# Quasi-Collatz T(x) exhaustive scanner

Map used (matching the paper):

T(x) = (4x - (x mod 3)) / 3^v3(4x - (x mod 3)), for positive x not divisible by 3.

## Build on an Intel MacBook Pro (macOS)

```bash
clang -O3 -march=native -flto -DNDEBUG -pthread collatz3_scan.c -lm -o collatz3_scan
```

If `-flto` is unavailable, omit it:

```bash
clang -O3 -march=native -DNDEBUG -pthread collatz3_scan.c -lm -o collatz3_scan
```

## Validation run: 1,000,000

```bash
./collatz3_scan --start 1 --end 1000000 --threads 4 --out results_1e6 --paths records
```

Expected attractor counts:

- fixed 1: 66,382 (9.957295%)
- fixed 2: 431,888 (64.783168%)
- 4-cycle {22,29,38,50}: 168,397 (25.259537%)

The program also distinguishes:

- `T_iterations_to_cycle`: number of reduced-map T iterations before entering a cycle.
- `total_v3_divisions_to_cycle`: sum of all v3 exponents before cycle entry. For x=969812 this is 326, matching the number reported in the paper.
- `reduced_state_peak`: maximum fully reduced T-state.
- `expanded_peak_after_first_division`: maximum value after the mandatory first division by 3 but before removing any additional 3 factors. The 91,577,291,778 peak reported in the paper appears under this convention.
- `raw_affine_peak`: maximum M(x)=4x-r before division by 3.

## Full scan to 1,000,000,000

Recommended first run (small output):

```bash
./collatz3_scan --start 1 --end 1000000000 --threads 4 --out results_1e9 --paths records
```

For a 2-core/4-thread 2012 MacBook Pro, try `--threads 2` or `--threads 4`; compare temperatures and throughput. `--threads 4` may not always be faster on an older laptop because of thermal throttling.

## Output modes

`--paths none` writes only aggregate results.

`--paths records` writes only record-breaking trajectories and any newly discovered cycles. This is recommended for 1e9.

`--paths full` writes every trajectory to per-thread JSONL and CSV. At 1e9 this can require enormous disk space and is not recommended unless you have very large external storage.

## Output files

- `summary.json` — main machine-readable summary
- `cycle_counts.csv` — attractor counts and percentages
- `steps_histogram.dat` — T-iteration histogram
- `report.tex` — generated LaTeX report
- `run_info.txt` — run metadata and speed
- `orbits_tNN.jsonl` — paths according to selected path mode
- `orbits_tNN.csv` — compact orbit metadata according to selected path mode

## Important scientific point

A finite scan to 1e9 verifies only starts in that finite range. It does not prove global convergence for all positive integers. Any newly found cycle is reported generically by its minimum cycle element and cycle length.
