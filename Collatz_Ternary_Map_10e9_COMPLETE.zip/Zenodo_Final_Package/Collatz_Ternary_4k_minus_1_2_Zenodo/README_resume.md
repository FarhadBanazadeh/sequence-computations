# Checkpoint/Resume runner for the quasi-Collatz scan

This launcher uses the already validated `collatz3_scan.c`, but scans the full
range in independent chunks. A chunk is committed only after its `summary.json`
exists. `checkpoint.txt` then records the next chunk start.

Default:
- END = 1,000,000,000
- CHUNK = 10,000,000
- THREADS = 2
- output = results_1e9_chunks
- paths = records

Run:
    chmod +x run_1b_resume.sh
    ./run_1b_resume.sh

If interrupted:
    ./run_1b_resume.sh

It resumes from `results_1e9_chunks/checkpoint.txt`.

First validation:
    END=1000000 CHUNK=250000 THREADS=2 ROOT=resume_test_1e6 ./run_1b_resume.sh

Important:
The existing C scanner writes per-chunk JSON/CSV/DAT/LaTeX outputs. This
launcher makes the expensive scan resumable without changing the validated
mathematics in the C core. Final cross-chunk aggregation should be performed
after all chunks complete; do not interpret one chunk's percentages as the
global 1e9 percentages.
