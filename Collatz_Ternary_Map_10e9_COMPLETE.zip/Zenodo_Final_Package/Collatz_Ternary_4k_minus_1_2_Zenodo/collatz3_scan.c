#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <inttypes.h>
#include <errno.h>
#include <math.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pthread.h>

/*
  Exhaustive scanner for the quasi-Collatz map from the user's paper:

      S = { x in Z_{>0} : x mod 3 != 0 }
      M(x) = 4x - (x mod 3)
      T(x) = M(x) / 3^{v_3(M(x))}

  Features:
    - scans all positive x in [start,end] not divisible by 3
    - pthread parallelism (portable on macOS without OpenMP)
    - generic cycle detection using a per-thread path + hash table
    - exact transient length, cycle length, orbit peak, peak/start ratio
    - known-cycle classification plus discovery of any new cycle
    - JSONL/CSV output modes: none, records, full
    - histogram of steps-to-cycle (.dat)
    - cycle summary CSV + JSON
    - generated LaTeX report
    - overflow detection for uint64_t arithmetic

  Build on macOS:
      clang -O3 -march=native -flto -DNDEBUG -pthread collatz3_scan.c -o collatz3_scan

  Example:
      ./collatz3_scan --start 1 --end 1000000 --threads 4 --out results_1e6 --paths records
      ./collatz3_scan --start 1 --end 1000000000 --threads 4 --out results_1e9 --paths records
*/

typedef enum { PATHS_NONE=0, PATHS_RECORDS=1, PATHS_FULL=2 } PathMode;

typedef struct {
    uint64_t *v;
    size_t n, cap;
} U64Vec;

typedef struct {
    uint32_t *v;
    size_t n, cap;
} U32Vec;

typedef struct {
    uint64_t *keys;
    uint32_t *vals;
    uint8_t *used;
    size_t cap;
} HashMap;

typedef struct {
    uint64_t key_min;
    uint32_t len;
    uint64_t count;
    uint64_t representative;
} CycleStat;

typedef struct {
    CycleStat *a;
    size_t n, cap;
} CycleVec;

typedef struct {
    uint64_t *bins;
    size_t n;
} Hist;

typedef struct {
    uint64_t tested;
    uint64_t overflowed;
    uint64_t max_steps;
    uint64_t max_steps_start;
    uint64_t max_steps_peak;
    uint64_t max_v3_sum;
    uint64_t max_v3_sum_start;
    uint64_t max_peak;
    uint64_t max_peak_start;
    uint64_t max_expanded_peak;
    uint64_t max_expanded_peak_start;
    uint64_t max_raw_affine_peak;
    uint64_t max_raw_affine_peak_start;
    long double max_peak_ratio;
    uint64_t max_peak_ratio_start;
    uint64_t max_peak_ratio_peak;
    long double sum_steps;
    long double sum_log_ratio;
    CycleVec cycles;
    Hist hist;
} Stats;

typedef struct {
    int tid;
    uint64_t lo, hi;
    const char *outdir;
    PathMode path_mode;
    uint64_t progress_every;
    Stats st;
} ThreadCtx;

static inline uint64_t mix64(uint64_t x) {
    x ^= x >> 30;
    x *= UINT64_C(0xbf58476d1ce4e5b9);
    x ^= x >> 27;
    x *= UINT64_C(0x94d049bb133111eb);
    x ^= x >> 31;
    return x;
}

static void die(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

static void vec_init(U64Vec *v) { memset(v,0,sizeof(*v)); }
static void vec_reset(U64Vec *v) { v->n=0; }
static void vec_free(U64Vec *v) { free(v->v); memset(v,0,sizeof(*v)); }
static void vec_push(U64Vec *v, uint64_t x) {
    if (v->n == v->cap) {
        size_t nc = v->cap ? v->cap*2 : 256;
        uint64_t *p = (uint64_t*)realloc(v->v, nc*sizeof(uint64_t));
        if (!p) die("realloc path");
        v->v=p; v->cap=nc;
    }
    v->v[v->n++] = x;
}

static void u32v_init(U32Vec *v){memset(v,0,sizeof(*v));}
static void u32v_reset(U32Vec *v){v->n=0;}
static void u32v_free(U32Vec *v){free(v->v);memset(v,0,sizeof(*v));}
static void u32v_push(U32Vec *v,uint32_t x){if(v->n==v->cap){size_t nc=v->cap?v->cap*2:256;uint32_t*p=realloc(v->v,nc*sizeof(uint32_t));if(!p)die("realloc kpath");v->v=p;v->cap=nc;}v->v[v->n++]=x;}

static size_t next_pow2(size_t x) {
    size_t p=1; while (p<x) p<<=1; return p;
}
static void hm_init(HashMap *h, size_t cap) {
    h->cap = next_pow2(cap < 512 ? 512 : cap);
    h->keys = (uint64_t*)calloc(h->cap,sizeof(uint64_t));
    h->vals = (uint32_t*)calloc(h->cap,sizeof(uint32_t));
    h->used = (uint8_t*)calloc(h->cap,sizeof(uint8_t));
    if(!h->keys||!h->vals||!h->used) die("calloc hash");
}
static void hm_clear(HashMap *h) { memset(h->used,0,h->cap); }
static void hm_free(HashMap *h) { free(h->keys); free(h->vals); free(h->used); memset(h,0,sizeof(*h)); }
static bool hm_get(const HashMap *h, uint64_t k, uint32_t *v) {
    size_t m=h->cap-1, i=(size_t)mix64(k)&m;
    while(h->used[i]) {
        if(h->keys[i]==k){*v=h->vals[i]; return true;}
        i=(i+1)&m;
    }
    return false;
}
static void hm_put(HashMap *h, uint64_t k, uint32_t v) {
    size_t m=h->cap-1, i=(size_t)mix64(k)&m;
    while(h->used[i]) {
        if(h->keys[i]==k){h->vals[i]=v; return;}
        i=(i+1)&m;
    }
    h->used[i]=1; h->keys[i]=k; h->vals[i]=v;
}

static void cycles_init(CycleVec *c){memset(c,0,sizeof(*c));}
static void cycles_free(CycleVec *c){free(c->a); memset(c,0,sizeof(*c));}
static CycleStat* cycles_get(CycleVec *c, uint64_t key, uint32_t len, uint64_t rep) {
    for(size_t i=0;i<c->n;i++) if(c->a[i].key_min==key && c->a[i].len==len) return &c->a[i];
    if(c->n==c->cap){size_t nc=c->cap?c->cap*2:8; CycleStat *p=realloc(c->a,nc*sizeof(*p)); if(!p)die("realloc cycles"); c->a=p;c->cap=nc;}
    c->a[c->n]=(CycleStat){key,len,0,rep};
    return &c->a[c->n++];
}

static void hist_init(Hist *h){memset(h,0,sizeof(*h));}
static void hist_free(Hist *h){free(h->bins); memset(h,0,sizeof(*h));}
static void hist_add(Hist *h, uint64_t k, uint64_t add) {
    if(k>=h->n){size_t nn=h->n?h->n:256; while(k>=nn) nn*=2; uint64_t *p=realloc(h->bins,nn*sizeof(uint64_t)); if(!p)die("realloc hist"); memset(p+h->n,0,(nn-h->n)*sizeof(uint64_t)); h->bins=p; h->n=nn;}
    h->bins[k]+=add;
}

static void stats_init(Stats *s){memset(s,0,sizeof(*s)); cycles_init(&s->cycles); hist_init(&s->hist);}
static void stats_free(Stats *s){cycles_free(&s->cycles); hist_free(&s->hist);}

/* Returns false on uint64 overflow. k is v_3(M(x)). */
static inline bool T_u64(uint64_t x, uint64_t *y, uint32_t *k, uint64_t *first_div, uint64_t *raw_m) {
    uint64_t r = x % 3u;
    if (r == 0) return false; /* outside state space */
    __uint128_t wide = (__uint128_t)4u * (__uint128_t)x - (__uint128_t)r;
    if (wide > UINT64_MAX) return false;
    uint64_t m = (uint64_t)wide;
    if(raw_m) *raw_m=m;
    uint32_t e=0;
    do { m/=3u; e++; if(e==1 && first_div) *first_div=m; } while(m%3u==0u);
    *y=m; *k=e; return true;
}

static const char* known_cycle_name(uint64_t key, uint32_t len) {
    if(key==1 && len==1) return "fixed_1";
    if(key==2 && len==1) return "fixed_2";
    if(key==22 && len==4) return "cycle_22_29_38_50";
    return "new_cycle";
}

static uint64_t cycle_min(const U64Vec *path, size_t c0) {
    uint64_t m=UINT64_MAX;
    for(size_t i=c0;i<path->n;i++) if(path->v[i]<m)m=path->v[i];
    return m;
}

static void print_json_path(FILE *f, const U64Vec *p) {
    fputc('[',f);
    for(size_t i=0;i<p->n;i++){ if(i)fputc(',',f); fprintf(f,"%" PRIu64,p->v[i]); }
    fputc(']',f);
}

static void write_orbit(FILE *jsonl, FILE *csv, uint64_t start, const U64Vec *path,
                        size_t c0, uint32_t clen, uint64_t ckey, uint64_t peak,
                        uint64_t v3sum, uint64_t expanded_peak, uint64_t raw_peak, bool overflow) {
    if(jsonl){
        fprintf(jsonl,"{\"start\":%" PRIu64 ",\"T_iterations_to_cycle\":%zu,\"total_v3_divisions_to_cycle\":%" PRIu64 ",\"cycle_length\":%u,\"cycle_key\":%" PRIu64 ",\"cycle_name\":\"%s\",\"reduced_state_peak\":%" PRIu64 ",\"expanded_peak_after_first_division\":%" PRIu64 ",\"raw_affine_peak\":%" PRIu64 ",\"overflow\":%s,\"path\":",
                start,c0,v3sum,clen,ckey,known_cycle_name(ckey,clen),peak,expanded_peak,raw_peak,overflow?"true":"false");
        print_json_path(jsonl,path);
        fprintf(jsonl,"}\n");
    }
    if(csv){
        fprintf(csv,"%" PRIu64 ",%zu,%" PRIu64 ",%u,%" PRIu64 ",%s,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%s\n",
                start,c0,v3sum,clen,ckey,known_cycle_name(ckey,clen),peak,expanded_peak,raw_peak,overflow?"true":"false");
    }
}

static bool simulate(uint64_t start, U64Vec *path, U32Vec *kpath, HashMap *hm,
                     size_t *cycle0, uint32_t *clen, uint64_t *ckey, uint64_t *peak,
                     uint64_t *v3sum, uint64_t *expanded_peak, uint64_t *raw_peak) {
    vec_reset(path); u32v_reset(kpath); hm_clear(hm);
    uint64_t x=start; *peak=x; *v3sum=0; *expanded_peak=x; *raw_peak=x;
    for(;;){
        if(path->n >= UINT32_MAX) return false;
        hm_put(hm,x,(uint32_t)path->n);
        vec_push(path,x);
        if(x>*peak)*peak=x;
        uint64_t y,first_div=0,raw_m=0; uint32_t k;
        if(!T_u64(x,&y,&k,&first_div,&raw_m)) return false;
        u32v_push(kpath,k);
        if(y>*peak)*peak=y;
        if(first_div>*expanded_peak)*expanded_peak=first_div;
        if(raw_m>*raw_peak)*raw_peak=raw_m;
        uint32_t idx;
        if(hm_get(hm,y,&idx)){
            *cycle0=(size_t)idx;
            *clen=(uint32_t)(path->n - idx);
            *ckey=cycle_min(path,*cycle0);
            for(size_t z=0; z<*cycle0; z++) *v3sum += kpath->v[z];
            return true;
        }
        x=y;
        /* grow hash if trajectory becomes unexpectedly large */
        if(path->n*2 > hm->cap){
            HashMap nh; hm_init(&nh,hm->cap*2);
            for(size_t i=0;i<path->n;i++) hm_put(&nh,path->v[i],(uint32_t)i);
            hm_free(hm); *hm=nh;
        }
    }
}

static void* worker(void *arg) {
    ThreadCtx *c=(ThreadCtx*)arg;
    Stats *s=&c->st; stats_init(s);
    U64Vec path; vec_init(&path);
    U32Vec kpath; u32v_init(&kpath);
    HashMap hm; hm_init(&hm,1024);

    char jpath[1024], cpath[1024];
    snprintf(jpath,sizeof(jpath),"%s/orbits_t%02d.jsonl",c->outdir,c->tid);
    snprintf(cpath,sizeof(cpath),"%s/orbits_t%02d.csv",c->outdir,c->tid);
    FILE *fj=NULL,*fc=NULL;
    if(c->path_mode!=PATHS_NONE){
        fj=fopen(jpath,"w"); if(!fj)die("fopen jsonl");
        fc=fopen(cpath,"w"); if(!fc)die("fopen csv");
        fprintf(fc,"start,T_iterations_to_cycle,total_v3_divisions_to_cycle,cycle_length,cycle_key,cycle_name,reduced_state_peak,expanded_peak_after_first_division,raw_affine_peak,overflow\n");
    }

    uint64_t local_record_steps=0, local_record_peak=0;
    for(uint64_t x=c->lo; x<=c->hi; x++){
        if(x%3u==0u){ if(x==UINT64_MAX)break; continue; }
        size_t c0=0; uint32_t clen=0; uint64_t ckey=0,peak=0,v3sum=0,expanded_peak=0,raw_peak=0;
        bool ok=simulate(x,&path,&kpath,&hm,&c0,&clen,&ckey,&peak,&v3sum,&expanded_peak,&raw_peak);
        s->tested++;
        if(!ok){s->overflowed++; if(c->path_mode==PATHS_FULL)write_orbit(fj,fc,x,&path,0,0,0,peak,0,expanded_peak,raw_peak,true); continue;}

        CycleStat *cs=cycles_get(&s->cycles,ckey,clen,path.v[c0]); cs->count++;
        hist_add(&s->hist,(uint64_t)c0,1);
        s->sum_steps += (long double)c0;
        if(x>0 && peak>0) s->sum_log_ratio += logl((long double)peak/(long double)x);

        bool rec=false;
        if((uint64_t)c0 > s->max_steps){s->max_steps=c0;s->max_steps_start=x;s->max_steps_peak=peak;rec=true;}
        if(v3sum > s->max_v3_sum){s->max_v3_sum=v3sum;s->max_v3_sum_start=x;rec=true;}
        if(peak > s->max_peak){s->max_peak=peak;s->max_peak_start=x;rec=true;}
        if(expanded_peak > s->max_expanded_peak){s->max_expanded_peak=expanded_peak;s->max_expanded_peak_start=x;rec=true;}
        if(raw_peak > s->max_raw_affine_peak){s->max_raw_affine_peak=raw_peak;s->max_raw_affine_peak_start=x;rec=true;}
        long double ratio=(long double)peak/(long double)x;
        if(ratio>s->max_peak_ratio){s->max_peak_ratio=ratio;s->max_peak_ratio_start=x;s->max_peak_ratio_peak=peak;rec=true;}
        if((uint64_t)c0>local_record_steps){local_record_steps=c0;rec=true;}
        if(peak>local_record_peak){local_record_peak=peak;rec=true;}

        if(c->path_mode==PATHS_FULL || (c->path_mode==PATHS_RECORDS && (rec || strcmp(known_cycle_name(ckey,clen),"new_cycle")==0)))
            write_orbit(fj,fc,x,&path,c0,clen,ckey,peak,v3sum,expanded_peak,raw_peak,false);

        if(c->progress_every && (s->tested % c->progress_every)==0){
            fprintf(stderr,"[thread %d] tested=%" PRIu64 " current=%" PRIu64 " range=%" PRIu64 "..%" PRIu64 "\n",c->tid,s->tested,x,c->lo,c->hi);
        }
        if(x==UINT64_MAX)break;
    }
    if(fj)fclose(fj); if(fc)fclose(fc);
    hm_free(&hm); u32v_free(&kpath); vec_free(&path);
    return NULL;
}

static void merge_stats(Stats *dst, const Stats *src){
    dst->tested += src->tested; dst->overflowed += src->overflowed;
    dst->sum_steps += src->sum_steps; dst->sum_log_ratio += src->sum_log_ratio;
    if(src->max_steps>dst->max_steps){dst->max_steps=src->max_steps;dst->max_steps_start=src->max_steps_start;dst->max_steps_peak=src->max_steps_peak;}
    if(src->max_v3_sum>dst->max_v3_sum){dst->max_v3_sum=src->max_v3_sum;dst->max_v3_sum_start=src->max_v3_sum_start;}
    if(src->max_peak>dst->max_peak){dst->max_peak=src->max_peak;dst->max_peak_start=src->max_peak_start;}
    if(src->max_expanded_peak>dst->max_expanded_peak){dst->max_expanded_peak=src->max_expanded_peak;dst->max_expanded_peak_start=src->max_expanded_peak_start;}
    if(src->max_raw_affine_peak>dst->max_raw_affine_peak){dst->max_raw_affine_peak=src->max_raw_affine_peak;dst->max_raw_affine_peak_start=src->max_raw_affine_peak_start;}
    if(src->max_peak_ratio>dst->max_peak_ratio){dst->max_peak_ratio=src->max_peak_ratio;dst->max_peak_ratio_start=src->max_peak_ratio_start;dst->max_peak_ratio_peak=src->max_peak_ratio_peak;}
    for(size_t i=0;i<src->cycles.n;i++){CycleStat *d=cycles_get(&dst->cycles,src->cycles.a[i].key_min,src->cycles.a[i].len,src->cycles.a[i].representative); d->count+=src->cycles.a[i].count;}
    for(size_t i=0;i<src->hist.n;i++) if(src->hist.bins[i]) hist_add(&dst->hist,i,src->hist.bins[i]);
}

static int cmp_cycle(const void *a,const void *b){const CycleStat*x=a,*y=b; return (x->key_min>y->key_min)-(x->key_min<y->key_min);}

static void write_outputs(const char *out, uint64_t start, uint64_t end, int threads, PathMode pm, const Stats *s, double elapsed){
    char p[1024];
    snprintf(p,sizeof(p),"%s/summary.json",out); FILE *fj=fopen(p,"w"); if(!fj)die("summary.json");
    fprintf(fj,"{\n  \"map\": \"T(x)=(4x-(x mod 3))/3^v3(4x-(x mod 3))\",\n");
    fprintf(fj,"  \"start\": %" PRIu64 ",\n  \"end\": %" PRIu64 ",\n  \"threads\": %d,\n  \"tested\": %" PRIu64 ",\n  \"overflowed\": %" PRIu64 ",\n",start,end,threads,s->tested,s->overflowed);
    fprintf(fj,"  \"elapsed_seconds\": %.6f,\n  \"rate_per_second\": %.3f,\n",elapsed, elapsed>0?(double)s->tested/elapsed:0.0);
    fprintf(fj,"  \"max_T_iterations_to_cycle\": %" PRIu64 ",\n  \"max_T_iterations_start\": %" PRIu64 ",\n  \"max_T_iterations_peak\": %" PRIu64 ",\n  \"max_total_v3_divisions_to_cycle\": %" PRIu64 ",\n  \"max_total_v3_divisions_start\": %" PRIu64 ",\n",s->max_steps,s->max_steps_start,s->max_steps_peak,s->max_v3_sum,s->max_v3_sum_start);
    fprintf(fj,"  \"max_reduced_state_peak\": %" PRIu64 ",\n  \"max_reduced_state_peak_start\": %" PRIu64 ",\n  \"max_expanded_peak_after_first_division\": %" PRIu64 ",\n  \"max_expanded_peak_start\": %" PRIu64 ",\n  \"max_raw_affine_peak\": %" PRIu64 ",\n  \"max_raw_affine_peak_start\": %" PRIu64 ",\n  \"max_peak_ratio\": %.12Lf,\n  \"max_peak_ratio_start\": %" PRIu64 ",\n  \"max_peak_ratio_peak\": %" PRIu64 ",\n",s->max_peak,s->max_peak_start,s->max_expanded_peak,s->max_expanded_peak_start,s->max_raw_affine_peak,s->max_raw_affine_peak_start,s->max_peak_ratio,s->max_peak_ratio_start,s->max_peak_ratio_peak);
    fprintf(fj,"  \"mean_steps_to_cycle\": %.12Lf,\n  \"cycles\": [\n",s->tested?s->sum_steps/(long double)(s->tested-s->overflowed):0.0L);
    for(size_t i=0;i<s->cycles.n;i++){
        const CycleStat *c=&s->cycles.a[i]; long double pct=(s->tested-s->overflowed)?100.0L*c->count/(long double)(s->tested-s->overflowed):0;
        fprintf(fj,"    {\"key\":%" PRIu64 ",\"length\":%u,\"name\":\"%s\",\"count\":%" PRIu64 ",\"percent\":%.10Lf}%s\n",c->key_min,c->len,known_cycle_name(c->key_min,c->len),c->count,pct,(i+1<s->cycles.n)?",":"");
    }
    fprintf(fj,"  ]\n}\n"); fclose(fj);

    snprintf(p,sizeof(p),"%s/cycle_counts.csv",out); FILE *fc=fopen(p,"w"); if(!fc)die("cycle csv");
    fprintf(fc,"cycle_key,cycle_length,cycle_name,count,percent\n");
    for(size_t i=0;i<s->cycles.n;i++){const CycleStat*c=&s->cycles.a[i];long double pct=(s->tested-s->overflowed)?100.0L*c->count/(long double)(s->tested-s->overflowed):0;fprintf(fc,"%" PRIu64 ",%u,%s,%" PRIu64 ",%.10Lf\n",c->key_min,c->len,known_cycle_name(c->key_min,c->len),c->count,pct);} fclose(fc);

    snprintf(p,sizeof(p),"%s/steps_histogram.dat",out); FILE *fh=fopen(p,"w"); if(!fh)die("hist dat");
    fprintf(fh,"# steps_to_cycle count\n"); for(size_t i=0;i<s->hist.n;i++)if(s->hist.bins[i])fprintf(fh,"%zu %" PRIu64 "\n",i,s->hist.bins[i]); fclose(fh);

    snprintf(p,sizeof(p),"%s/report.tex",out); FILE *ft=fopen(p,"w"); if(!ft)die("report.tex");
    fprintf(ft,"\\documentclass[11pt]{article}\n\\usepackage{amsmath,booktabs,geometry}\n\\geometry{margin=1in}\n\\begin{document}\n");
    fprintf(ft,"\\section*{Exhaustive computation for the quasi-Collatz map}\n");
    fprintf(ft,"We scanned all positive integers $x\\in[%" PRIu64 ",%" PRIu64 "]$ with $3\\nmid x$ under\n\\[T(x)=\\frac{4x-(x\\bmod 3)}{3^{\\nu_3(4x-(x\\bmod 3))}}.\\]\n",start,end);
    fprintf(ft,"Tested: %" PRIu64 "; overflowed: %" PRIu64 "; elapsed: %.2f s.\\\\\n",s->tested,s->overflowed,elapsed);
    fprintf(ft,"Maximum reduced-map transient length: %" PRIu64 " (start %" PRIu64 ").\\\\\n",s->max_steps,s->max_steps_start);
    fprintf(ft,"Maximum total $\\nu_3$ divisions before the cycle: %" PRIu64 " (start %" PRIu64 ").\\\\\n",s->max_v3_sum,s->max_v3_sum_start);
    fprintf(ft,"Maximum observed peak: %" PRIu64 " (start %" PRIu64 ").\\\\\n",s->max_peak,s->max_peak_start);
    fprintf(ft,"\\subsection*{Attractor distribution}\n\\begin{tabular}{lrrr}\\toprule Attractor & Length & Count & Percent \\\\ \\midrule\n");
    for(size_t i=0;i<s->cycles.n;i++){const CycleStat*c=&s->cycles.a[i];long double pct=(s->tested-s->overflowed)?100.0L*c->count/(long double)(s->tested-s->overflowed):0;fprintf(ft,"%s & %u & %" PRIu64 " & %.6Lf\\%% \\\\ \n",known_cycle_name(c->key_min,c->len),c->len,c->count,pct);} 
    fprintf(ft,"\\bottomrule\\end{tabular}\n\\end{document}\n"); fclose(ft);

    snprintf(p,sizeof(p),"%s/run_info.txt",out); FILE *fi=fopen(p,"w"); if(!fi)die("run_info");
    fprintf(fi,"start=%" PRIu64 "\nend=%" PRIu64 "\nthreads=%d\npaths_mode=%d\ntested=%" PRIu64 "\noverflowed=%" PRIu64 "\nelapsed_seconds=%.6f\nrate_per_second=%.3f\n",start,end,threads,(int)pm,s->tested,s->overflowed,elapsed,elapsed>0?(double)s->tested/elapsed:0.0); fclose(fi);
}

static uint64_t parse_u64(const char *s){char *e=NULL; errno=0; unsigned long long v=strtoull(s,&e,10); if(errno||!e||*e) {fprintf(stderr,"bad integer: %s\n",s);exit(2);} return (uint64_t)v;}
static void usage(const char *p){
    fprintf(stderr,"Usage: %s [--start N] --end N [--threads N] [--out DIR] [--paths none|records|full] [--progress N]\n",p);
}

int main(int argc,char **argv){
    uint64_t start=1,end=1000000,progress=1000000; int threads=1; const char*out="results"; PathMode pm=PATHS_RECORDS;
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"--start")&&i+1<argc)start=parse_u64(argv[++i]);
        else if(!strcmp(argv[i],"--end")&&i+1<argc)end=parse_u64(argv[++i]);
        else if(!strcmp(argv[i],"--threads")&&i+1<argc)threads=(int)parse_u64(argv[++i]);
        else if(!strcmp(argv[i],"--out")&&i+1<argc)out=argv[++i];
        else if(!strcmp(argv[i],"--progress")&&i+1<argc)progress=parse_u64(argv[++i]);
        else if(!strcmp(argv[i],"--paths")&&i+1<argc){const char*m=argv[++i]; if(!strcmp(m,"none"))pm=PATHS_NONE; else if(!strcmp(m,"records"))pm=PATHS_RECORDS; else if(!strcmp(m,"full"))pm=PATHS_FULL; else{usage(argv[0]);return 2;}}
        else {usage(argv[0]);return 2;}
    }
    if(start<1||end<start||threads<1||threads>64){usage(argv[0]);return 2;}
    if(mkdir(out,0755)!=0 && errno!=EEXIST)die("mkdir out");

    pthread_t *th=calloc((size_t)threads,sizeof(*th)); ThreadCtx *ctx=calloc((size_t)threads,sizeof(*ctx)); if(!th||!ctx)die("calloc threads");
    uint64_t total=end-start+1, base=total/(uint64_t)threads, rem=total%(uint64_t)threads, cur=start;
    struct timespec ts0,ts1; clock_gettime(CLOCK_MONOTONIC,&ts0);
    for(int t=0;t<threads;t++){
        uint64_t sz=base+(t<(int)rem?1:0); ctx[t].tid=t;ctx[t].lo=cur;ctx[t].hi=cur+sz-1;ctx[t].outdir=out;ctx[t].path_mode=pm;ctx[t].progress_every=progress; cur+=sz;
        if(pthread_create(&th[t],NULL,worker,&ctx[t])!=0)die("pthread_create");
    }
    Stats all; stats_init(&all);
    for(int t=0;t<threads;t++){pthread_join(th[t],NULL); merge_stats(&all,&ctx[t].st); stats_free(&ctx[t].st);} 
    qsort(all.cycles.a,all.cycles.n,sizeof(CycleStat),cmp_cycle);
    clock_gettime(CLOCK_MONOTONIC,&ts1); double elapsed=(ts1.tv_sec-ts0.tv_sec)+1e-9*(ts1.tv_nsec-ts0.tv_nsec);
    write_outputs(out,start,end,threads,pm,&all,elapsed);

    printf("Done. tested=%" PRIu64 " overflowed=%" PRIu64 " elapsed=%.3fs rate=%.1f/s\n",all.tested,all.overflowed,elapsed,elapsed>0?(double)all.tested/elapsed:0.0);
    printf("max_T_iterations=%" PRIu64 " start=%" PRIu64 " peak_on_that_orbit=%" PRIu64 "\n",all.max_steps,all.max_steps_start,all.max_steps_peak);
    printf("max_total_v3_divisions=%" PRIu64 " start=%" PRIu64 "\n",all.max_v3_sum,all.max_v3_sum_start);
    printf("max_reduced_peak=%" PRIu64 " start=%" PRIu64 "\n",all.max_peak,all.max_peak_start);
    printf("max_expanded_peak_after_first_division=%" PRIu64 " start=%" PRIu64 "\n",all.max_expanded_peak,all.max_expanded_peak_start);
    printf("max_raw_affine_peak=%" PRIu64 " start=%" PRIu64 "\n",all.max_raw_affine_peak,all.max_raw_affine_peak_start);
    for(size_t i=0;i<all.cycles.n;i++){CycleStat*c=&all.cycles.a[i];long double pct=(all.tested-all.overflowed)?100.0L*c->count/(long double)(all.tested-all.overflowed):0;printf("cycle key=%" PRIu64 " len=%u %-22s count=%" PRIu64 " pct=%.6Lf%%\n",c->key_min,c->len,known_cycle_name(c->key_min,c->len),c->count,pct);} 
    stats_free(&all); free(th); free(ctx); return 0;
}
