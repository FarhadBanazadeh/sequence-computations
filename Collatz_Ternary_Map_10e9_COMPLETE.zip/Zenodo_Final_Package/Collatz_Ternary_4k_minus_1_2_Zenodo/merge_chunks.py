#!/usr/bin/env python3
import argparse, csv, glob, json, os
from collections import defaultdict

def better(cur_val, cur_start, new_val, new_start):
    # Prefer larger value; on ties prefer the smaller start for deterministic output.
    return (new_val > cur_val) or (new_val == cur_val and (cur_start is None or new_start < cur_start))

def main():
    ap = argparse.ArgumentParser(description="Merge checkpointed quasi-Collatz chunk outputs.")
    ap.add_argument("root", help="Chunk root, e.g. results_1e9_chunks")
    args = ap.parse_args()
    root = args.root

    summaries = sorted(glob.glob(os.path.join(root, "chunk_*", "summary.json")))
    if not summaries:
        raise SystemExit(f"No chunk summaries found under {root}/chunk_*/summary.json")

    totals = {
        "tested": 0, "overflowed": 0, "elapsed_seconds_sum": 0.0,
        "start": None, "end": None,
        "max_T_iterations_to_cycle": 0, "max_T_iterations_start": None, "max_T_iterations_peak": 0,
        "max_total_v3_divisions_to_cycle": 0, "max_total_v3_divisions_start": None,
        "max_reduced_state_peak": 0, "max_reduced_state_peak_start": None,
        "max_expanded_peak_after_first_division": 0, "max_expanded_peak_start": None,
        "max_raw_affine_peak": 0, "max_raw_affine_peak_start": None,
        "max_peak_ratio": 0.0, "max_peak_ratio_start": None, "max_peak_ratio_peak": 0,
    }
    cycle_counts = defaultdict(int)
    cycle_meta = {}
    weighted_steps = 0.0
    hist = defaultdict(int)

    for sp in summaries:
        with open(sp, "r", encoding="utf-8") as f:
            s = json.load(f)

        totals["tested"] += int(s["tested"])
        totals["overflowed"] += int(s["overflowed"])
        totals["elapsed_seconds_sum"] += float(s.get("elapsed_seconds", 0))
        totals["start"] = int(s["start"]) if totals["start"] is None else min(totals["start"], int(s["start"]))
        totals["end"] = int(s["end"]) if totals["end"] is None else max(totals["end"], int(s["end"]))

        valid = int(s["tested"]) - int(s["overflowed"])
        weighted_steps += float(s.get("mean_steps_to_cycle", 0.0)) * valid

        fields = [
            ("max_T_iterations_to_cycle","max_T_iterations_start"),
            ("max_total_v3_divisions_to_cycle","max_total_v3_divisions_start"),
            ("max_reduced_state_peak","max_reduced_state_peak_start"),
            ("max_expanded_peak_after_first_division","max_expanded_peak_start"),
            ("max_raw_affine_peak","max_raw_affine_peak_start"),
            ("max_peak_ratio","max_peak_ratio_start"),
        ]
        for vf, sf in fields:
            nv = s.get(vf, 0)
            ns = s.get(sf)
            if ns is not None and better(totals[vf], totals[sf], nv, ns):
                totals[vf] = nv
                totals[sf] = ns
                if vf == "max_T_iterations_to_cycle":
                    totals["max_T_iterations_peak"] = int(s.get("max_T_iterations_peak", 0))
                if vf == "max_peak_ratio":
                    totals["max_peak_ratio_peak"] = int(s.get("max_peak_ratio_peak", 0))

        for c in s.get("cycles", []):
            key = (int(c["key"]), int(c["length"]), c.get("name", "unknown"))
            cycle_counts[key] += int(c["count"])
            cycle_meta[key] = c

        hp = os.path.join(os.path.dirname(sp), "steps_histogram.dat")
        if os.path.exists(hp):
            with open(hp, "r", encoding="utf-8") as hf:
                for line in hf:
                    line=line.strip()
                    if not line or line.startswith("#"): continue
                    a,b=line.split()
                    hist[int(a)] += int(b)

    valid_total = totals["tested"] - totals["overflowed"]
    mean_steps = weighted_steps / valid_total if valid_total else 0.0

    cycles = []
    for (key,length,name), count in sorted(cycle_counts.items()):
        pct = 100.0 * count / valid_total if valid_total else 0.0
        cycles.append({"key":key,"length":length,"name":name,"count":count,"percent":pct})

    out = {
        "map": "T(x)=(4x-(x mod 3))/3^v3(4x-(x mod 3))",
        "start": totals["start"], "end": totals["end"],
        "chunks_merged": len(summaries),
        "tested": totals["tested"], "overflowed": totals["overflowed"],
        "elapsed_seconds_sum": totals["elapsed_seconds_sum"],
        "max_T_iterations_to_cycle": totals["max_T_iterations_to_cycle"],
        "max_T_iterations_start": totals["max_T_iterations_start"],
        "max_T_iterations_peak": totals["max_T_iterations_peak"],
        "max_total_v3_divisions_to_cycle": totals["max_total_v3_divisions_to_cycle"],
        "max_total_v3_divisions_start": totals["max_total_v3_divisions_start"],
        "max_reduced_state_peak": totals["max_reduced_state_peak"],
        "max_reduced_state_peak_start": totals["max_reduced_state_peak_start"],
        "max_expanded_peak_after_first_division": totals["max_expanded_peak_after_first_division"],
        "max_expanded_peak_start": totals["max_expanded_peak_start"],
        "max_raw_affine_peak": totals["max_raw_affine_peak"],
        "max_raw_affine_peak_start": totals["max_raw_affine_peak_start"],
        "max_peak_ratio": totals["max_peak_ratio"],
        "max_peak_ratio_start": totals["max_peak_ratio_start"],
        "max_peak_ratio_peak": totals["max_peak_ratio_peak"],
        "mean_steps_to_cycle": mean_steps,
        "cycles": cycles,
    }

    with open(os.path.join(root, "GLOBAL_summary.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

    with open(os.path.join(root, "GLOBAL_cycle_counts.csv"), "w", newline="", encoding="utf-8") as f:
        w=csv.writer(f)
        w.writerow(["cycle_key","cycle_length","cycle_name","count","percent"])
        for c in cycles:
            w.writerow([c["key"],c["length"],c["name"],c["count"],f'{c["percent"]:.10f}'])

    with open(os.path.join(root, "GLOBAL_steps_histogram.dat"), "w", encoding="utf-8") as f:
        f.write("# steps_to_cycle count\n")
        for k in sorted(hist):
            f.write(f"{k} {hist[k]}\n")

    with open(os.path.join(root, "GLOBAL_report.tex"), "w", encoding="utf-8") as f:
        f.write(r"\documentclass[11pt]{article}"+"\n")
        f.write(r"\usepackage{amsmath,booktabs,geometry}"+"\n")
        f.write(r"\geometry{margin=1in}"+"\n"+r"\begin{document}"+"\n")
        f.write(r"\section*{Exhaustive computation for the quasi-Collatz map}"+"\n")
        f.write(f"Range: {totals['start']}--{totals['end']}. Chunks merged: {len(summaries)}.\\\\\n")
        f.write(f"Tested: {totals['tested']}; overflowed: {totals['overflowed']}.\\\\\n")
        f.write(f"Maximum reduced-map transient length: {totals['max_T_iterations_to_cycle']} (start {totals['max_T_iterations_start']}).\\\\\n")
        f.write(f"Maximum total $\\nu_3$ divisions: {totals['max_total_v3_divisions_to_cycle']} (start {totals['max_total_v3_divisions_start']}).\\\\\n")
        f.write(f"Maximum reduced-state peak: {totals['max_reduced_state_peak']} (start {totals['max_reduced_state_peak_start']}).\\\\\n")
        f.write(r"\subsection*{Attractor distribution}"+"\n")
        f.write(r"\begin{tabular}{lrrr}\toprule Attractor & Length & Count & Percent \\ \midrule"+"\n")
        for c in cycles:
            name=c["name"].replace("_", r"\_")
            f.write(f"{name} & {c['length']} & {c['count']} & {c['percent']:.6f}\\% \\\\\n")
        f.write(r"\bottomrule\end{tabular}"+"\n"+r"\end{document}"+"\n")

    print(f"Merged {len(summaries)} chunks")
    print(f"tested={totals['tested']} overflowed={totals['overflowed']}")
    print(f"max_T_iterations={totals['max_T_iterations_to_cycle']} start={totals['max_T_iterations_start']}")
    print(f"max_total_v3_divisions={totals['max_total_v3_divisions_to_cycle']} start={totals['max_total_v3_divisions_start']}")
    print(f"max_reduced_peak={totals['max_reduced_state_peak']} start={totals['max_reduced_state_peak_start']}")
    for c in cycles:
        print(f"cycle key={c['key']} len={c['length']} {c['name']} count={c['count']} pct={c['percent']:.6f}%")
    print("Wrote GLOBAL_summary.json, GLOBAL_cycle_counts.csv, GLOBAL_steps_histogram.dat, GLOBAL_report.tex")

if __name__ == "__main__":
    main()
