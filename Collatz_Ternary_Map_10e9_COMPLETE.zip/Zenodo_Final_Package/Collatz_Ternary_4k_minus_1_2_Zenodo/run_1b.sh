#!/bin/bash
set -euo pipefail
THREADS="${THREADS:-4}"
OUT="${OUT:-results_1e9}"
clang -O3 -march=native -flto -DNDEBUG -pthread collatz3_scan.c -lm -o collatz3_scan || \
clang -O3 -march=native -DNDEBUG -pthread collatz3_scan.c -lm -o collatz3_scan
./collatz3_scan --start 1 --end 1000000000 --threads "$THREADS" --out "$OUT" --paths records --progress 1000000
