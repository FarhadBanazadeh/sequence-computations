ZENODO REPRODUCIBILITY PACKAGE

Paper:
A Ternary (4k-1(2))/3 Collatz-Type Map: Complete 3-Adic Reduction,
Algebraic Cycle Analysis, and Exhaustive Computational Verification up to 10^9

Author:
Farhad Banazadeh
fn.bana@hotmail.com
ORCID: 0009-0004-7023-0298

Main finite result:
All 666,666,667 positive starts x <= 10^9 with 3 not dividing x were tested.
No overflow and no attractor beyond fixed_1, fixed_2, and the four-cycle
22 -> 29 -> 38 -> 50 -> 22 was reported.

Files:
- article.pdf / article.tex
- collatz3_scan.c
- run_1b_resume.sh
- merge_chunks.py
- GLOBAL_summary_1e9.json
- GLOBAL_cycle_counts_1e9.csv
- supporting README/launcher files where available

Important archival note:
The original 100 results_1e9_chunks directories live on the computation Mac and
are not present in this ChatGPT runtime. Add that directory to the Zenodo deposit
if the complete raw chunk audit trail is desired.
