#!/bin/bash
set -euo pipefail

END="${END:-1000000000}"
CHUNK="${CHUNK:-10000000}"
THREADS="${THREADS:-2}"
ROOT="${ROOT:-results_1e9_chunks}"
PROGRESS="${PROGRESS:-1000000}"

mkdir -p "$ROOT"
LOG="$ROOT/master.log"
STATE="$ROOT/checkpoint.txt"

# Compile validated scanner.
clang -O3 -march=native -flto -DNDEBUG -pthread collatz3_scan.c -lm -o collatz3_scan 2>/dev/null || \
clang -O3 -march=native -DNDEBUG -pthread collatz3_scan.c -lm -o collatz3_scan

# checkpoint.txt stores the next integer range start.
if [ -f "$STATE" ]; then
  START=$(cat "$STATE")
else
  START=1
fi

echo "=== run started $(date) ===" | tee -a "$LOG"
echo "END=$END CHUNK=$CHUNK THREADS=$THREADS START=$START" | tee -a "$LOG"

while [ "$START" -le "$END" ]; do
  STOP=$((START + CHUNK - 1))
  if [ "$STOP" -gt "$END" ]; then STOP="$END"; fi

  TAG=$(printf "%010d_%010d" "$START" "$STOP")
  OUT="$ROOT/chunk_$TAG"

  # If this chunk already finished, skip it safely.
  if [ -f "$OUT/summary.json" ]; then
    echo "Skipping completed $START..$STOP" | tee -a "$LOG"
  else
    echo "Running $START..$STOP at $(date)" | tee -a "$LOG"
    ./collatz3_scan \
      --start "$START" \
      --end "$STOP" \
      --threads "$THREADS" \
      --out "$OUT" \
      --paths records \
      --progress "$PROGRESS" 2>&1 | tee -a "$LOG"
  fi

  START=$((STOP + 1))
  printf "%s\n" "$START" > "$STATE"
  sync
done

echo "=== all chunks complete $(date) ===" | tee -a "$LOG"
echo "Chunk summaries are under: $ROOT/chunk_*/summary.json" | tee -a "$LOG"
