# 4^r-Scaled Ternary (4k-1(2))/3 Collatz-Type Map

This archive accompanies Farhad Banazadeh's paper on the exact 4^r-scaled family of the ternary `(4k-1(2))/3` Collatz-type map.

## Main identity

For `S = {y > 0 : 3 does not divide y}` and `S_r = 4^r S`, define

- `M_0(y) = 4y - rho(y)`, where `rho(y) = y mod 3 in {1,2}`;
- `T_0(y) = M_0(y) / 3^v3(M_0(y))`;
- `M_r(x) = 4x - 4^r rho(x)` on `S_r`;
- `T_r(x) = M_r(x) / 3^v3(M_r(x))`.

The paper proves algebraically

`T_r(4^r y) = 4^r T_0(y)`

and therefore `T_r^j(4^r y) = 4^r T_0^j(y)` for every `j >= 0`.

## Files

- `A_4r_Scaled_Family_Ternary_4k_minus_1_2_over_3.pdf` - compiled paper.
- `A_4r_Scaled_Family_Ternary_4k_minus_1_2_over_3.tex` - LaTeX source.
- `verify_4r_conjugacy.py` - exact finite consistency checker for the proved identities.
- `scaling_rules.json` - machine-readable definitions and identities.
- `base_GLOBAL_summary_10e9.json` - inherited summary of the base 10^9 computation; this is reference data, not a new scaled-family run.
- `VERIFICATION.txt` - output of the included verifier.
- `SHA256SUMS.txt` - checksums.

## Base paper

Farhad Banazadeh (2026), *A Ternary (4k-1(2))/3 Collatz-Type Map: Complete 3-Adic Reduction, Algebraic Cycle Analysis, and Exhaustive Computational Verification up to 10^9*.

DOI: https://doi.org/10.5281/zenodo.22662980

## Important interpretation

The scaled-family conjugacy is an exact theorem. The global statement that every positive base orbit enters one of the three known positive attractors remains a conjecture. The 10^9 numerical data in this archive are inherited from the base computation and are not presented as a new billion-scale computation of every scaled level.

Author: Farhad Banazadeh  
Email: fn.bana@hotmail.com  
ORCID: 0009-0004-7023-0298
