#!/usr/bin/env python3
"""Exact finite checker for the 4^r-scaled ternary (4k-1(2))/3 map.
This script verifies identities that are proved algebraically in the paper.
"""
import argparse


def v3(n: int) -> int:
    if n == 0:
        raise ValueError("v3(0) is not used")
    k = 0
    while n % 3 == 0:
        n //= 3
        k += 1
    return k


def rho(n: int) -> int:
    z = n % 3
    if z not in (1, 2):
        raise ValueError("state must not be divisible by 3")
    return z


def M0(y: int) -> int:
    return 4 * y - rho(y)


def T0(y: int) -> int:
    m = M0(y)
    return m // (3 ** v3(m))


def Mr(x: int, r: int) -> int:
    scale = 4 ** r
    if x % scale != 0:
        raise ValueError("x must lie in S_r = 4^r S")
    return 4 * x - scale * rho(x)


def Tr(x: int, r: int) -> int:
    m = Mr(x, r)
    return m // (3 ** v3(m))


def verify(max_r: int, max_y: int, iterates: int) -> int:
    checked = 0
    for r in range(max_r + 1):
        s = 4 ** r
        for y in range(1, max_y + 1):
            if y % 3 == 0:
                continue
            x = s * y
            assert rho(x) == rho(y)
            assert Mr(x, r) == s * M0(y)
            assert v3(Mr(x, r)) == v3(M0(y))
            assert Tr(x, r) == s * T0(y)
            yy, xx = y, x
            for _ in range(iterates):
                assert xx == s * yy
                yy = T0(yy)
                xx = Tr(xx, r)
            assert xx == s * yy
            checked += 1
    print(f"PASS: {checked:,} (r,y) pairs checked; r=0..{max_r}, y<= {max_y:,}, iterates={iterates}")
    return checked


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--max-r", type=int, default=8)
    p.add_argument("--max-y", type=int, default=100000)
    p.add_argument("--iterates", type=int, default=50)
    a = p.parse_args()
    verify(a.max_r, a.max_y, a.iterates)
