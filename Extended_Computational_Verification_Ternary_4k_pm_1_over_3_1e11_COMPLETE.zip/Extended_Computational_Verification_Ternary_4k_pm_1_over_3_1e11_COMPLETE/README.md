# Extended Computational Verification of the Ternary (4k±1)/3 Collatz-Type Map up to 10^11

## Purpose

This archive accompanies the paper:

**Extended Computational Verification of the Ternary (4k±1)/3 Collatz-Type Map up to 10^11: A 128-Bit Exhaustive Certification**

Author: Farhad Banazadeh  
ORCID: 0009-0004-7023-0298

The computation extends the previously verified interval [1, 10^9] to 10^11 for the map

T(k) = k/3                    if k mod 3 = 0
T(k) = (4k - 1)/3            if k mod 3 = 1
T(k) = (4k + 1)/3            if k mod 3 = 2

The earlier research entry is associated with the Zenodo records:
- https://doi.org/10.5281/zenodo.22195651
- https://doi.org/10.5281/zenodo.22195652

## Final 128-bit certificate run

Command:

```text
./ternary_v3_u128 \
  --start 1000000001 \
  --end 100000000000 \
  --threads 4 \
  --mode certificate \
  --prefix scan_1e9_to_1e11_u128
```

Final result:

- tested = 99,000,000,000
- certified = 99,000,000,000
- overflowed_u128 = 0
- elapsed = 45,956.017 s
- average rate = 2,154,233.7 starts/s
- maximum steps to base interval = 548
- record start for steps to base = 58,528,894,046
- maximum observed peak = 1,030,251,791,629,144,029,921
- peak-record start = 72,496,238,260
- peak step = 168

The certificate threshold is 10^9. In certificate mode an orbit is accepted when it first reaches a value <= 10^9, because that base interval had already been exhaustively verified to reach 1 in the earlier computation.

Combining the two finite computations therefore gives a computational verification that every start 1 <= n <= 10^11 reaches 1. This is a finite computational result, not a proof for all positive integers.

## 64-bit comparison run

The archive also retains the earlier 64-bit pthread source and its summary files. That run tested the same extension interval but reported 158 unresolved trajectories because the evolving orbit exceeded the unsigned 64-bit range. These were arithmetic overflows, not counterexamples. The 128-bit run resolves the entire interval with zero 128-bit overflow.

## Files

- `Extended_Computational_Verification_Ternary_4k_pm_1_over_3_1e11.pdf` - paper PDF
- `Extended_Computational_Verification_Ternary_4k_pm_1_over_3_1e11.tex` - LaTeX source
- `ternary_v3_u128.c` - final unsigned-128 certificate implementation
- `scan_1e9_to_1e11_u128_summary.txt` - final plain-text summary
- `scan_1e9_to_1e11_u128_summary.csv` - final CSV summary
- `scan_1e9_to_1e11_u128_summary.json` - final JSON summary
- `scan_1e9_to_1e11_u128_u128_overflow_starts.txt` - list of genuine u128-overflow starts; empty in the completed run
- `ternary_v2_pthread.c` - earlier unsigned-64 implementation retained for audit comparison
- `scan_1e9_to_1e11_summary.txt` - 64-bit run summary
- `scan_1e9_to_1e11_summary.csv` - 64-bit run summary
- `scan_1e9_to_1e11_summary.json` - 64-bit run summary
- `SHA256SUMS.txt` - SHA-256 hashes of archive contents

## Compilation

A compatible Clang/GCC toolchain supporting `unsigned __int128` is required.

```text
clang -O3 -march=native -std=c11 -pthread ternary_v3_u128.c -o ternary_v3_u128
```

## Integrity and scope

The final 128-bit summary files should agree on the interval, tested/certified totals, zero-overflow result, and record values. The empty overflow-start file is consistent with `overflowed_u128=0`.

The computation is exhaustive only for the explicitly stated finite range. No global convergence proof is claimed.

Copyright © 2026 Farhad Banazadeh. All rights reserved.
