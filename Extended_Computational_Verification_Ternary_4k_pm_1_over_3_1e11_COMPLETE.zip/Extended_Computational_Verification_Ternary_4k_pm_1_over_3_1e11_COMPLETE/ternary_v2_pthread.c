
/*
  ternary_v2_pthread.c
  Exhaustive scan for Banazadeh ternary (4k±1)/3 map.

  T(k) =
    k/3          if k % 3 == 0
    (4k-1)/3     if k % 3 == 1
    (4k+1)/3     if k % 3 == 2

  Two modes:
    certificate (default): stop once orbit reaches <= base (default 1e9),
      relying on the previously exhaustive verification of [1, base].
    full: continue every orbit all the way to 1, yielding exact stopping time/peak
      for the new interval.

  Portable pthread implementation for older macOS/Clang.
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#include <errno.h>

typedef uint64_t u64;
typedef __uint128_t u128;

typedef struct {
    u64 tested, certified, reached_one, overflowed;
    u64 branch0, branch1, branch2;
    u64 max_steps, max_steps_start, max_steps_peak;
    u64 max_peak, max_peak_start, max_peak_step, max_peak_steps;
} Stats;

typedef struct {
    u64 lo, hi, base;
    int full_mode;
    Stats s;
} Job;

static inline double wall_time(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + 1e-9*(double)ts.tv_nsec;
}

static inline u64 step_T(u64 k, int *branch, int *overflow) {
    const u64 r = k % 3ULL;
    *branch = (int)r;
    if (r == 0) return k / 3ULL;

    u128 x;
    if (r == 1) x = (u128)4 * (u128)k - 1;
    else        x = (u128)4 * (u128)k + 1;
    x /= 3;

    if (x > (u128)UINT64_MAX) {
        *overflow = 1;
        return 0;
    }
    return (u64)x;
}

static void *worker(void *arg) {
    Job *j = (Job*)arg;
    Stats s = {0};

    for (u64 n=j->lo; n<=j->hi; ++n) {
        u64 k=n, peak=n, peak_step=0, steps=0;
        int ov=0;

        const u64 threshold = j->full_mode ? 1ULL : j->base;

        while (k > threshold) {
            int b=0;
            u64 nx = step_T(k, &b, &ov);
            if (ov) break;

            if (b==0) ++s.branch0;
            else if (b==1) ++s.branch1;
            else ++s.branch2;

            ++steps;
            k=nx;
            if (k > peak) { peak=k; peak_step=steps; }
        }

        ++s.tested;
        if (ov) {
            ++s.overflowed;
        } else {
            if (j->full_mode) {
                if (k==1) { ++s.reached_one; ++s.certified; }
            } else {
                if (k<=j->base) ++s.certified;
                if (k==1) ++s.reached_one;
            }

            if (steps > s.max_steps) {
                s.max_steps=steps;
                s.max_steps_start=n;
                s.max_steps_peak=peak;
            }
            if (peak > s.max_peak) {
                s.max_peak=peak;
                s.max_peak_start=n;
                s.max_peak_step=peak_step;
                s.max_peak_steps=steps;
            }
        }

        if (n == UINT64_MAX) break;
    }

    j->s=s;
    return NULL;
}

static void merge(Stats *a, const Stats *b) {
    a->tested += b->tested;
    a->certified += b->certified;
    a->reached_one += b->reached_one;
    a->overflowed += b->overflowed;
    a->branch0 += b->branch0;
    a->branch1 += b->branch1;
    a->branch2 += b->branch2;

    if (b->max_steps > a->max_steps) {
        a->max_steps=b->max_steps;
        a->max_steps_start=b->max_steps_start;
        a->max_steps_peak=b->max_steps_peak;
    }
    if (b->max_peak > a->max_peak) {
        a->max_peak=b->max_peak;
        a->max_peak_start=b->max_peak_start;
        a->max_peak_step=b->max_peak_step;
        a->max_peak_steps=b->max_peak_steps;
    }
}

static void usage(const char *p) {
    fprintf(stderr,
      "Usage: %s [--start N] [--end N] [--base N] [--threads N]\\n"
      "          [--mode certificate|full] [--prefix NAME]\\n", p);
}

int main(int argc, char **argv) {
    u64 start=1000000001ULL;
    u64 end=100000000000ULL;
    u64 base=1000000000ULL;
    int threads=2;
    int full_mode=0;
    const char *prefix="ternary_v2";

    for (int i=1;i<argc;i++) {
        if (!strcmp(argv[i],"--start") && i+1<argc) start=strtoull(argv[++i],0,10);
        else if (!strcmp(argv[i],"--end") && i+1<argc) end=strtoull(argv[++i],0,10);
        else if (!strcmp(argv[i],"--base") && i+1<argc) base=strtoull(argv[++i],0,10);
        else if (!strcmp(argv[i],"--threads") && i+1<argc) threads=atoi(argv[++i]);
        else if (!strcmp(argv[i],"--prefix") && i+1<argc) prefix=argv[++i];
        else if (!strcmp(argv[i],"--mode") && i+1<argc) {
            const char *m=argv[++i];
            if (!strcmp(m,"certificate")) full_mode=0;
            else if (!strcmp(m,"full")) full_mode=1;
            else { usage(argv[0]); return 2; }
        } else { usage(argv[0]); return 2; }
    }

    if (start>end || threads<1 || threads>64) {
        usage(argv[0]); return 2;
    }

    const u64 total_n=end-start+1;
    if ((u64)threads > total_n) threads=(int)total_n;

    pthread_t *tid=(pthread_t*)calloc((size_t)threads,sizeof(*tid));
    Job *jobs=(Job*)calloc((size_t)threads,sizeof(*jobs));
    if (!tid || !jobs) { fprintf(stderr,"allocation failure\n"); return 1; }

    const u64 q=total_n/(u64)threads;
    const u64 rem=total_n%(u64)threads;
    u64 cur=start;

    double t0=wall_time();

    for (int t=0;t<threads;t++) {
        u64 len=q + ((u64)t<rem ? 1ULL:0ULL);
        jobs[t].lo=cur;
        jobs[t].hi=cur+len-1;
        jobs[t].base=base;
        jobs[t].full_mode=full_mode;
        cur += len;
        int rc=pthread_create(&tid[t],NULL,worker,&jobs[t]);
        if (rc) {
            fprintf(stderr,"pthread_create failed: %s\n",strerror(rc));
            return 1;
        }
    }

    Stats all={0};
    for (int t=0;t<threads;t++) {
        pthread_join(tid[t],NULL);
        merge(&all,&jobs[t].s);
    }

    double elapsed=wall_time()-t0;
    double rate=elapsed>0 ? (double)all.tested/elapsed : 0.0;

    char fn[1024];

    snprintf(fn,sizeof(fn),"%s_summary.txt",prefix);
    FILE *f=fopen(fn,"w");
    if (!f) { perror(fn); return 1; }

    fprintf(f,"Banazadeh ternary (4k±1)/3 V2 exhaustive scan\n");
    fprintf(f,"mode=%s\n", full_mode ? "full" : "certificate");
    fprintf(f,"start=%" PRIu64 "\nend=%" PRIu64 "\nbase=%" PRIu64 "\nthreads=%d\n",
            start,end,base,threads);
    fprintf(f,"tested=%" PRIu64 "\ncertified=%" PRIu64 "\nreached_one=%" PRIu64 "\noverflowed=%" PRIu64 "\n",
            all.tested,all.certified,all.reached_one,all.overflowed);
    fprintf(f,"elapsed_seconds=%.6f\nrate_per_second=%.3f\n",elapsed,rate);
    fprintf(f,"branch0_div3=%" PRIu64 "\nbranch1_minus=%" PRIu64 "\nbranch2_plus=%" PRIu64 "\n",
            all.branch0,all.branch1,all.branch2);
    fprintf(f,"%s=%" PRIu64 "\nmax_steps_start=%" PRIu64 "\nmax_steps_peak=%" PRIu64 "\n",
            full_mode ? "max_stopping_time" : "max_steps_to_base",
            all.max_steps,all.max_steps_start,all.max_steps_peak);
    fprintf(f,"max_peak=%" PRIu64 "\nmax_peak_start=%" PRIu64 "\nmax_peak_step=%" PRIu64 "\nmax_peak_orbit_steps_scanned=%" PRIu64 "\n",
            all.max_peak,all.max_peak_start,all.max_peak_step,all.max_peak_steps);
    fclose(f);

    snprintf(fn,sizeof(fn),"%s_summary.csv",prefix);
    f=fopen(fn,"w");
    if (!f) { perror(fn); return 1; }
    fprintf(f,"mode,start,end,base,threads,tested,certified,reached_one,overflowed,elapsed_seconds,rate_per_second,branch0_div3,branch1_minus,branch2_plus,max_steps,max_steps_start,max_steps_peak,max_peak,max_peak_start,max_peak_step,max_peak_orbit_steps_scanned\n");
    fprintf(f,"%s,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%d,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%.6f,%.3f,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 "\n",
            full_mode?"full":"certificate",start,end,base,threads,all.tested,all.certified,all.reached_one,all.overflowed,
            elapsed,rate,all.branch0,all.branch1,all.branch2,all.max_steps,all.max_steps_start,all.max_steps_peak,
            all.max_peak,all.max_peak_start,all.max_peak_step,all.max_peak_steps);
    fclose(f);

    snprintf(fn,sizeof(fn),"%s_summary.json",prefix);
    f=fopen(fn,"w");
    if (!f) { perror(fn); return 1; }
    fprintf(f,
      "{\n"
      "  \"map\": \"k/3; (4k-1)/3; (4k+1)/3 by residue mod 3\",\n"
      "  \"mode\": \"%s\",\n"
      "  \"start\": %" PRIu64 ",\n"
      "  \"end\": %" PRIu64 ",\n"
      "  \"base\": %" PRIu64 ",\n"
      "  \"threads\": %d,\n"
      "  \"tested\": %" PRIu64 ",\n"
      "  \"certified\": %" PRIu64 ",\n"
      "  \"reached_one\": %" PRIu64 ",\n"
      "  \"overflowed\": %" PRIu64 ",\n"
      "  \"elapsed_seconds\": %.6f,\n"
      "  \"rate_per_second\": %.3f,\n"
      "  \"branch_counts\": {\"div3\": %" PRIu64 ", \"minus\": %" PRIu64 ", \"plus\": %" PRIu64 "},\n"
      "  \"max_steps\": %" PRIu64 ",\n"
      "  \"max_steps_start\": %" PRIu64 ",\n"
      "  \"max_steps_peak\": %" PRIu64 ",\n"
      "  \"max_peak\": %" PRIu64 ",\n"
      "  \"max_peak_start\": %" PRIu64 ",\n"
      "  \"max_peak_step\": %" PRIu64 ",\n"
      "  \"max_peak_orbit_steps_scanned\": %" PRIu64 "\n"
      "}\n",
      full_mode?"full":"certificate",start,end,base,threads,all.tested,all.certified,all.reached_one,all.overflowed,
      elapsed,rate,all.branch0,all.branch1,all.branch2,
      all.max_steps,all.max_steps_start,all.max_steps_peak,
      all.max_peak,all.max_peak_start,all.max_peak_step,all.max_peak_steps);
    fclose(f);

    printf("Done. mode=%s tested=%" PRIu64 " certified=%" PRIu64 " overflowed=%" PRIu64
           " elapsed=%.3fs rate=%.1f/s\n",
           full_mode?"full":"certificate",all.tested,all.certified,all.overflowed,elapsed,rate);
    printf("%s=%" PRIu64 " start=%" PRIu64 "\n",
           full_mode?"max_stopping_time":"max_steps_to_base",all.max_steps,all.max_steps_start);
    printf("max_peak=%" PRIu64 " start=%" PRIu64 " step=%" PRIu64 "\n",
           all.max_peak,all.max_peak_start,all.max_peak_step);

    free(tid); free(jobs);
    return all.overflowed ? 3 : 0;
}
