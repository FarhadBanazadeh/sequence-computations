# Full computational archive for the ternary (4k ± 1)/3 study

This directory is the complete publication-oriented computational archive for the deterministic ternary map

F(n) = n/3 if n ≡ 0 (mod 3), (4n-1)/3 if n ≡ 1 (mod 3), and (4n+1)/3 if n ≡ 2 (mod 3).

## Certified finite domain

The fresh production computation covers every admissible accelerated start `3 ∤ n` in `1 <= n <= 100000000000`:

- admissible starts: `66,666,666,667`
- certified: `66,666,666,667`
- unresolved: `0`
- clean aggregate: `true`

The computation has two explicitly distinct phases:

1. `1 <= n <= 10^9`: fresh full trajectories to the fixed point 1.
2. `10^9 < n <= 10^11`: fresh certificate trajectories to the freshly verified base interval `[1,10^9]`.

The second phase is a convergence certificate, but its step/sign/valuation totals are certificate-segment totals rather than redundant full-to-1 totals. See `DATA_SCOPE.md`.

## Release identity

- scanner version: `pm-accelerated-v4.0-freshcert`
- source + exact-certificate SHA-256: `e9f810e1b844f9f2153d5d13d42cbe6161b4367f3d6153d645133004e992d216`
- original received production ZIP SHA-256: `ae8313f37b1ff583f764f687bd123221e424a0b5237deca2ceee295a2578f4da`

The root `PROJECT_SHA256SUMS.txt` in this archival copy was regenerated after the production run because the original root copy contained one stale pre-run hash for `BARRIER_EXACT_CERTIFICATE.json`. No source file, certificate, checkpoint, result, trajectory, audit output, or scientific datum was changed. The snapshot manifest stored inside `results_fresh_1e11/` and the final recursive result manifest were already correct.

## Contents retained

This archive intentionally keeps the complete scientific/audit record rather than a minimal subset, including:

- scanner C source and generated exact-certificate headers;
- Python aggregation, reference, certificate-generation, comparison, and replay tools;
- validation scripts and validation evidence;
- exact barrier and theory-cutoff certificates;
- compiled production/audit binaries copied into the result archive;
- all 10 fresh-base chunk checkpoints and anomaly files;
- all 990 extension-certificate chunk checkpoints and anomaly files;
- base, extension, combined, discrepancy, and replay audit logs;
- complete finite-discrepancy cases file;
- global summary JSON/TXT files;
- all arbitrary-precision record trajectory TSV files;
- recursive SHA-256 manifests.

Only non-scientific cache/desktop metadata such as Python `__pycache__` or `.DS_Store` is excluded from this archival copy.

## Primary result files

Start with:

- `results_fresh_1e11/COMBINED_SUMMARY.json`
- `results_fresh_1e11/COMBINED_SUMMARY.txt`
- `results_fresh_1e11/RUN_METADATA.txt`
- `results_fresh_1e11/RECORD_REPLAY_AUDIT.log`
- `results_fresh_1e11/DISCREPANCY50_AUDIT.log`
- `results_fresh_1e11/FINAL_SHA256SUMS.txt`
- `DATA_SCOPE.md`

## Integrity verification

The result-level manifest can be checked from the project root with a standard SHA-256 utility after accounting for its relative path format. The publication archive also includes `ZENODO_FULL_SHA256SUMS.txt`, generated last, which covers every file in the final Zenodo directory except itself.

## Paper and post-scan theory certificates

The final archive includes `paper/Ternary_4k_pm_1_over_3_Manuscript_v3.tex` and `theory_certificates/`. The PDF is intentionally omitted from this Zenodo package at the depositor's request; the LaTeX source is the publication manuscript included here. These additions are post-scan publication materials. They do not alter the frozen source/certificate hash of the production computation.
