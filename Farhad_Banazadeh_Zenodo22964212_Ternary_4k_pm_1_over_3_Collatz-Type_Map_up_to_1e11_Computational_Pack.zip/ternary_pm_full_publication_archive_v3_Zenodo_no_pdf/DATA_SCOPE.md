# Exact data scope and semantics

This note is part of the computational record.  Its purpose is to prevent a later paper from accidentally assigning full-orbit meaning to certificate-segment quantities.

## Domain and certification

The production command performs two fresh exhaustive phases.

### Phase A — fresh full base

`1 <= n <= 1,000,000,000`, `3 ∤ n`.

Every orbit is followed to `1`.  All phase-A stopping times, sign/valuation totals, histograms, extrema, and peaks therefore refer to complete accelerated trajectories to `1`.

### Phase B — fresh extension certificate

`1,000,000,001 <= n <= 100,000,000,000`, `3 ∤ n`.

Every orbit is followed until its first entry into `[1,10^9]`.  Since phase A freshly proves that every admissible state in that interval reaches `1`, this is an exhaustive finite certificate for the extension.

## Quantities captured exactly for every start

The archive captures or derives exactly:

- raw and admissible start counts;
- certified, overflow, invariant-failure, step-limit, and unresolved counts;
- initial sign and initial valuation distribution;
- exact first reduced descent below the original start;
- accumulated original-map step count at that reduced first descent;
- exact first descent among the individual original-map `/3` states inside an accelerated edge;
- exact first crossing of the valuation barrier `A_j > j log_3 4` within the certified barrier range;
- relative ordering and gap between first barrier and first reduced descent;
- barrier-survivor and actual-first-descent survivor counts at depths `6,10,20,25,30,40,50,100,200,500`;
- finite-discrepancy counts and explicit theory-cutoff violations;
- largest accelerated/reduced state on scanned segments;
- largest original-map intermediate state on scanned segments;
- maximum single 3-adic valuation on scanned segments;
- longest consecutive run of valuation `a=1`; if such a run begins before the certificate boundary, the extension scanner continues it beyond the boundary until it breaks;
- exact per-chunk sign/valuation joint histograms on scanned segments;
- record starts and event locations;
- exact anomaly records and source/build identity.

For extension starts, entry into the verified base is itself a strict reduced descent because the start is greater than `10^9`.  Therefore exact first-descent information cannot be lost by certificate stopping.  If the first barrier has not yet occurred at base entry, the event tail continues until it is known.  This preserves the barrier/first-descent comparison used by the paper.

## Global extrema across the complete finite domain

A state reached after an extension trajectory enters `[1,10^9]` lies on the orbit of a base state that is scanned completely in phase A.  Consequently, taking the maximum of phase-A full-orbit extrema and phase-B pre-entry extrema recovers the global maximum state and maximum valuation through the complete certified domain.  The special continuation rule for a boundary-crossing `a=1` run similarly preserves the global longest run.

## Segment totals — deliberately labelled

The following extension quantities are **certificate-segment** statistics:

- total reduced steps;
- total accumulated valuation / represented original steps;
- sign counts;
- valuation histogram;
- joint sign–valuation histogram;
- reduced/original stopping histograms.

They stop at first base entry.  The archive does **not** call these extension full-to-1 totals.  Repeating already verified base tails for each of 66 billion extension starts would add very large computational cost without strengthening the finite convergence certificate or the first-descent/barrier theorems.

The scanner still supports `full` mode if a future study deliberately wants redundant full-tail distributions for a smaller or selected domain.

## Independent post-scan audits

The production workflow also runs two inexpensive independent checks after/between the main phases:

1. `audit_discrepancy50` independently enumerates the entire explicit possible discrepancy zone through horizon 50 and writes every discrepancy start to `DISCREPANCY50_CASES.tsv`.  Its counts are compared with the production scanner aggregate.
2. `tools/replay_records.py` replays every global record start with Python arbitrary-precision integers, verifies the recorded extrema/events, checks the signed cocycle identity exactly, and emits one trajectory TSV per record start.

These post-processing steps require only record starts / the finite discrepancy zone and therefore do not require a second `10^11` scan.
