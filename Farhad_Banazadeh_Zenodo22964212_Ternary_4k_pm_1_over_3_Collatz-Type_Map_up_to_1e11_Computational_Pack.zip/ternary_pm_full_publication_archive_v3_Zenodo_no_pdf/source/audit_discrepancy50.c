/* Independent finite-horizon discrepancy enumerator for the signed ternary map.
 * Deliberately separate from the production scanner hot loop.
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include "barrier_small.h"
#include "theory_cutoffs.h"
#ifndef SOURCE_SHA256
#define SOURCE_SHA256 "unknown"
#endif

typedef unsigned __int128 u128;
static const uint32_t H[7] = {6U,10U,20U,25U,30U,40U,50U};

static int step(u128 x,u128 *y,uint32_t *v){
    unsigned r=(unsigned)(x%(u128)3);
    if(r!=1U && r!=2U) return 0;
    u128 num = (r==1U) ? 4*x-(u128)1 : 4*x+(u128)1;
    uint32_t k=0;
    do { num/=(u128)3; ++k; } while(num%(u128)3==0);
    *y=num; *v=k; return 1;
}

int main(int argc,char **argv){
    if(argc!=3){fprintf(stderr,"usage: %s MAX_START OUTPUT_TSV\n",argv[0]);return 2;}
    uint64_t maxn=strtoull(argv[1],NULL,10);
    FILE *f=fopen(argv[2],"w"); if(!f){perror("fopen");return 2;}
    fprintf(f,"start\tfirst_descent\tfirst_barrier\thorizon_mask\n");
    uint64_t counts[7]={0}, maxstart[7]={0};
    uint64_t adm=0;
    for(uint64_t n=1;n<=maxn;++n){
        if(n%3ULL==0) continue;
        ++adm;
        u128 x=(u128)n; uint64_t A=0,fd=0,bc=0;
        for(uint32_t j=1;j<=50U;++j){
            u128 y; uint32_t v;
            if(!step(x,&y,&v)){fprintf(stderr,"step failure at start=%" PRIu64 "\n",n);fclose(f);return 3;}
            A+=(uint64_t)v;
            if(!bc && A>(uint64_t)BARRIER_SMALL_FLOOR[j]) bc=j;
            if(!fd && y<(u128)n) fd=j;
            x=y;
            if(fd && bc) break;
        }
        unsigned mask=0;
        for(unsigned i=0;i<7;++i){
            int bs=(bc==0 || bc>(uint64_t)H[i]);
            int as=(fd==0 || fd>(uint64_t)H[i]);
            if(bs!=as){counts[i]++; if(n>maxstart[i])maxstart[i]=n; mask|=1U<<i;}
        }
        if(mask) fprintf(f,"%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%u\n",n,fd,bc,mask);
        if(n==UINT64_MAX) break;
    }
    if(fclose(f)!=0){perror("fclose");return 2;}
    printf("DISCREPANCY50 INDEPENDENT AUDIT\nsource_sha256=%s\nmax_start=%" PRIu64 "\nadmissible=%" PRIu64 "\n",SOURCE_SHA256,maxn,adm);
    for(unsigned i=0;i<7;++i) printf("horizon_%u_count=%" PRIu64 " horizon_%u_max_start=%" PRIu64 " cutoff=%" PRIu64 "\n",H[i],counts[i],H[i],maxstart[i],THEORY_CUTOFF[i]);
    return 0;
}
