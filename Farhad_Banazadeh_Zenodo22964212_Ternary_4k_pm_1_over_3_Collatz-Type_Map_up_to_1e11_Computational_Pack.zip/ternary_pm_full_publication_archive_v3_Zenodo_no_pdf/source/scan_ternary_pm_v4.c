/*
 * scan_ternary_pm_v4.c
 *
 * Audit-oriented exhaustive scanner for the accelerated signed ternary map
 *
 *   S = {x > 0 : 3 does not divide x}
 *   sigma(x) = +1 if x == 1 (mod 3), -1 if x == 2 (mod 3)
 *   a(x) = v_3(4x - sigma(x))
 *   T(x) = (4x - sigma(x)) / 3^a(x)
 *
 * Two exact scan modes are supported.  full follows every admissible start to 1.
 * certificate follows starts above a verified base until first entry into that
 * base, while continuing only the event tail needed to resolve first barrier and
 * a valuation-1 run crossing the certificate boundary.  This preserves exact
 * first-descent/barrier data without recomputing verified tails.
 *
 * The scanner records reduced/original segment totals, first-descent statistics,
 * exact valuation-barrier survivor counts, sign/valuation histograms, extrema,
 * overflow/anomaly counts, and restartable atomic checkpoints.
 *
 * Compile via ../build.sh so SOURCE_SHA256 and build metadata are embedded.
 *
 * Usage:
 *   ./scanner START END CHUNK THREADS RESULTS_DIR
 * Example:
 *   ./scanner 1 100000000000 100000000 4 results_full_1e11
 */

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "barrier_exact.h"
#include "barrier_small.h"
#include "theory_cutoffs.h"

typedef unsigned __int128 u128;

#ifndef SOURCE_SHA256
#define SOURCE_SHA256 "UNSET"
#endif
#ifndef BUILD_CC
#define BUILD_CC "UNSET"
#endif
#ifndef BUILD_CFLAGS
#define BUILD_CFLAGS "UNSET"
#endif

#define SCANNER_VERSION "pm-accelerated-v4.0-freshcert"
#define FORMAT_VERSION 4
#define WORK_BLOCK 65536ULL
#define VMAX 80U
#define DESC_HIST_MAX 4096U
#define STOP_HIST_MAX 8192U
#define MAX_REDUCED_STEPS 10000000ULL
_Static_assert(MAX_REDUCED_STEPS <= BARRIER_CERT_MAX_J, "barrier certificate must cover the step limit");
#define NH 10
#define NANOMALY 16
_Static_assert(THEORY_CUTOFF_COUNT == NH, "theory cutoff count mismatch");

static const uint32_t HORIZONS[NH] = {6,10,20,25,30,40,50,100,200,500};
/* THEORY_CUTOFF is auto-generated from the exact finite-discrepancy bound.
 * A zero entry means the exact cutoff exceeds uint64_t (and far exceeds 1e11). */

typedef struct {
    uint64_t start;
    uint64_t reduced_step;
    uint64_t original_step;
    u128 state;
    int sign;
    uint32_t valuation;
    char reason[48];
} Anomaly;

typedef struct {
    uint64_t raw_count;
    uint64_t admissible;
    uint64_t excluded_mult3;

    uint64_t certified_to1;
    uint64_t unknown_cycle;
    uint64_t overflow;
    uint64_t invariant_fail;
    uint64_t step_limit;
    uint64_t barrier_certificate_exceeded;

    u128 total_reduced_steps;
    u128 total_original_steps;

    uint64_t sign_plus;
    uint64_t sign_minus;
    uint64_t val_hist[VMAX+1];
    uint64_t joint_plus[VMAX+1];
    uint64_t joint_minus[VMAX+1];
    uint64_t initial_val_hist[VMAX+1];
    uint64_t initial_plus;
    uint64_t initial_minus;

    /* Distribution-preserving counters.  The final bin (MAX+1) is overflow. */
    uint64_t first_reduced_descent_hist[DESC_HIST_MAX+2];
    uint64_t first_reduced_descent_original_hist[STOP_HIST_MAX+2];
    uint64_t first_original_descent_hist[STOP_HIST_MAX+2];
    uint64_t first_barrier_hist[DESC_HIST_MAX+2];
    uint64_t total_reduced_steps_hist[STOP_HIST_MAX+2];
    uint64_t total_original_steps_hist[STOP_HIST_MAX+2];

    uint64_t first_descent_found;
    uint64_t no_first_descent_certified;
    uint64_t no_first_descent_unresolved;
    u128 total_first_descent_reduced_steps;
    u128 total_first_descent_original_steps;
    uint64_t first_descent_above_barrier;
    uint64_t first_descent_below_barrier;
    uint64_t first_descent_barrier_unknown;
    uint64_t barrier_cross_pre_descent_no_descent;

    uint64_t first_barrier_found;
    uint64_t no_first_barrier_certified;
    uint64_t no_first_barrier_unresolved;
    u128 total_first_barrier_edges;
    uint64_t max_first_barrier_edges;
    uint64_t max_first_barrier_start;
    uint64_t barrier_before_reduced_descent;
    uint64_t reduced_descent_before_barrier;
    uint64_t barrier_descent_same_edge;
    uint64_t max_barrier_to_descent_gap;
    uint64_t max_barrier_to_descent_gap_start;
    uint64_t max_descent_to_barrier_gap;
    uint64_t max_descent_to_barrier_gap_start;

    uint64_t barrier_survive[NH];
    uint64_t actual_survive[NH];
    uint64_t discrepancy[NH];
    uint64_t discrepancy_below_barrier_descent[NH];
    uint64_t discrepancy_above_barrier_nondesc[NH];
    uint64_t discrepancy_max_start[NH];
    uint64_t theory_cutoff_violations[NH];

    uint64_t max_reduced_steps;
    uint64_t max_reduced_steps_start;
    uint64_t max_original_steps;
    uint64_t max_original_steps_start;

    uint64_t max_first_descent_reduced;
    uint64_t max_first_descent_reduced_start;
    uint64_t max_first_descent_reduced_original_at_event;
    uint64_t max_first_descent_original;
    uint64_t max_first_descent_original_start;
    uint64_t max_first_descent_original_reduced_at_event;

    /* Exact first descent in the unaccelerated/original map, which may occur
     * inside an accelerated edge before its reduced endpoint descends. */
    uint64_t first_original_descent_found;
    uint64_t no_original_descent_certified;
    uint64_t no_original_descent_unresolved;
    u128 total_first_original_descent_steps;
    uint64_t max_first_original_descent;
    uint64_t max_first_original_descent_start;
    uint64_t max_first_original_descent_reduced_edge;
    u128 max_first_original_descent_state;

    uint64_t max_v1_run;
    uint64_t max_v1_run_start;
    uint64_t max_v1_run_begin_step;
    uint64_t max_v1_run_end_step;

    u128 max_reduced_state;
    uint64_t max_reduced_state_start;
    uint64_t max_reduced_state_step;
    uint64_t max_reduced_state_original_step;

    u128 max_original_state;
    uint64_t max_original_state_start;
    uint64_t max_original_state_reduced_step;
    uint64_t max_original_state_original_step;

    uint32_t max_single_valuation;
    uint64_t max_single_valuation_start;
    u128 max_single_valuation_state;
    uint64_t max_single_valuation_reduced_step;
    int max_single_valuation_sign;

    uint64_t max_discrepancy_start_any;

    uint64_t first_unknown_start;
    u128 first_unknown_state;
    uint64_t first_overflow_start;
    u128 first_overflow_state;
    uint64_t first_invariant_start;
    u128 first_invariant_state;
    uint64_t first_step_limit_start;

    Anomaly anomaly[NANOMALY];
    uint32_t anomaly_count;
} Stats;

typedef struct {
    uint64_t lo, hi, base;
    int certificate_mode;
    _Atomic uint64_t next_raw;
    Stats *locals;
} ChunkCtx;

typedef struct { ChunkCtx *ctx; Stats *s; } WorkerArg;

static inline u128 u128_max(void) { return ~(u128)0; }

static void u128_to_str(u128 x, char *buf, size_t n) {
    char tmp[64]; size_t i=0,j=0;
    if (!n) return;
    if (!x) { if(n>1){buf[0]='0';buf[1]='\0';} return; }
    while (x && i<sizeof(tmp)) { tmp[i++]=(char)('0'+(unsigned)(x%10)); x/=10; }
    while (i && j+1<n) buf[j++]=tmp[--i];
    buf[j]='\0';
}

static inline int sign_from_mod3_u128(u128 x) {
    unsigned r=(unsigned)(x%(u128)3);
    return r==1 ? +1 : (r==2 ? -1 : 0);
}

/*
 * Exact accelerated step, optimized for the production hot path.
 * Returns the accelerated endpoint, first unaccelerated /3 image, sign,
 * and valuation.  The first /3 division is performed exactly once.
 * If need_original_descent is true, the already-required division chain is
 * also used to locate the earliest original-map state below the start,
 * avoiding a second pass over the same powers of 3.
 */
static inline int map_step(u128 x, u128 start_value, int need_original_descent,
                           u128 *next, u128 *original_first,
                           int *sign, uint32_t *v,
                           uint32_t *original_descent_offset,
                           u128 *original_descent_state) {
    *original_descent_offset=0;
    *original_descent_state=0;
    if (x <= (u128)UINT64_MAX) {
        uint64_t a=(uint64_t)x;
        unsigned r=(unsigned)(a%3ULL);
        uint64_t num;
        int sg;
        if (r==1U && a<=UINT64_MAX/4ULL+1ULL) { num=4ULL*a-1ULL; sg=+1; }
        else if (r==2U && a<=UINT64_MAX/4ULL) { num=4ULL*a+1ULL; sg=-1; }
        else if (r==0U) return 0;
        else goto wide_path;

        uint64_t y=num/3ULL;
        uint64_t first=y;
        uint32_t k=1;
        if (need_original_descent && (u128)y < start_value) {
            *original_descent_offset=1; *original_descent_state=(u128)y;
        }
        while (y%3ULL==0ULL) {
            y/=3ULL; ++k;
            if (need_original_descent && *original_descent_offset==0 && (u128)y < start_value) {
                *original_descent_offset=k; *original_descent_state=(u128)y;
            }
        }
        *next=(u128)y; *original_first=(u128)first; *sign=sg; *v=k; return 1;
    }

wide_path:
    {
        int sg=sign_from_mod3_u128(x);
        if (!sg) return 0;
        u128 num;
        const u128 mx=u128_max();
        if (sg>0) {
            if (x > mx/4 + 1) return 0;
            num=4*x-(u128)1;
        } else {
            if (x > mx/4) return 0;
            num=4*x+(u128)1;
        }
        u128 y=num/(u128)3;
        u128 first=y;
        uint32_t k=1;
        if (need_original_descent && y < start_value) {
            *original_descent_offset=1; *original_descent_state=y;
        }
        while (y%(u128)3==0) {
            y/=(u128)3; ++k;
            if (need_original_descent && *original_descent_offset==0 && y < start_value) {
                *original_descent_offset=k; *original_descent_state=y;
            }
        }
        *next=y; *original_first=first; *sign=sg; *v=k; return 1;
    }
}

static inline int barrier_crossed(uint64_t j, uint64_t A, int *known) {
    if (j<=BARRIER_SMALL_MAX_J) {
        *known=1;
        return A>(uint64_t)BARRIER_SMALL_FLOOR[j];
    }
    if (j<=BARRIER_CERT_MAX_J) {
        uint64_t fl=(j*ALPHA_LO_P)/ALPHA_LO_Q;
        *known=1;
        return A>fl;
    }
    *known=0;
    return 0;
}

static inline int better_u64(uint64_t v,uint64_t start,uint64_t oldv,uint64_t oldstart) {
    return v>oldv || (v==oldv && v!=0 && (oldstart==0 || start<oldstart));
}
static inline int better_u128(u128 v,uint64_t start,u128 oldv,uint64_t oldstart) {
    return v>oldv || (v==oldv && v!=0 && (oldstart==0 || start<oldstart));
}

static inline void hist_inc(uint64_t *h,uint64_t cap,uint64_t v) {
    ++h[v<=cap ? v : cap+1];
}

static void add_anomaly(Stats *s,uint64_t start,uint64_t rstep,uint64_t ostep,
                        u128 state,int sign,uint32_t val,const char *reason) {
    if (s->anomaly_count < NANOMALY) {
        Anomaly *a=&s->anomaly[s->anomaly_count++];
        a->start=start; a->reduced_step=rstep; a->original_step=ostep;
        a->state=state; a->sign=sign; a->valuation=val;
        snprintf(a->reason,sizeof(a->reason),"%s",reason);
    }
}

#ifdef FULL_INVARIANTS
static inline int check_mod4(int sign,uint32_t a,u128 y) {
    unsigned m=(unsigned)(y%(u128)4);
    int chi = (m==1) ? +1 : (m==3 ? -1 : 0);
    if (!chi) return 0;
    int rhs = (a&1U) ? chi : -chi; /* (-1)^(a+1) chi */
    return sign==rhs;
}

static inline int check_mod8(int sign,uint32_t a,u128 y) {
    unsigned got=(unsigned)(y%(u128)8);
    unsigned expected;
    if (sign>0) expected=(a&1U)?1U:3U;
    else expected=(a&1U)?7U:5U;
    return got==expected;
}

#endif

/* Survivor marginals are reconstructed exactly from first-event histograms
 * once per chunk. Only true barrier/descent discrepancies need horizon work. */
static inline void finalize_discrepancy(Stats *s,uint64_t start,uint64_t fd_j,uint64_t bc_j) {
    if (fd_j==bc_j) return;
    for (int h=0;h<NH;++h) {
        uint64_t m=HORIZONS[h];
        int bs=(bc_j==0 || bc_j>m);
        int as=(fd_j==0 || fd_j>m);
        if (bs!=as) {
            ++s->discrepancy[h];
            if (!as && bs) ++s->discrepancy_below_barrier_descent[h];
            if (as && !bs) ++s->discrepancy_above_barrier_nondesc[h];
            if (start > s->discrepancy_max_start[h]) s->discrepancy_max_start[h]=start;
            if (start > s->max_discrepancy_start_any) s->max_discrepancy_start_any=start;
            if (THEORY_CUTOFF[h] && start>=THEORY_CUTOFF[h]) ++s->theory_cutoff_violations[h];
        }
    }
}

static void derive_chunk_stats(Stats *s) {
    s->sign_plus=0; s->sign_minus=0;
    s->total_reduced_steps=0; s->total_original_steps=0;
    for (unsigned k=1;k<=VMAX;++k) {
        s->val_hist[k]=s->joint_plus[k]+s->joint_minus[k];
        s->sign_plus += s->joint_plus[k];
        s->sign_minus += s->joint_minus[k];
        s->total_original_steps += (u128)k*(u128)s->val_hist[k];
    }
    s->total_reduced_steps=(u128)(s->sign_plus+s->sign_minus);


    for (int h=0;h<NH;++h) {
        uint64_t m=HORIZONS[h], fd_le=0, bc_le=0;
        for (uint64_t j=1;j<=m;++j) {
            fd_le += s->first_reduced_descent_hist[j];
            bc_le += s->first_barrier_hist[j];
        }
        s->actual_survive[h]=s->admissible-fd_le;
        s->barrier_survive[h]=s->admissible-bc_le;
    }
}

static inline void finish_certified(Stats *s,uint64_t start,uint64_t steps,uint64_t A,
                                    uint64_t fd_j,uint64_t fd_A,
                                    uint64_t ofd_A,uint64_t ofd_j,u128 ofd_state,
                                    uint64_t bc_j) {
    ++s->certified_to1;
    hist_inc(s->total_reduced_steps_hist,STOP_HIST_MAX,steps);
    hist_inc(s->total_original_steps_hist,STOP_HIST_MAX,A);

    if (better_u64(steps,start,s->max_reduced_steps,s->max_reduced_steps_start)) {
        s->max_reduced_steps=steps; s->max_reduced_steps_start=start;
    }
    if (better_u64(A,start,s->max_original_steps,s->max_original_steps_start)) {
        s->max_original_steps=A; s->max_original_steps_start=start;
    }

    if (fd_j) {
        ++s->first_descent_found;
        s->total_first_descent_reduced_steps += (u128)fd_j;
        s->total_first_descent_original_steps += (u128)fd_A;
        hist_inc(s->first_reduced_descent_hist,DESC_HIST_MAX,fd_j);
        hist_inc(s->first_reduced_descent_original_hist,STOP_HIST_MAX,fd_A);
        if (better_u64(fd_j,start,s->max_first_descent_reduced,s->max_first_descent_reduced_start)) {
            s->max_first_descent_reduced=fd_j; s->max_first_descent_reduced_start=start;
            s->max_first_descent_reduced_original_at_event=fd_A;
        }
        if (better_u64(fd_A,start,s->max_first_descent_original,s->max_first_descent_original_start)) {
            s->max_first_descent_original=fd_A; s->max_first_descent_original_start=start;
            s->max_first_descent_original_reduced_at_event=fd_j;
        }
    } else {
        ++s->no_first_descent_certified;
    }

    if (ofd_A) {
        ++s->first_original_descent_found;
        s->total_first_original_descent_steps += (u128)ofd_A;
        hist_inc(s->first_original_descent_hist,STOP_HIST_MAX,ofd_A);
        if (better_u64(ofd_A,start,s->max_first_original_descent,s->max_first_original_descent_start)) {
            s->max_first_original_descent=ofd_A;
            s->max_first_original_descent_start=start;
            s->max_first_original_descent_reduced_edge=ofd_j;
            s->max_first_original_descent_state=ofd_state;
        }
    } else {
        ++s->no_original_descent_certified;
    }

    if (bc_j) {
        ++s->first_barrier_found;
        s->total_first_barrier_edges += (u128)bc_j;
        hist_inc(s->first_barrier_hist,DESC_HIST_MAX,bc_j);
        if (better_u64(bc_j,start,s->max_first_barrier_edges,s->max_first_barrier_start)) {
            s->max_first_barrier_edges=bc_j;
            s->max_first_barrier_start=start;
        }
    } else {
        ++s->no_first_barrier_certified;
    }

    if (fd_j && bc_j) {
        if (bc_j < fd_j) {
            ++s->barrier_before_reduced_descent;
            uint64_t gap=fd_j-bc_j;
            if (better_u64(gap,start,s->max_barrier_to_descent_gap,s->max_barrier_to_descent_gap_start)) {
                s->max_barrier_to_descent_gap=gap; s->max_barrier_to_descent_gap_start=start;
            }
        } else if (fd_j < bc_j) {
            ++s->reduced_descent_before_barrier;
            uint64_t gap=bc_j-fd_j;
            if (better_u64(gap,start,s->max_descent_to_barrier_gap,s->max_descent_to_barrier_gap_start)) {
                s->max_descent_to_barrier_gap=gap; s->max_descent_to_barrier_gap_start=start;
            }
        } else {
            ++s->barrier_descent_same_edge;
        }
    } else if (fd_j) {
        ++s->reduced_descent_before_barrier;
    } else if (bc_j) {
        ++s->barrier_before_reduced_descent;
    }
}

static void finish_unresolved_common(Stats *s,uint64_t start,uint64_t steps,uint64_t A,
                                     uint64_t fd_j,uint64_t fd_A,
                                     uint64_t ofd_A,uint64_t bc_j) {
    (void)start; (void)steps; (void)A;
    s->total_reduced_steps += (u128)steps;
    s->total_original_steps += (u128)A;
    if (fd_j) {
        ++s->first_descent_found;
        s->total_first_descent_reduced_steps += (u128)fd_j;
        s->total_first_descent_original_steps += (u128)fd_A;
        hist_inc(s->first_reduced_descent_hist,DESC_HIST_MAX,fd_j);
        hist_inc(s->first_reduced_descent_original_hist,STOP_HIST_MAX,fd_A);
    } else ++s->no_first_descent_unresolved;
    if (ofd_A) {
        ++s->first_original_descent_found;
        s->total_first_original_descent_steps += (u128)ofd_A;
        hist_inc(s->first_original_descent_hist,STOP_HIST_MAX,ofd_A);
    } else ++s->no_original_descent_unresolved;
    if (bc_j) {
        ++s->first_barrier_found;
        s->total_first_barrier_edges += (u128)bc_j;
        hist_inc(s->first_barrier_hist,DESC_HIST_MAX,bc_j);
    } else ++s->no_first_barrier_unresolved;
}

static void scan_one_full(uint64_t start, Stats *s) {
    u128 x=(u128)start;
    uint64_t steps=0, A=0;
    uint64_t fd_j=0, fd_A=0;
    uint64_t ofd_A=0, ofd_j=0; u128 ofd_state=0;
    uint64_t bc_j=0;
    uint64_t cur_v1_run=0, cur_v1_begin=0;

    if (better_u128(x,start,s->max_reduced_state,s->max_reduced_state_start)) {
        s->max_reduced_state=x; s->max_reduced_state_start=start;
        s->max_reduced_state_step=0; s->max_reduced_state_original_step=0;
    }
    if (better_u128(x,start,s->max_original_state,s->max_original_state_start)) {
        s->max_original_state=x; s->max_original_state_start=start;
        s->max_original_state_reduced_step=0; s->max_original_state_original_step=0;
    }

    for (;;) {
        if (x==(u128)1) {
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_certified(s,start,steps,A,fd_j,fd_A,ofd_A,ofd_j,ofd_state,bc_j);
            return;
        }
        if (steps>=MAX_REDUCED_STEPS) {
            ++s->step_limit;
            if(!s->first_step_limit_start || start<s->first_step_limit_start) s->first_step_limit_start=start;
            add_anomaly(s,start,steps,A,x,0,0,"step_limit");
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_unresolved_common(s,start,steps,A,fd_j,fd_A,ofd_A,bc_j);
            return;
        }

        u128 y,orig1; int sign=0; uint32_t v=0;
        uint32_t od_off=0; u128 od_state=0;
        if (!map_step(x,(u128)start,!ofd_A,&y,&orig1,&sign,&v,&od_off,&od_state)) {
            ++s->overflow;
            if(!s->first_overflow_start || start<s->first_overflow_start){s->first_overflow_start=start;s->first_overflow_state=x;}
            add_anomaly(s,start,steps,A,x,sign,v,"map_overflow_or_invalid");
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_unresolved_common(s,start,steps,A,fd_j,fd_A,ofd_A,bc_j);
            return;
        }

        /* Production keeps only essentially-free structural checks here.
         * Expensive congruence audits are enabled in validation builds with
         * -DFULL_INVARIANTS=1 and are cross-checked against Python reference. */
        if (v<1 || v>VMAX || y==0) {
            ++s->invariant_fail;
            if(!s->first_invariant_start || start<s->first_invariant_start){s->first_invariant_start=start;s->first_invariant_state=x;}
            add_anomaly(s,start,steps,A,x,sign,v,"step_invariant_failed");
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_unresolved_common(s,start,steps,A,fd_j,fd_A,ofd_A,bc_j);
            return;
        }
#ifdef FULL_INVARIANTS
        {
            int mod8_ok = ((x & (u128)1) == 0) ? 1 : check_mod8(sign,v,y);
            if (y%(u128)3==0 || (y%(u128)2)==0 || !check_mod4(sign,v,y) || !mod8_ok) {
                ++s->invariant_fail;
                if(!s->first_invariant_start || start<s->first_invariant_start){s->first_invariant_start=start;s->first_invariant_state=x;}
                add_anomaly(s,start,steps,A,x,sign,v,"full_step_invariant_failed");
                finalize_discrepancy(s,start,fd_j,bc_j);
            finish_unresolved_common(s,start,steps,A,fd_j,fd_A,ofd_A,bc_j);
                return;
            }
        }
#endif

        ++steps;
        uint64_t A_before=A;
        A += (uint64_t)v;
        if (A < A_before) {
            ++s->invariant_fail;
            if(!s->first_invariant_start || start<s->first_invariant_start){s->first_invariant_start=start;s->first_invariant_state=x;}
            add_anomaly(s,start,steps,A,x,sign,v,"original_step_counter_overflow");
            finish_unresolved_common(s,start,steps,A_before,fd_j,fd_A,ofd_A,bc_j);
            return;
        }

        if (sign>0) ++s->joint_plus[v]; else ++s->joint_minus[v];
        if (steps==1) {
            if(sign>0) ++s->initial_plus; else ++s->initial_minus;
            ++s->initial_val_hist[v];
        }

        /* a=1 is exactly a local increase for x>1; retain the longest run. */
        if (v==1U) {
            if (cur_v1_run==0) cur_v1_begin=steps;
            ++cur_v1_run;
            if (cur_v1_run>s->max_v1_run ||
                (cur_v1_run==s->max_v1_run && cur_v1_run &&
                 (s->max_v1_run_start==0 || start<s->max_v1_run_start ||
                  (start==s->max_v1_run_start && cur_v1_begin<s->max_v1_run_begin_step)))) {
                s->max_v1_run=cur_v1_run; s->max_v1_run_start=start;
                s->max_v1_run_begin_step=cur_v1_begin; s->max_v1_run_end_step=steps;
            }
        } else { cur_v1_run=0; cur_v1_begin=0; }

        /* Exact original-map first descent was detected while map_step already
         * traversed the required /3 chain; no duplicate divisions are needed. */
        if (!ofd_A && od_off) {
            ofd_A=A_before+(uint64_t)od_off; ofd_j=steps; ofd_state=od_state;
        }

        if (v > s->max_single_valuation ||
            (v==s->max_single_valuation && (s->max_single_valuation_start==0 || start<s->max_single_valuation_start))) {
            s->max_single_valuation=v; s->max_single_valuation_start=start;
            s->max_single_valuation_state=x;
            s->max_single_valuation_reduced_step=steps;
            s->max_single_valuation_sign=sign;
        }

        if (better_u128(y,start,s->max_reduced_state,s->max_reduced_state_start)) {
            s->max_reduced_state=y; s->max_reduced_state_start=start;
            s->max_reduced_state_step=steps; s->max_reduced_state_original_step=A;
        }
        if (better_u128(orig1,start,s->max_original_state,s->max_original_state_start)) {
            s->max_original_state=orig1; s->max_original_state_start=start;
            s->max_original_state_reduced_step=steps;
            s->max_original_state_original_step=A_before+1;
        }

        if (!fd_j || !bc_j) {
            int bknown=0;
            int crossed=barrier_crossed(steps,A,&bknown);
            if (!bknown) {
                ++s->barrier_certificate_exceeded;
                if (steps==BARRIER_CERT_MAX_J+1)
                    add_anomaly(s,start,steps,A,x,sign,v,"barrier_certificate_exceeded");
            } else if (!bc_j && crossed) {
                bc_j=steps;
                if (!fd_j && y >= (u128)start) ++s->barrier_cross_pre_descent_no_descent;
            }

            if (!fd_j && y < (u128)start) {
                fd_j=steps; fd_A=A;
                if (bknown) {
                    if (crossed) ++s->first_descent_above_barrier;
                    else ++s->first_descent_below_barrier;
                } else ++s->first_descent_barrier_unknown;
            }
        }

        x=y;
    }
}

static void scan_one_certificate(uint64_t start, uint64_t base, Stats *s) {
    u128 x=(u128)start;
    uint64_t steps=0, A=0, seg_steps=0, seg_A=0;
    uint64_t fd_j=0, fd_A=0;
    uint64_t ofd_A=0, ofd_j=0; u128 ofd_state=0;
    uint64_t bc_j=0;
    uint64_t cur_v1_run=0, cur_v1_begin=0;
    int segment_done=0;

    if (start<=base) { add_anomaly(s,start,0,0,x,0,0,"certificate_start_not_above_base"); ++s->invariant_fail; return; }
    if (better_u128(x,start,s->max_reduced_state,s->max_reduced_state_start)) {
        s->max_reduced_state=x; s->max_reduced_state_start=start;
        s->max_reduced_state_step=0; s->max_reduced_state_original_step=0;
    }
    if (better_u128(x,start,s->max_original_state,s->max_original_state_start)) {
        s->max_original_state=x; s->max_original_state_start=start;
        s->max_original_state_reduced_step=0; s->max_original_state_original_step=0;
    }

    for (;;) {
        if (!segment_done && x <= (u128)base) {
            segment_done=1; seg_steps=steps; seg_A=A;
            /* Entry into the verified base is itself a strict reduced descent. */
            if (!fd_j) { fd_j=steps; fd_A=A; }
        }
        if (segment_done && x==(u128)1) {
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_certified(s,start,seg_steps,seg_A,fd_j,fd_A,ofd_A,ofd_j,ofd_state,bc_j);
            return;
        }
        if (segment_done && bc_j && cur_v1_run==0) {
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_certified(s,start,seg_steps,seg_A,fd_j,fd_A,ofd_A,ofd_j,ofd_state,bc_j);
            return;
        }
        if (steps>=MAX_REDUCED_STEPS) {
            ++s->step_limit;
            if(!s->first_step_limit_start || start<s->first_step_limit_start) s->first_step_limit_start=start;
            add_anomaly(s,start,steps,A,x,0,0,segment_done?"event_tail_step_limit":"certificate_step_limit");
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_unresolved_common(s,start,segment_done?seg_steps:steps,segment_done?seg_A:A,fd_j,fd_A,ofd_A,bc_j);
            return;
        }

        u128 y,orig1; int sign=0; uint32_t v=0;
        uint32_t od_off=0; u128 od_state=0;
        if (!map_step(x,(u128)start,!ofd_A,&y,&orig1,&sign,&v,&od_off,&od_state)) {
            ++s->overflow;
            if(!s->first_overflow_start || start<s->first_overflow_start){s->first_overflow_start=start;s->first_overflow_state=x;}
            add_anomaly(s,start,steps,A,x,sign,v,segment_done?"event_tail_overflow":"certificate_overflow");
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_unresolved_common(s,start,segment_done?seg_steps:steps,segment_done?seg_A:A,fd_j,fd_A,ofd_A,bc_j);
            return;
        }
        if (v<1 || v>VMAX || y==0) {
            ++s->invariant_fail;
            if(!s->first_invariant_start || start<s->first_invariant_start){s->first_invariant_start=start;s->first_invariant_state=x;}
            add_anomaly(s,start,steps,A,x,sign,v,"step_invariant_failed");
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_unresolved_common(s,start,segment_done?seg_steps:steps,segment_done?seg_A:A,fd_j,fd_A,ofd_A,bc_j);
            return;
        }
#ifdef FULL_INVARIANTS
        {
            int mod8_ok = ((x & (u128)1) == 0) ? 1 : check_mod8(sign,v,y);
            if (y%(u128)3==0 || (y%(u128)2)==0 || !check_mod4(sign,v,y) || !mod8_ok) {
                ++s->invariant_fail;
                if(!s->first_invariant_start || start<s->first_invariant_start){s->first_invariant_start=start;s->first_invariant_state=x;}
                add_anomaly(s,start,steps,A,x,sign,v,"full_step_invariant_failed");
                finalize_discrepancy(s,start,fd_j,bc_j);
                finish_unresolved_common(s,start,segment_done?seg_steps:steps,segment_done?seg_A:A,fd_j,fd_A,ofd_A,bc_j);
                return;
            }
        }
#endif
        ++steps;
        uint64_t A_before=A; A+=(uint64_t)v;
        if (A<A_before) {
            ++s->invariant_fail; add_anomaly(s,start,steps,A,x,sign,v,"original_step_counter_overflow");
            finalize_discrepancy(s,start,fd_j,bc_j);
            finish_unresolved_common(s,start,segment_done?seg_steps:steps,segment_done?seg_A:A_before,fd_j,fd_A,ofd_A,bc_j);
            return;
        }

        if (!segment_done) {
            if (sign>0) ++s->joint_plus[v]; else ++s->joint_minus[v];
            if (steps==1) { if(sign>0) ++s->initial_plus; else ++s->initial_minus; ++s->initial_val_hist[v]; }

            if (v==1U) {
                if (cur_v1_run==0) cur_v1_begin=steps;
                ++cur_v1_run;
                if (cur_v1_run>s->max_v1_run ||
                    (cur_v1_run==s->max_v1_run && cur_v1_run &&
                    (s->max_v1_run_start==0 || start<s->max_v1_run_start ||
                     (start==s->max_v1_run_start && cur_v1_begin<s->max_v1_run_begin_step)))) {
                    s->max_v1_run=cur_v1_run; s->max_v1_run_start=start;
                    s->max_v1_run_begin_step=cur_v1_begin; s->max_v1_run_end_step=steps;
                }
            } else { cur_v1_run=0; cur_v1_begin=0; }

            if (v > s->max_single_valuation ||
                (v==s->max_single_valuation && (s->max_single_valuation_start==0 || start<s->max_single_valuation_start))) {
                s->max_single_valuation=v; s->max_single_valuation_start=start; s->max_single_valuation_state=x;
                s->max_single_valuation_reduced_step=steps; s->max_single_valuation_sign=sign;
            }
            if (better_u128(y,start,s->max_reduced_state,s->max_reduced_state_start)) {
                s->max_reduced_state=y; s->max_reduced_state_start=start; s->max_reduced_state_step=steps; s->max_reduced_state_original_step=A;
            }
            if (better_u128(orig1,start,s->max_original_state,s->max_original_state_start)) {
                s->max_original_state=orig1; s->max_original_state_start=start; s->max_original_state_reduced_step=steps; s->max_original_state_original_step=A_before+1;
            }
        } else if (cur_v1_run) {
            /* Only a run crossing the certificate boundary can beat a base-only run. */
            if (v==1U) {
                ++cur_v1_run;
                if (cur_v1_run>s->max_v1_run ||
                    (cur_v1_run==s->max_v1_run && (s->max_v1_run_start==0 || start<s->max_v1_run_start))) {
                    s->max_v1_run=cur_v1_run; s->max_v1_run_start=start;
                    s->max_v1_run_begin_step=cur_v1_begin; s->max_v1_run_end_step=steps;
                }
            } else { cur_v1_run=0; cur_v1_begin=0; }
        }

        if (!ofd_A && od_off) { ofd_A=A_before+(uint64_t)od_off; ofd_j=steps; ofd_state=od_state; }

        if (!fd_j || !bc_j) {
            int bknown=0; int crossed=barrier_crossed(steps,A,&bknown);
            if (!bknown) {
                ++s->barrier_certificate_exceeded;
                if (steps==BARRIER_CERT_MAX_J+1) add_anomaly(s,start,steps,A,x,sign,v,"barrier_certificate_exceeded");
            } else if (!bc_j && crossed) {
                bc_j=steps;
                if (!fd_j && y >= (u128)start) ++s->barrier_cross_pre_descent_no_descent;
            }
            if (!fd_j && y < (u128)start) {
                fd_j=steps; fd_A=A;
                if (bknown) { if (crossed) ++s->first_descent_above_barrier; else ++s->first_descent_below_barrier; }
                else ++s->first_descent_barrier_unknown;
            }
        }
        x=y;
    }
}

static void *worker(void *p) {
    WorkerArg *a=(WorkerArg*)p;
    ChunkCtx *c=a->ctx; Stats *s=a->s;
    memset(s,0,sizeof(*s));
    for (;;) {
        uint64_t lo=atomic_fetch_add_explicit(&c->next_raw,WORK_BLOCK,memory_order_relaxed);
        if (lo>c->hi) break;
        uint64_t remain=c->hi-lo+1;
        uint64_t hi=remain<WORK_BLOCK?c->hi:lo+WORK_BLOCK-1;
        s->raw_count += hi-lo+1;
        s->excluded_mult3 += hi/3ULL-(lo-1ULL)/3ULL;
        uint64_t m = lo + ((3ULL - (lo % 3ULL)) % 3ULL); /* first multiple of 3 >= lo */
        for (uint64_t n=lo; n<m && n<=hi; ++n) { ++s->admissible; if(c->certificate_mode) scan_one_certificate(n,c->base,s); else scan_one_full(n,s); }
        uint64_t q=m;
        while (q<=hi) {
            if (q < UINT64_MAX && q+1ULL<=hi) { ++s->admissible; if(c->certificate_mode) scan_one_certificate(q+1ULL,c->base,s); else scan_one_full(q+1ULL,s); }
            if (q <= UINT64_MAX-2ULL && q+2ULL<=hi) { ++s->admissible; if(c->certificate_mode) scan_one_certificate(q+2ULL,c->base,s); else scan_one_full(q+2ULL,s); }
            if (q > UINT64_MAX-3ULL) break;
            q += 3ULL;
        }
    }
    return NULL;
}

static void merge(Stats *d,const Stats *s) {
#define ADD(x) d->x += s->x
    ADD(raw_count); ADD(admissible); ADD(excluded_mult3);
    ADD(certified_to1); ADD(unknown_cycle); ADD(overflow); ADD(invariant_fail); ADD(step_limit); ADD(barrier_certificate_exceeded);
    d->total_reduced_steps += s->total_reduced_steps; d->total_original_steps += s->total_original_steps;
    ADD(sign_plus); ADD(sign_minus); ADD(initial_plus); ADD(initial_minus);
    for(unsigned k=0;k<=VMAX;++k){d->val_hist[k]+=s->val_hist[k];d->joint_plus[k]+=s->joint_plus[k];d->joint_minus[k]+=s->joint_minus[k];d->initial_val_hist[k]+=s->initial_val_hist[k];}
    for(unsigned k=0;k<=DESC_HIST_MAX+1U;++k){d->first_reduced_descent_hist[k]+=s->first_reduced_descent_hist[k];d->first_barrier_hist[k]+=s->first_barrier_hist[k];}
    for(unsigned k=0;k<=STOP_HIST_MAX+1U;++k){d->first_reduced_descent_original_hist[k]+=s->first_reduced_descent_original_hist[k];d->first_original_descent_hist[k]+=s->first_original_descent_hist[k];d->total_reduced_steps_hist[k]+=s->total_reduced_steps_hist[k];d->total_original_steps_hist[k]+=s->total_original_steps_hist[k];}
    ADD(first_descent_found); ADD(no_first_descent_certified); ADD(no_first_descent_unresolved);
    d->total_first_descent_reduced_steps += s->total_first_descent_reduced_steps;
    d->total_first_descent_original_steps += s->total_first_descent_original_steps;
    ADD(first_descent_above_barrier); ADD(first_descent_below_barrier); ADD(first_descent_barrier_unknown); ADD(barrier_cross_pre_descent_no_descent);
    ADD(first_barrier_found); ADD(no_first_barrier_certified); ADD(no_first_barrier_unresolved);
    d->total_first_barrier_edges += s->total_first_barrier_edges;
    ADD(barrier_before_reduced_descent); ADD(reduced_descent_before_barrier); ADD(barrier_descent_same_edge);
    if (better_u64(s->max_first_barrier_edges,s->max_first_barrier_start,d->max_first_barrier_edges,d->max_first_barrier_start)) {
        d->max_first_barrier_edges=s->max_first_barrier_edges; d->max_first_barrier_start=s->max_first_barrier_start;
    }
    if (better_u64(s->max_barrier_to_descent_gap,s->max_barrier_to_descent_gap_start,d->max_barrier_to_descent_gap,d->max_barrier_to_descent_gap_start)) {
        d->max_barrier_to_descent_gap=s->max_barrier_to_descent_gap; d->max_barrier_to_descent_gap_start=s->max_barrier_to_descent_gap_start;
    }
    if (better_u64(s->max_descent_to_barrier_gap,s->max_descent_to_barrier_gap_start,d->max_descent_to_barrier_gap,d->max_descent_to_barrier_gap_start)) {
        d->max_descent_to_barrier_gap=s->max_descent_to_barrier_gap; d->max_descent_to_barrier_gap_start=s->max_descent_to_barrier_gap_start;
    }
    for(int h=0;h<NH;++h){
        d->barrier_survive[h]+=s->barrier_survive[h]; d->actual_survive[h]+=s->actual_survive[h]; d->discrepancy[h]+=s->discrepancy[h];
        d->discrepancy_below_barrier_descent[h]+=s->discrepancy_below_barrier_descent[h]; d->discrepancy_above_barrier_nondesc[h]+=s->discrepancy_above_barrier_nondesc[h];
        if(s->discrepancy_max_start[h]>d->discrepancy_max_start[h])d->discrepancy_max_start[h]=s->discrepancy_max_start[h];
        d->theory_cutoff_violations[h]+=s->theory_cutoff_violations[h];
    }
    if (better_u64(s->max_reduced_steps,s->max_reduced_steps_start,d->max_reduced_steps,d->max_reduced_steps_start)) {d->max_reduced_steps=s->max_reduced_steps;d->max_reduced_steps_start=s->max_reduced_steps_start;}
    if (better_u64(s->max_original_steps,s->max_original_steps_start,d->max_original_steps,d->max_original_steps_start)) {d->max_original_steps=s->max_original_steps;d->max_original_steps_start=s->max_original_steps_start;}
    if (better_u64(s->max_first_descent_reduced,s->max_first_descent_reduced_start,d->max_first_descent_reduced,d->max_first_descent_reduced_start)) {d->max_first_descent_reduced=s->max_first_descent_reduced;d->max_first_descent_reduced_start=s->max_first_descent_reduced_start;d->max_first_descent_reduced_original_at_event=s->max_first_descent_reduced_original_at_event;}
    if (better_u64(s->max_first_descent_original,s->max_first_descent_original_start,d->max_first_descent_original,d->max_first_descent_original_start)) {d->max_first_descent_original=s->max_first_descent_original;d->max_first_descent_original_start=s->max_first_descent_original_start;d->max_first_descent_original_reduced_at_event=s->max_first_descent_original_reduced_at_event;}
    ADD(first_original_descent_found); ADD(no_original_descent_certified); ADD(no_original_descent_unresolved);
    d->total_first_original_descent_steps += s->total_first_original_descent_steps;
    if (better_u64(s->max_first_original_descent,s->max_first_original_descent_start,d->max_first_original_descent,d->max_first_original_descent_start)) {
        d->max_first_original_descent=s->max_first_original_descent; d->max_first_original_descent_start=s->max_first_original_descent_start;
        d->max_first_original_descent_reduced_edge=s->max_first_original_descent_reduced_edge; d->max_first_original_descent_state=s->max_first_original_descent_state;
    }
    if (s->max_v1_run>d->max_v1_run || (s->max_v1_run==d->max_v1_run && s->max_v1_run &&
        (d->max_v1_run_start==0 || s->max_v1_run_start<d->max_v1_run_start ||
         (s->max_v1_run_start==d->max_v1_run_start && s->max_v1_run_begin_step<d->max_v1_run_begin_step)))) {
        d->max_v1_run=s->max_v1_run; d->max_v1_run_start=s->max_v1_run_start;
        d->max_v1_run_begin_step=s->max_v1_run_begin_step; d->max_v1_run_end_step=s->max_v1_run_end_step;
    }
    if (better_u128(s->max_reduced_state,s->max_reduced_state_start,d->max_reduced_state,d->max_reduced_state_start)) {d->max_reduced_state=s->max_reduced_state;d->max_reduced_state_start=s->max_reduced_state_start;d->max_reduced_state_step=s->max_reduced_state_step;d->max_reduced_state_original_step=s->max_reduced_state_original_step;}
    if (better_u128(s->max_original_state,s->max_original_state_start,d->max_original_state,d->max_original_state_start)) {d->max_original_state=s->max_original_state;d->max_original_state_start=s->max_original_state_start;d->max_original_state_reduced_step=s->max_original_state_reduced_step;d->max_original_state_original_step=s->max_original_state_original_step;}
    if (s->max_single_valuation>d->max_single_valuation || (s->max_single_valuation==d->max_single_valuation && s->max_single_valuation && (d->max_single_valuation_start==0 || s->max_single_valuation_start<d->max_single_valuation_start))) {d->max_single_valuation=s->max_single_valuation;d->max_single_valuation_start=s->max_single_valuation_start;d->max_single_valuation_state=s->max_single_valuation_state;d->max_single_valuation_reduced_step=s->max_single_valuation_reduced_step;d->max_single_valuation_sign=s->max_single_valuation_sign;}
    if(s->max_discrepancy_start_any>d->max_discrepancy_start_any)d->max_discrepancy_start_any=s->max_discrepancy_start_any;
    if(s->first_unknown_start&&(!d->first_unknown_start||s->first_unknown_start<d->first_unknown_start)){d->first_unknown_start=s->first_unknown_start;d->first_unknown_state=s->first_unknown_state;}
    if(s->first_overflow_start&&(!d->first_overflow_start||s->first_overflow_start<d->first_overflow_start)){d->first_overflow_start=s->first_overflow_start;d->first_overflow_state=s->first_overflow_state;}
    if(s->first_invariant_start&&(!d->first_invariant_start||s->first_invariant_start<d->first_invariant_start)){d->first_invariant_start=s->first_invariant_start;d->first_invariant_state=s->first_invariant_state;}
    if(s->first_step_limit_start&&(!d->first_step_limit_start||s->first_step_limit_start<d->first_step_limit_start))d->first_step_limit_start=s->first_step_limit_start;
    for(uint32_t i=0;i<s->anomaly_count&&d->anomaly_count<NANOMALY;++i)d->anomaly[d->anomaly_count++]=s->anomaly[i];
#undef ADD
}

static int mkdir_if_needed(const char *p){if(mkdir(p,0755)==0||errno==EEXIST)return 1;perror("mkdir");return 0;}

static double wall_time(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return(double)ts.tv_sec+1e-9*(double)ts.tv_nsec;}

static int sync_close(FILE *f) {
    if (fflush(f)!=0) { fclose(f); return 0; }
    if (fsync(fileno(f))!=0) { fclose(f); return 0; }
    return fclose(f)==0;
}

static uint64_t count_mult3(uint64_t lo,uint64_t hi){return hi/3ULL-(lo-1ULL)/3ULL;}

static int checkpoint_exists_valid_identity(const char *dir,uint64_t idx,uint64_t lo,uint64_t hi,int certificate_mode,uint64_t base){
    char path[512],line[512];snprintf(path,sizeof(path),"%s/chunk_%06" PRIu64 ".done",dir,idx);
    FILE*f=fopen(path,"r");if(!f)return 0;
    uint64_t ridx=0,rlo=0,rhi=0,rbase=0;int rfmt=0;
    int goti=0,gotlo=0,gothi=0,gotver=0,gothash=0,gotfmt=0,gotmode=0,gotbase=0;
    char ver[128]={0},hash[128]={0},mode[32]={0};
    while(fgets(line,sizeof(line),f)){
        if(sscanf(line,"index=%" SCNu64,&ridx)==1)goti=1;
        else if(sscanf(line,"lo=%" SCNu64,&rlo)==1)gotlo=1;
        else if(sscanf(line,"hi=%" SCNu64,&rhi)==1)gothi=1;
        else if(sscanf(line,"scanner_version=%127s",ver)==1)gotver=1;
        else if(sscanf(line,"source_sha256=%127s",hash)==1)gothash=1;
        else if(sscanf(line,"format_version=%d",&rfmt)==1)gotfmt=1;
        else if(sscanf(line,"scan_mode=%31s",mode)==1)gotmode=1;
        else if(sscanf(line,"base_threshold=%" SCNu64,&rbase)==1)gotbase=1;
    }
    fclose(f);
    if(goti&&gotlo&&gothi&&gotver&&gothash&&gotfmt&&gotmode&&gotbase&&
       ridx==idx&&rlo==lo&&rhi==hi&&rfmt==FORMAT_VERSION&&rbase==base&&
       !strcmp(mode,certificate_mode?"certificate":"full")&&
       !strcmp(ver,SCANNER_VERSION)&&!strcmp(hash,SOURCE_SHA256))return 1;
    fprintf(stderr,"Refusing stale/malformed checkpoint %s (identity/hash/version mismatch)\n",path);return -1;
}

static void print_u64_array(FILE*f,const char*name,const uint64_t*a,size_t n){fprintf(f,"%s=",name);for(size_t i=0;i<n;++i)fprintf(f,"%s%" PRIu64,i?",":"",a[i]);fprintf(f,"\n");}

static int save_checkpoint(const char *dir,uint64_t idx,uint64_t lo,uint64_t hi,double sec,int certificate_mode,uint64_t base,const Stats*s){
    char path[512],tmp[520],apath[512],atmp[520];
    snprintf(path,sizeof(path),"%s/chunk_%06" PRIu64 ".done",dir,idx);snprintf(tmp,sizeof(tmp),"%s.tmp",path);
    FILE*f=fopen(tmp,"w");if(!f){perror(tmp);return 0;}
    char a[64],b[64],c[64],d[64];
    u128_to_str(s->total_reduced_steps,a,sizeof(a));u128_to_str(s->total_original_steps,b,sizeof(b));
    u128_to_str(s->total_first_descent_reduced_steps,c,sizeof(c));u128_to_str(s->total_first_descent_original_steps,d,sizeof(d));
    time_t now=time(NULL); struct tm utc_tm; char utc_stamp[32]="unknown";
    if (now!=(time_t)-1 && gmtime_r(&now,&utc_tm)!=NULL) strftime(utc_stamp,sizeof(utc_stamp),"%Y-%m-%dT%H:%M:%SZ",&utc_tm);
    fprintf(f,"format_version=%d\nscanner_version=%s\nsource_sha256=%s\nbuild_cc=%s\nbuild_cflags=%s\nscan_mode=%s\nbase_threshold=%" PRIu64 "\n",FORMAT_VERSION,SCANNER_VERSION,SOURCE_SHA256,BUILD_CC,BUILD_CFLAGS,certificate_mode?"certificate":"full",base);
    fprintf(f,"checkpoint_utc=%s\nindex=%" PRIu64 "\nlo=%" PRIu64 "\nhi=%" PRIu64 "\nseconds=%.9f\n",utc_stamp,idx,lo,hi,sec);
    fprintf(f,"raw_count=%" PRIu64 "\nadmissible=%" PRIu64 "\nexcluded_mult3=%" PRIu64 "\n",s->raw_count,s->admissible,s->excluded_mult3);
    fprintf(f,"certified_to1=%" PRIu64 "\nunknown_cycle=%" PRIu64 "\noverflow=%" PRIu64 "\ninvariant_fail=%" PRIu64 "\nstep_limit=%" PRIu64 "\nbarrier_certificate_exceeded=%" PRIu64 "\n",s->certified_to1,s->unknown_cycle,s->overflow,s->invariant_fail,s->step_limit,s->barrier_certificate_exceeded);
    fprintf(f,"total_reduced_steps=%s\ntotal_original_steps=%s\n",a,b);
    fprintf(f,"sign_plus=%" PRIu64 "\nsign_minus=%" PRIu64 "\ninitial_plus=%" PRIu64 "\ninitial_minus=%" PRIu64 "\n",s->sign_plus,s->sign_minus,s->initial_plus,s->initial_minus);
    print_u64_array(f,"val_hist",s->val_hist,VMAX+1);print_u64_array(f,"joint_plus",s->joint_plus,VMAX+1);print_u64_array(f,"joint_minus",s->joint_minus,VMAX+1);print_u64_array(f,"initial_val_hist",s->initial_val_hist,VMAX+1);
    fprintf(f,"desc_hist_max=%u\nstop_hist_max=%u\n",DESC_HIST_MAX,STOP_HIST_MAX);
    print_u64_array(f,"first_reduced_descent_hist",s->first_reduced_descent_hist,DESC_HIST_MAX+2U);
    print_u64_array(f,"first_reduced_descent_original_hist",s->first_reduced_descent_original_hist,STOP_HIST_MAX+2U);
    print_u64_array(f,"first_original_descent_hist",s->first_original_descent_hist,STOP_HIST_MAX+2U);
    print_u64_array(f,"first_barrier_hist",s->first_barrier_hist,DESC_HIST_MAX+2U);
    print_u64_array(f,"total_reduced_steps_hist",s->total_reduced_steps_hist,STOP_HIST_MAX+2U);
    print_u64_array(f,"total_original_steps_hist",s->total_original_steps_hist,STOP_HIST_MAX+2U);
    fprintf(f,"first_reduced_descent_found=%" PRIu64 "\nno_reduced_descent_certified=%" PRIu64 "\nno_reduced_descent_unresolved=%" PRIu64 "\n",s->first_descent_found,s->no_first_descent_certified,s->no_first_descent_unresolved);
    fprintf(f,"total_first_reduced_descent_edges=%s\ntotal_original_steps_at_first_reduced_descent=%s\n",c,d);
    fprintf(f,"first_reduced_descent_at_or_above_barrier=%" PRIu64 "\nfirst_reduced_descent_below_barrier=%" PRIu64 "\nfirst_reduced_descent_barrier_unknown=%" PRIu64 "\nbarrier_cross_pre_descent_no_descent=%" PRIu64 "\n",s->first_descent_above_barrier,s->first_descent_below_barrier,s->first_descent_barrier_unknown,s->barrier_cross_pre_descent_no_descent);
    u128_to_str(s->total_first_barrier_edges,a,sizeof(a));
    fprintf(f,"first_barrier_found=%" PRIu64 "\nno_first_barrier_certified=%" PRIu64 "\nno_first_barrier_unresolved=%" PRIu64 "\ntotal_first_barrier_edges=%s\n",s->first_barrier_found,s->no_first_barrier_certified,s->no_first_barrier_unresolved,a);
    fprintf(f,"max_first_barrier_edges=%" PRIu64 "\nmax_first_barrier_start=%" PRIu64 "\nbarrier_before_reduced_descent=%" PRIu64 "\nreduced_descent_before_barrier=%" PRIu64 "\nbarrier_descent_same_edge=%" PRIu64 "\n",s->max_first_barrier_edges,s->max_first_barrier_start,s->barrier_before_reduced_descent,s->reduced_descent_before_barrier,s->barrier_descent_same_edge);
    fprintf(f,"max_barrier_to_descent_gap=%" PRIu64 "\nmax_barrier_to_descent_gap_start=%" PRIu64 "\nmax_descent_to_barrier_gap=%" PRIu64 "\nmax_descent_to_barrier_gap_start=%" PRIu64 "\n",s->max_barrier_to_descent_gap,s->max_barrier_to_descent_gap_start,s->max_descent_to_barrier_gap,s->max_descent_to_barrier_gap_start);
    fprintf(f,"horizons_values=");for(int h=0;h<NH;++h)fprintf(f,"%s%u",h?",":"",HORIZONS[h]);fprintf(f,"\n");
    print_u64_array(f,"barrier_survive",s->barrier_survive,NH);print_u64_array(f,"actual_survive",s->actual_survive,NH);print_u64_array(f,"discrepancy",s->discrepancy,NH);print_u64_array(f,"discrepancy_below_barrier_descent",s->discrepancy_below_barrier_descent,NH);print_u64_array(f,"discrepancy_above_barrier_nondesc",s->discrepancy_above_barrier_nondesc,NH);print_u64_array(f,"discrepancy_max_start",s->discrepancy_max_start,NH);print_u64_array(f,"theory_cutoff_violations",s->theory_cutoff_violations,NH);
    fprintf(f,"max_reduced_steps=%" PRIu64 "\nmax_reduced_steps_start=%" PRIu64 "\nmax_original_steps=%" PRIu64 "\nmax_original_steps_start=%" PRIu64 "\n",s->max_reduced_steps,s->max_reduced_steps_start,s->max_original_steps,s->max_original_steps_start);
    fprintf(f,"max_first_reduced_descent_edges=%" PRIu64 "\nmax_first_reduced_descent_edges_start=%" PRIu64 "\noriginal_steps_at_max_first_reduced_descent=%" PRIu64 "\n",s->max_first_descent_reduced,s->max_first_descent_reduced_start,s->max_first_descent_reduced_original_at_event);
    fprintf(f,"max_original_steps_at_first_reduced_descent=%" PRIu64 "\nmax_original_steps_at_first_reduced_descent_start=%" PRIu64 "\nreduced_edges_at_max_original_steps_first_reduced_descent=%" PRIu64 "\n",s->max_first_descent_original,s->max_first_descent_original_start,s->max_first_descent_original_reduced_at_event);
    u128_to_str(s->total_first_original_descent_steps,a,sizeof(a));
    fprintf(f,"first_original_descent_found=%" PRIu64 "\nno_original_descent_certified=%" PRIu64 "\nno_original_descent_unresolved=%" PRIu64 "\ntotal_first_original_descent_steps=%s\n",s->first_original_descent_found,s->no_original_descent_certified,s->no_original_descent_unresolved,a);
    u128_to_str(s->max_first_original_descent_state,b,sizeof(b));
    fprintf(f,"max_first_original_descent=%" PRIu64 "\nmax_first_original_descent_start=%" PRIu64 "\nmax_first_original_descent_reduced_edge=%" PRIu64 "\nmax_first_original_descent_state=%s\n",s->max_first_original_descent,s->max_first_original_descent_start,s->max_first_original_descent_reduced_edge,b);
    fprintf(f,"max_v1_run=%" PRIu64 "\nmax_v1_run_start=%" PRIu64 "\nmax_v1_run_begin_step=%" PRIu64 "\nmax_v1_run_end_step=%" PRIu64 "\n",s->max_v1_run,s->max_v1_run_start,s->max_v1_run_begin_step,s->max_v1_run_end_step);
    u128_to_str(s->max_reduced_state,a,sizeof(a));u128_to_str(s->max_original_state,b,sizeof(b));
    fprintf(f,"max_reduced_state=%s\nmax_reduced_state_start=%" PRIu64 "\nmax_reduced_state_step=%" PRIu64 "\nmax_reduced_state_original_step=%" PRIu64 "\n",a,s->max_reduced_state_start,s->max_reduced_state_step,s->max_reduced_state_original_step);
    fprintf(f,"max_original_state=%s\nmax_original_state_start=%" PRIu64 "\nmax_original_state_reduced_step=%" PRIu64 "\nmax_original_state_original_step=%" PRIu64 "\n",b,s->max_original_state_start,s->max_original_state_reduced_step,s->max_original_state_original_step);
    u128_to_str(s->max_single_valuation_state,c,sizeof(c));
    fprintf(f,"max_single_valuation=%u\nmax_single_valuation_start=%" PRIu64 "\nmax_single_valuation_state=%s\nmax_single_valuation_reduced_step=%" PRIu64 "\nmax_single_valuation_sign=%d\n",s->max_single_valuation,s->max_single_valuation_start,c,s->max_single_valuation_reduced_step,s->max_single_valuation_sign);
    fprintf(f,"max_discrepancy_start_any=%" PRIu64 "\nfirst_unknown_start=%" PRIu64 "\nfirst_overflow_start=%" PRIu64 "\nfirst_invariant_start=%" PRIu64 "\nfirst_step_limit_start=%" PRIu64 "\n",s->max_discrepancy_start_any,s->first_unknown_start,s->first_overflow_start,s->first_invariant_start,s->first_step_limit_start);
    u128_to_str(s->first_unknown_state,a,sizeof(a));u128_to_str(s->first_overflow_state,b,sizeof(b));u128_to_str(s->first_invariant_state,c,sizeof(c));
    fprintf(f,"first_unknown_state=%s\nfirst_overflow_state=%s\nfirst_invariant_state=%s\n",a,b,c);
    if(!sync_close(f)){unlink(tmp);return 0;}

    snprintf(apath,sizeof(apath),"%s/chunk_%06" PRIu64 ".anomalies.tsv",dir,idx);snprintf(atmp,sizeof(atmp),"%s.tmp",apath);
    FILE*g=fopen(atmp,"w");if(!g){perror(atmp);unlink(tmp);return 0;}
    fprintf(g,"start\treduced_step\toriginal_step\tstate\tsign\tvaluation\treason\n");
    for(uint32_t i=0;i<s->anomaly_count;++i){char st[64];u128_to_str(s->anomaly[i].state,st,sizeof(st));fprintf(g,"%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%s\t%d\t%u\t%s\n",s->anomaly[i].start,s->anomaly[i].reduced_step,s->anomaly[i].original_step,st,s->anomaly[i].sign,s->anomaly[i].valuation,s->anomaly[i].reason);}
    if(!sync_close(g)){unlink(atmp);unlink(tmp);return 0;}
    if(rename(atmp,apath)!=0){perror("rename anomaly");unlink(tmp);return 0;}
    if(rename(tmp,path)!=0){perror("rename checkpoint");return 0;}
    return 1;
}

static void show_chunk(uint64_t idx,uint64_t chunks,uint64_t lo,uint64_t hi,double sec,const Stats*s){
    char rr[64],oo[64],rp[64],op[64];u128_to_str(s->total_reduced_steps,rr,sizeof(rr));u128_to_str(s->total_original_steps,oo,sizeof(oo));u128_to_str(s->max_reduced_state,rp,sizeof(rp));u128_to_str(s->max_original_state,op,sizeof(op));
    printf("chunk %" PRIu64 "/%" PRIu64 " [%" PRIu64 ",%" PRIu64 "]: adm=%" PRIu64 " sec=%.3f rate=%.0f adm/s cert=%" PRIu64 " unresolved=%" PRIu64 "\n",idx,chunks,lo,hi,s->admissible,sec,sec>0?(double)s->admissible/sec:0.0,s->certified_to1,s->unknown_cycle+s->overflow+s->invariant_fail+s->step_limit);
    printf("  steps reduced=%s original=%s | max transient r=%" PRIu64 "@%" PRIu64 " o=%" PRIu64 "@%" PRIu64 "\n",rr,oo,s->max_reduced_steps,s->max_reduced_steps_start,s->max_original_steps,s->max_original_steps_start);
    printf("  first reduced descent max r=%" PRIu64 "@%" PRIu64 " (edge-end original=%" PRIu64 ") | correction=%" PRIu64 " barrier=%" PRIu64 "\n",s->max_first_descent_reduced,s->max_first_descent_reduced_start,s->max_first_descent_original,s->first_descent_below_barrier,s->first_descent_above_barrier);
    printf("  first ORIGINAL descent max o=%" PRIu64 "@%" PRIu64 " | longest a=1 run=%" PRIu64 "@%" PRIu64 "\n",s->max_first_original_descent,s->max_first_original_descent_start,s->max_v1_run,s->max_v1_run_start);
    printf("  peaks reduced=%s@%" PRIu64 " original=%s@%" PRIu64 " | max a=%u@%" PRIu64 "\n",rp,s->max_reduced_state_start,op,s->max_original_state_start,s->max_single_valuation,s->max_single_valuation_start);
    fflush(stdout);
}

int main(int argc,char**argv){
    if(argc!=8){fprintf(stderr,"Usage: %s MODE BASE START END CHUNK THREADS RESULTS_DIR\nMODE=full|certificate\n",argv[0]);return 2;}
    int certificate_mode;
    if(!strcmp(argv[1],"full")) certificate_mode=0;
    else if(!strcmp(argv[1],"certificate")) certificate_mode=1;
    else {fprintf(stderr,"MODE must be full or certificate\n");return 2;}
    errno=0;uint64_t base=strtoull(argv[2],NULL,10),start=strtoull(argv[3],NULL,10),end=strtoull(argv[4],NULL,10),chunk=strtoull(argv[5],NULL,10);int threads=atoi(argv[6]);const char*dir=argv[7];
    if(errno||start<1||end<start||chunk<1||threads<1||threads>256||(certificate_mode&&base<1)||(certificate_mode&&start<=base)){fprintf(stderr,"Invalid arguments.\n");return 2;}
    if(!mkdir_if_needed(dir))return 1;
    for (int h=0; h<NH; ++h) {
        if (HORIZONS[h] != THEORY_CUTOFF_HORIZONS[h]) {
            fprintf(stderr,"Internal horizon/cutoff mismatch at index %d\n",h); return 1;
        }
    }
    uint64_t span=end-start+1;uint64_t chunks=span/chunk+(span%chunk!=0);
    printf("TERNARY (4k±1)/3 ACCELERATED AUDIT SCANNER %s\n",SCANNER_VERSION);
    printf("source_sha256=%s\nmode=%s base=%" PRIu64 " range=[%" PRIu64 ",%" PRIu64 "] chunk=%" PRIu64 " threads=%d results=%s\n",SOURCE_SHA256,certificate_mode?"certificate":"full",base,start,end,chunk,threads,dir);
    printf("barrier_certificate_max_j=%" PRIu64 "; horizons=6,10,20,25,30,40,50,100,200,500\n",(uint64_t)BARRIER_CERT_MAX_J);
    printf("theory_cutoffs=41,82,8808,29471,38211,1060106,84746117,29226808579889,NA,NA\n");

    for(uint64_t idx=1;idx<=chunks;++idx){
        uint64_t lo=start+(idx-1)*chunk;uint64_t hi=(end-lo+1<chunk)?end:lo+chunk-1;
        int ex=checkpoint_exists_valid_identity(dir,idx,lo,hi,certificate_mode,base);if(ex<0)return 1;if(ex>0){printf("chunk %" PRIu64 ": existing validated identity; skipped\n",idx);continue;}
        Stats cs;memset(&cs,0,sizeof(cs));Stats*locals=calloc((size_t)threads,sizeof(Stats));pthread_t*tid=calloc((size_t)threads,sizeof(pthread_t));WorkerArg*wa=calloc((size_t)threads,sizeof(WorkerArg));if(!locals||!tid||!wa){fprintf(stderr,"allocation failure\n");return 1;}
        ChunkCtx ctx={.lo=lo,.hi=hi,.base=base,.certificate_mode=certificate_mode,.locals=locals};atomic_init(&ctx.next_raw,lo);
        double t0=wall_time();
        for(int t=0;t<threads;++t){wa[t].ctx=&ctx;wa[t].s=&locals[t];int rc=pthread_create(&tid[t],NULL,worker,&wa[t]);if(rc){fprintf(stderr,"pthread_create: %s\n",strerror(rc));return 1;}}
        for(int t=0;t<threads;++t){pthread_join(tid[t],NULL);merge(&cs,&locals[t]);}
        double sec=wall_time()-t0;
        derive_chunk_stats(&cs);
        uint64_t expected_raw=hi-lo+1, expected_mult=count_mult3(lo,hi), expected_adm=expected_raw-expected_mult;
        uint64_t unresolved=cs.unknown_cycle+cs.overflow+cs.invariant_fail+cs.step_limit;
        uint64_t expected_initial = expected_adm - ((lo<=1 && 1<=hi)?1ULL:0ULL);
        if(cs.raw_count!=expected_raw||cs.excluded_mult3!=expected_mult||cs.admissible!=expected_adm||
           cs.certified_to1+unresolved!=cs.admissible||
           (u128)(cs.sign_plus+cs.sign_minus)!=cs.total_reduced_steps||
           cs.initial_plus+cs.initial_minus!=expected_initial||
           cs.first_descent_found+cs.no_first_descent_certified+cs.no_first_descent_unresolved!=cs.admissible||
           cs.first_original_descent_found+cs.no_original_descent_certified+cs.no_original_descent_unresolved!=cs.admissible||
           cs.first_barrier_found+cs.no_first_barrier_certified+cs.no_first_barrier_unresolved!=cs.admissible){
            fprintf(stderr,"chunk consistency failure idx=%" PRIu64 "\n",idx);return 1;
        }
        uint64_t hist_sum=0,joint_sum=0;for(unsigned k=1;k<=VMAX;++k){hist_sum+=cs.val_hist[k];joint_sum+=cs.joint_plus[k]+cs.joint_minus[k];}
        if(hist_sum!=cs.sign_plus+cs.sign_minus||joint_sum!=hist_sum){fprintf(stderr,"histogram consistency failure idx=%" PRIu64 "\n",idx);return 1;}
        uint64_t hfd=0,hfdo=0,hofd=0,hbc=0,htr=0,hto=0;
        for(unsigned k=0;k<=DESC_HIST_MAX+1U;++k){hfd+=cs.first_reduced_descent_hist[k];hbc+=cs.first_barrier_hist[k];}
        for(unsigned k=0;k<=STOP_HIST_MAX+1U;++k){hfdo+=cs.first_reduced_descent_original_hist[k];hofd+=cs.first_original_descent_hist[k];htr+=cs.total_reduced_steps_hist[k];hto+=cs.total_original_steps_hist[k];}
        if(hfd!=cs.first_descent_found||hfdo!=cs.first_descent_found||hofd!=cs.first_original_descent_found||hbc!=cs.first_barrier_found||htr!=cs.certified_to1||hto!=cs.certified_to1){fprintf(stderr,"distribution histogram consistency failure idx=%" PRIu64 "\n",idx);return 1;}
        if(!save_checkpoint(dir,idx,lo,hi,sec,certificate_mode,base,&cs)){fprintf(stderr,"failed saving checkpoint\n");return 1;}
        show_chunk(idx,chunks,lo,hi,sec,&cs);
        free(locals);free(tid);free(wa);
    }
    printf("All requested chunks are present. Run tools/aggregate.py for strict global audit, SHA-256 manifest, and record list.\n");
    return 0;
}
