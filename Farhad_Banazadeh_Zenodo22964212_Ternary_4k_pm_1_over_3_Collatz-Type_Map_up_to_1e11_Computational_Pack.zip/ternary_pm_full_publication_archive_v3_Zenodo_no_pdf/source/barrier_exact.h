/* Auto-generated/verified by tools/generate_barrier_certificate.py. */
#ifndef BARRIER_EXACT_H
#define BARRIER_EXACT_H
#include <stdint.h>
#define ALPHA_LO_P 190537ULL
#define ALPHA_LO_Q 150997ULL
#define ALPHA_HI_P 21372011ULL
#define ALPHA_HI_Q 16936918ULL
#define BARRIER_CERT_MAX_J 17087914ULL
#endif
