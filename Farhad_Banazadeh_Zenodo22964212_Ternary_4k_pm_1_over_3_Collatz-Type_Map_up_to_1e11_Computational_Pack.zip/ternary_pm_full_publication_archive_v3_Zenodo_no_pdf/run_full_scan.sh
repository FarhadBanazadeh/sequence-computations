#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"
# On macOS keep the computation awake automatically.
if command -v caffeinate >/dev/null 2>&1 && [ "${TERNARY_CAFFEINATED:-0}" != 1 ]; then
  exec env TERNARY_CAFFEINATED=1 caffeinate -is "$0" "$@"
fi
BASE="${BASE:-1000000000}"
END="${END:-100000000000}"
CHUNK="${CHUNK:-100000000}"
THREADS="${THREADS:-4}"
RESULTS="${RESULTS:-results_fresh_1e11}"
export RESULTS
CC="${CC:-clang}"; export CC
mkdir -p "$RESULTS/base_full" "$RESULTS/extension_certificate"
{
  echo "utc_start=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "host_uname=$(uname -a)"
  echo "compiler=$CC"; "$CC" --version | sed 's/^/compiler_version=/'
  python3 --version 2>&1 | sed 's/^/python_version=/'
  if command -v sysctl >/dev/null 2>&1; then sysctl -n machdep.cpu.brand_string 2>/dev/null | sed 's/^/cpu=/' || true; fi
  echo "base=$BASE"; echo "end=$END"; echo "chunk=$CHUNK"; echo "threads=$THREADS"
  echo "architecture=fresh full base scan + fresh extension certificate scan"
} > "$RESULTS/RUN_METADATA.txt"
./build.sh 2>&1 | tee "$RESULTS/BUILD.log"
cp scanner "$RESULTS/scanner_binary"
cp audit_discrepancy50 "$RESULTS/audit_discrepancy50_binary"
python3 - <<'PY' > "$RESULTS/PROJECT_SHA256SUMS.txt"
from pathlib import Path
import hashlib
for p in [Path('build.sh'),Path('run_full_scan.sh'),Path('monitor_progress.sh'),*sorted(Path('source').glob('*')),*sorted(Path('tools').glob('*.py')),Path('BARRIER_EXACT_CERTIFICATE.json'),Path('THEORY_CUTOFF_CERTIFICATE.json')]:
    if p.is_file(): print(hashlib.sha256(p.read_bytes()).hexdigest(),p.as_posix())
PY

echo "===== PHASE 1/2: FRESH FULL BASE [1,$BASE] ====="
./scanner full 0 1 "$BASE" "$CHUNK" "$THREADS" "$RESULTS/base_full" 2>&1 | tee "$RESULTS/BASE_SCAN.log"
python3 tools/aggregate.py "$RESULTS/base_full" --expect-start 1 --expect-end "$BASE" --require-clean --project-root . 2>&1 | tee "$RESULTS/BASE_AUDIT.log"

# Independent finite-discrepancy audit through the entire explicit m=50 zone.
DISC_CUTOFF=$(python3 - <<'PY2'
import json
x=json.load(open('THEORY_CUTOFF_CERTIFICATE.json'))
print(next(int(r['cutoff_floor_M_plus_1']) for r in x['horizons'] if int(r['horizon'])==50))
PY2
)
DISC_MAX=$((DISC_CUTOFF-1))
if [ "$BASE" -lt "$DISC_MAX" ]; then DISC_MAX="$BASE"; fi
echo "===== INDEPENDENT DISCREPANCY AUDIT [1,$DISC_MAX], horizons <=50 ====="
./audit_discrepancy50 "$DISC_MAX" "$RESULTS/DISCREPANCY50_CASES.tsv" 2>&1 | tee "$RESULTS/DISCREPANCY50_AUDIT.log"
python3 - "$RESULTS/base_full/aggregate_summary.json" "$RESULTS/DISCREPANCY50_AUDIT.log" "$BASE" "$DISC_CUTOFF" <<'PY2'
import json,re,sys
summary=json.load(open(sys.argv[1])); text=open(sys.argv[2]).read(); base=int(sys.argv[3]); cutoff=int(sys.argv[4])
horizons=[6,10,20,25,30,40,50]
for i,h in enumerate(horizons):
    m=re.search(rf'horizon_{h}_count=(\d+) horizon_{h}_max_start=(\d+) cutoff=(\d+)',text)
    if not m: raise SystemExit(f'missing discrepancy audit output for horizon {h}')
    count,mx,co=map(int,m.groups())
    if co != summary['arrays']['theory_cutoff_violations'][i]*0 + [41,82,8808,29471,38211,1060106,84746117][i]:
        raise SystemExit(f'cutoff mismatch at horizon {h}: {co}')
    # If the fresh base covers the whole theoretical discrepancy zone, the independent
    # enumerator and production aggregate must agree exactly.
    if base >= cutoff-1 and count != summary['arrays']['discrepancy'][i]:
        raise SystemExit(f'discrepancy count mismatch at horizon {h}: independent={count} scanner={summary["arrays"]["discrepancy"][i]}')
    if mx and mx >= co: raise SystemExit(f'theory cutoff violation in independent audit at horizon {h}: {mx} >= {co}')
print('independent discrepancy audit: PASS')
PY2

echo "===== PHASE 2/2: FRESH EXTENSION CERTIFICATE [$((BASE+1)),$END] ====="
./scanner certificate "$BASE" "$((BASE+1))" "$END" "$CHUNK" "$THREADS" "$RESULTS/extension_certificate" 2>&1 | tee "$RESULTS/EXTENSION_SCAN.log"
python3 tools/aggregate.py "$RESULTS/extension_certificate" --expect-start "$((BASE+1))" --expect-end "$END" --require-clean --project-root . 2>&1 | tee "$RESULTS/EXTENSION_AUDIT.log"

python3 tools/combine_results.py "$RESULTS/base_full/aggregate_summary.json" "$RESULTS/extension_certificate/aggregate_summary.json" --output-dir "$RESULTS" --base-end "$BASE" --end "$END" 2>&1 | tee "$RESULTS/COMBINE_AUDIT.log"

echo "===== GLOBAL RECORD REPLAY / TRAJECTORY CERTIFICATES ====="
python3 tools/replay_records.py "$RESULTS/base_full/aggregate_summary.json" "$RESULTS/extension_certificate/aggregate_summary.json" --base "$BASE" --output-dir "$RESULTS/record_trajectories" 2>&1 | tee "$RESULTS/RECORD_REPLAY_AUDIT.log"
{
  echo "utc_finish=$(date -u +%Y-%m-%dT%H:%M:%SZ)"; echo "status=COMPLETE_AND_AUDITED"
} >> "$RESULTS/RUN_METADATA.txt"
python3 - <<'PY' > "$RESULTS/FINAL_SHA256SUMS.txt"
from pathlib import Path
import hashlib
root=Path(__import__('os').environ.get('RESULTS','results_fresh_1e11'))
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name!='FINAL_SHA256SUMS.txt': print(hashlib.sha256(p.read_bytes()).hexdigest(),p.relative_to(root).as_posix())
PY
echo "FULL FRESH SCAN COMPLETE AND CLEAN: $RESULTS"
