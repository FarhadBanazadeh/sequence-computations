#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"
CC_BIN="${CC:-cc}"
DEFAULT_FLAGS='-O3 -march=native -flto -std=c11 -pthread -Wall -Wextra -Wformat=2 -Wshadow -Wconversion -Wsign-conversion -Werror'
CFLAGS_STR="${CFLAGS:-$DEFAULT_FLAGS}"
python3 tools/generate_barrier_certificate.py --header source/barrier_exact.h --certificate BARRIER_EXACT_CERTIFICATE.json >/dev/null
python3 tools/generate_theory_cutoffs.py --header source/theory_cutoffs.h --certificate THEORY_CUTOFF_CERTIFICATE.json >/dev/null
python3 tools/generate_barrier_small.py --output source/barrier_small.h --max-j 8192 >/dev/null
CODE_HASH="$(python3 - <<'PY'
from pathlib import Path
import hashlib
h=hashlib.sha256()
for name in ['source/scan_ternary_pm_v4.c','source/audit_discrepancy50.c','source/barrier_exact.h','source/barrier_small.h','source/theory_cutoffs.h']:
    h.update(Path(name).read_bytes())
print(h.hexdigest())
PY
)"
escape_c_string(){ printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }
compile_with(){
  local flags="$1"; local cc_esc cf_esc
  read -r -a arr <<< "$flags"
  cc_esc="$(escape_c_string "$CC_BIN")"; cf_esc="$(escape_c_string "$flags")"
  "$CC_BIN" "${arr[@]}" \
    "-DSOURCE_SHA256=\"$CODE_HASH\"" \
    "-DBUILD_CC=\"$cc_esc\"" \
    "-DBUILD_CFLAGS=\"$cf_esc\"" \
    source/scan_ternary_pm_v4.c -o scanner
  "$CC_BIN" "${arr[@]}" \
    "-DSOURCE_SHA256=\"$CODE_HASH\"" \
    source/audit_discrepancy50.c -o audit_discrepancy50
}
if ! compile_with "$CFLAGS_STR"; then
  if [[ "$CFLAGS_STR" == *-flto* ]]; then
    echo "LTO build failed; retrying without -flto" >&2
    CFLAGS_STR="${CFLAGS_STR//-flto/}"
    compile_with "$CFLAGS_STR"
  else
    exit 1
  fi
fi
printf 'built %s/scanner\nsource+certificates SHA256: %s\n' "$ROOT" "$CODE_HASH"
