#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from reference_scan import H,CUT,VMAX,DESC_HIST_MAX,STOP_HIST_MAX,step,better,init_stats

def inc_hist(h,cap,v): h[v if v<=cap else cap+1]+=1

def finish(s,start,seg_steps,seg_A,fdj,fdA,ofdA,ofdj,ofdstate,bcj):
    s['certified_to1']+=1
    s['total_reduced_steps']+=seg_steps;s['total_original_steps']+=seg_A
    inc_hist(s['total_reduced_steps_hist'],STOP_HIST_MAX,seg_steps);inc_hist(s['total_original_steps_hist'],STOP_HIST_MAX,seg_A)
    if better(seg_steps,start,s['max_reduced_steps'],s['max_reduced_steps_start']):s['max_reduced_steps']=seg_steps;s['max_reduced_steps_start']=start
    if better(seg_A,start,s['max_original_steps'],s['max_original_steps_start']):s['max_original_steps']=seg_A;s['max_original_steps_start']=start
    if fdj:
        s['first_reduced_descent_found']+=1;s['total_first_reduced_descent_edges']+=fdj;s['total_original_steps_at_first_reduced_descent']+=fdA
        inc_hist(s['first_reduced_descent_hist'],DESC_HIST_MAX,fdj);inc_hist(s['first_reduced_descent_original_hist'],STOP_HIST_MAX,fdA)
        if better(fdj,start,s['max_first_reduced_descent_edges'],s['max_first_reduced_descent_edges_start']):s['max_first_reduced_descent_edges']=fdj;s['max_first_reduced_descent_edges_start']=start;s['original_steps_at_max_first_reduced_descent']=fdA
        if better(fdA,start,s['max_original_steps_at_first_reduced_descent'],s['max_original_steps_at_first_reduced_descent_start']):s['max_original_steps_at_first_reduced_descent']=fdA;s['max_original_steps_at_first_reduced_descent_start']=start;s['reduced_edges_at_max_original_steps_first_reduced_descent']=fdj
    else:s['no_reduced_descent_certified']+=1
    if ofdA:
        s['first_original_descent_found']+=1;s['total_first_original_descent_steps']+=ofdA;inc_hist(s['first_original_descent_hist'],STOP_HIST_MAX,ofdA)
        if better(ofdA,start,s['max_first_original_descent'],s['max_first_original_descent_start']):s['max_first_original_descent']=ofdA;s['max_first_original_descent_start']=start;s['max_first_original_descent_reduced_edge']=ofdj;s['max_first_original_descent_state']=ofdstate
    else:s['no_original_descent_certified']+=1
    if bcj:
        s['first_barrier_found']+=1;s['total_first_barrier_edges']+=bcj;inc_hist(s['first_barrier_hist'],DESC_HIST_MAX,bcj)
        if better(bcj,start,s['max_first_barrier_edges'],s['max_first_barrier_start']):s['max_first_barrier_edges']=bcj;s['max_first_barrier_start']=start
    else:s['no_first_barrier_certified']+=1
    if fdj and bcj:
        if bcj<fdj:
            s['barrier_before_reduced_descent']+=1;g=fdj-bcj
            if better(g,start,s['max_barrier_to_descent_gap'],s['max_barrier_to_descent_gap_start']):s['max_barrier_to_descent_gap']=g;s['max_barrier_to_descent_gap_start']=start
        elif fdj<bcj:
            s['reduced_descent_before_barrier']+=1;g=bcj-fdj
            if better(g,start,s['max_descent_to_barrier_gap'],s['max_descent_to_barrier_gap_start']):s['max_descent_to_barrier_gap']=g;s['max_descent_to_barrier_gap_start']=start
        else:s['barrier_descent_same_edge']+=1
    elif fdj:s['reduced_descent_before_barrier']+=1
    elif bcj:s['barrier_before_reduced_descent']+=1
    for i,m in enumerate(H):
        bs=(bcj==0 or bcj>m);ac=(fdj==0 or fdj>m)
        if bs:s['barrier_survive'][i]+=1
        if ac:s['actual_survive'][i]+=1
        if bs!=ac:
            s['discrepancy'][i]+=1
            if (not ac) and bs:s['discrepancy_below_barrier_descent'][i]+=1
            if ac and (not bs):s['discrepancy_above_barrier_nondesc'][i]+=1
            s['discrepancy_max_start'][i]=max(s['discrepancy_max_start'][i],start);s['max_discrepancy_start_any']=max(s['max_discrepancy_start_any'],start)
            if CUT[i] is not None and start>=CUT[i]:s['theory_cutoff_violations'][i]+=1

def scan(lo,hi,base):
    s=init_stats()
    assert lo>base
    for start in range(lo,hi+1):
        s['raw_count']+=1
        if start%3==0:s['excluded_mult3']+=1;continue
        s['admissible']+=1
        x=start;steps=A=0;seg_steps=seg_A=0;fdj=fdA=ofdA=ofdj=ofdstate=bcj=0;cur1=curbegin=0;done=False
        if better(x,start,s['max_reduced_state'],s['max_reduced_state_start']):s['max_reduced_state']=x;s['max_reduced_state_start']=start
        if better(x,start,s['max_original_state'],s['max_original_state_start']):s['max_original_state']=x;s['max_original_state_start']=start
        seen=set()
        while True:
            if not done and x<=base:
                done=True;seg_steps=steps;seg_A=A
                if not fdj:fdj=steps;fdA=A
            if done and (x==1 or (bcj and cur1==0)):
                finish(s,start,seg_steps,seg_A,fdj,fdA,ofdA,ofdj,ofdstate,bcj);break
            key=(x,steps,A,done,bcj,cur1)
            if key in seen: raise AssertionError(('event tail cycle',start,x))
            seen.add(key)
            y,num,orig1,sign,v=step(x);steps+=1;Ab=A;A+=v
            if not done:
                s['joint_plus' if sign>0 else 'joint_minus'][v]+=1
                s['val_hist'][v]+=1;s['sign_plus' if sign>0 else 'sign_minus']+=1
                if steps==1:s['initial_plus' if sign>0 else 'initial_minus']+=1;s['initial_val_hist'][v]+=1
                if v==1:
                    if cur1==0:curbegin=steps
                    cur1+=1
                    if cur1>s['max_v1_run'] or (cur1==s['max_v1_run'] and (s['max_v1_run_start']==0 or start<s['max_v1_run_start'])):
                        s['max_v1_run']=cur1;s['max_v1_run_start']=start;s['max_v1_run_begin_step']=curbegin;s['max_v1_run_end_step']=steps
                else:cur1=curbegin=0
                if v>s['max_single_valuation'] or (v==s['max_single_valuation'] and (s['max_single_valuation_start']==0 or start<s['max_single_valuation_start'])):
                    s['max_single_valuation']=v;s['max_single_valuation_start']=start;s['max_single_valuation_state']=x;s['max_single_valuation_reduced_step']=steps;s['max_single_valuation_sign']=sign
                if better(y,start,s['max_reduced_state'],s['max_reduced_state_start']):s['max_reduced_state']=y;s['max_reduced_state_start']=start;s['max_reduced_state_step']=steps;s['max_reduced_state_original_step']=A
                if better(orig1,start,s['max_original_state'],s['max_original_state_start']):s['max_original_state']=orig1;s['max_original_state_start']=start;s['max_original_state_reduced_step']=steps;s['max_original_state_original_step']=Ab+1
            elif cur1:
                if v==1:
                    cur1+=1
                    if cur1>s['max_v1_run'] or (cur1==s['max_v1_run'] and (s['max_v1_run_start']==0 or start<s['max_v1_run_start'])):
                        s['max_v1_run']=cur1;s['max_v1_run_start']=start;s['max_v1_run_begin_step']=curbegin;s['max_v1_run_end_step']=steps
                else:cur1=curbegin=0
            if not ofdA:
                z=orig1
                for t in range(1,v+1):
                    if z<start:ofdA=Ab+t;ofdj=steps;ofdstate=z;break
                    if t<v:z//=3
            crossed=(3**A>4**steps)
            if not bcj and crossed:
                bcj=steps
                if not fdj and y>=start:s['barrier_cross_pre_descent_no_descent']+=1
            if not fdj and y<start:
                fdj=steps;fdA=A
                if crossed:s['first_reduced_descent_at_or_above_barrier']+=1
                else:s['first_reduced_descent_below_barrier']+=1
            x=y
    return s

def main():
    ap=argparse.ArgumentParser();ap.add_argument('start',type=int);ap.add_argument('end',type=int);ap.add_argument('--base',type=int,required=True);ap.add_argument('--output',type=Path)
    a=ap.parse_args();d=scan(a.start,a.end,a.base);txt=json.dumps(d,indent=2,sort_keys=True)+'\n'
    if a.output:a.output.write_text(txt)
    else:print(txt,end='')
if __name__=='__main__':main()
