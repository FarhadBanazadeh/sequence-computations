#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,hashlib
from pathlib import Path

EVENT_ARRAYS=['barrier_survive','actual_survive','discrepancy','discrepancy_below_barrier_descent','discrepancy_above_barrier_nondesc','theory_cutoff_violations']
EVENT_SUMS=['first_reduced_descent_found','no_reduced_descent_certified','no_reduced_descent_unresolved','total_first_reduced_descent_edges','total_original_steps_at_first_reduced_descent','first_reduced_descent_at_or_above_barrier','first_reduced_descent_below_barrier','first_reduced_descent_barrier_unknown','barrier_cross_pre_descent_no_descent','first_barrier_found','no_first_barrier_certified','no_first_barrier_unresolved','total_first_barrier_edges','barrier_before_reduced_descent','reduced_descent_before_barrier','barrier_descent_same_edge','first_original_descent_found','no_original_descent_certified','no_original_descent_unresolved','total_first_original_descent_steps']
EVENT_RECORDS=['max_first_reduced_descent_edges','max_original_steps_at_first_reduced_descent','max_first_original_descent','max_first_barrier_edges','max_barrier_to_descent_gap','max_descent_to_barrier_gap']
CERTIFICATE_RECORDS=['max_reduced_steps','max_original_steps']
GLOBAL_RECORDS=['max_reduced_state','max_original_state','max_single_valuation','max_v1_run']

def load(p): return json.loads(Path(p).read_text())
def recmax(a,b,key):
    A=a['records'][key];B=b['records'][key]
    va=A['value'];vb=B['value']
    if vb>va:return B
    if va>vb:return A
    sa=A.get('start',0);sb=B.get('start',0)
    if va and sb and (not sa or sb<sa):return B
    return A

def main():
    ap=argparse.ArgumentParser();ap.add_argument('base_summary');ap.add_argument('extension_summary');ap.add_argument('--output-dir',type=Path,required=True);ap.add_argument('--base-end',type=int,default=1000000000);ap.add_argument('--end',type=int,default=100000000000);a=ap.parse_args()
    b=load(a.base_summary);e=load(a.extension_summary)
    if b['scan_mode']!='full' or b['range']!=[1,a.base_end]: raise SystemExit('base summary identity mismatch')
    if e['scan_mode']!='certificate' or e['base_threshold']!=a.base_end or e['range']!=[a.base_end+1,a.end]: raise SystemExit('extension summary identity mismatch')
    if b['source_sha256']!=e['source_sha256']: raise SystemExit('source hash mismatch')
    if not b['clean'] or not e['clean']: raise SystemExit('cannot combine unclean phases')
    total_adm=b['sums']['admissible']+e['sums']['admissible']; total_cert=b['sums']['certified_to1']+e['sums']['certified_to1']
    out={
      'statement':'finite exhaustive certification through 10^11 using fresh full base scan plus fresh extension certificate scan',
      'source_sha256':b['source_sha256'],'scanner_version':b['scanner_version'],
      'base_phase':{'range':b['range'],'admissible':b['sums']['admissible'],'certified':b['sums']['certified_to1'],'seconds':b['total_chunk_seconds'],'semantics':'full accelerated trajectories to 1'},
      'extension_phase':{'range':e['range'],'admissible':e['sums']['admissible'],'certified':e['sums']['certified_to1'],'seconds':e['total_chunk_seconds'],'base_threshold':a.base_end,'semantics':'accelerated certificate segments to the freshly verified base; first-descent/barrier events are followed exactly as needed'},
      'combined':{'admissible':total_adm,'certified':total_cert,'expected_admissible':a.end-a.end//3,'clean': total_adm==total_cert==a.end-a.end//3},
      'horizons':b['horizons'],
      'event_sums':{k:b['sums'][k]+e['sums'][k] for k in EVENT_SUMS},
      'event_arrays':{k:[x+y for x,y in zip(b['arrays'][k],e['arrays'][k])] for k in EVENT_ARRAYS},
      'certificate_records':{k:recmax(b,e,k) for k in CERTIFICATE_RECORDS},
      'event_records':{k:recmax(b,e,k) for k in EVENT_RECORDS},
      'global_records':{k:recmax(b,e,k) for k in GLOBAL_RECORDS},
      'segment_statistics_note':'Full-to-1 stopping-time and edge histograms are meaningful only for the base phase. Extension total_reduced_steps/total_original_steps and valuation/sign histograms refer to certificate segments before entry into [1,10^9]. They are intentionally not mislabeled as full-orbit totals.',
      'global_record_note':'Peak state and maximum valuation after extension entry into the base are covered by the fresh full base scan. max_v1_run in the extension phase follows a run across the certificate boundary until it breaks, so the max of base and extension records covers boundary-crossing runs.'
    }
    a.output_dir.mkdir(parents=True,exist_ok=True)
    (a.output_dir/'COMBINED_SUMMARY.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    lines=[
      'TERNARY (4k±1)/3 COMBINED FRESH VERIFICATION',
      f"source_sha256={out['source_sha256']}",
      f"base_admissible={out['base_phase']['admissible']}",f"extension_admissible={out['extension_phase']['admissible']}",
      f"combined_admissible={total_adm}",f"combined_certified={total_cert}",f"clean={str(out['combined']['clean']).lower()}",
      f"base_seconds={out['base_phase']['seconds']:.6f}",f"extension_seconds={out['extension_phase']['seconds']:.6f}",f"total_chunk_seconds={out['base_phase']['seconds']+out['extension_phase']['seconds']:.6f}",
      'NOTE: extension step/valuation totals are certificate-segment totals, not full-to-1 orbit totals.'
    ]
    (a.output_dir/'COMBINED_SUMMARY.txt').write_text('\n'.join(lines)+'\n')
    if not out['combined']['clean']: raise SystemExit('combined count check failed')
    print(json.dumps({'admissible':total_adm,'certified':total_cert,'clean':True,'source_sha256':out['source_sha256']},indent=2))
if __name__=='__main__':main()
