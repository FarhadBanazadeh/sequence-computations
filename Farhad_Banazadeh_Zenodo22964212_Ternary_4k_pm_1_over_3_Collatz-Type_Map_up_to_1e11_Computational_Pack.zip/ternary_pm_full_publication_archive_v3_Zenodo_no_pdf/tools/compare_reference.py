#!/usr/bin/env python3
import argparse,json
from pathlib import Path
LIST_KEYS={'val_hist','joint_plus','joint_minus','initial_val_hist','first_reduced_descent_hist','first_reduced_descent_original_hist','first_original_descent_hist','first_barrier_hist','total_reduced_steps_hist','total_original_steps_hist','barrier_survive','actual_survive','discrepancy','discrepancy_below_barrier_descent','discrepancy_above_barrier_nondesc','discrepancy_max_start','theory_cutoff_violations'}
def parse_done(p):
 d={}
 for line in Path(p).read_text().splitlines():
  if '=' not in line:continue
  k,v=line.split('=',1)
  if k in LIST_KEYS:d[k]=[int(x) for x in v.split(',')]
  else:
   try:d[k]=int(v)
   except ValueError:d[k]=v
 return d
ap=argparse.ArgumentParser();ap.add_argument('checkpoint');ap.add_argument('reference');a=ap.parse_args()
c=parse_done(a.checkpoint); r=json.loads(Path(a.reference).read_text())
missing=[];diff=[]
for k,v in r.items():
 if k not in c: missing.append(k)
 elif c[k]!=v: diff.append((k,c[k],v))
print(f'compared={len(r)} missing={len(missing)} diffs={len(diff)}')
for k in missing:print('MISSING',k)
for k,a1,b1 in diff[:100]:print('DIFF',k,'C=',a1,'PY=',b1)
raise SystemExit(1 if missing or diff else 0)
