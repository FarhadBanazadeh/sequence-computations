#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path

def load(p): return json.loads(Path(p).read_text())

def one_step(x:int,start:int):
    r=x%3
    if r==1: sigma=1; num=4*x-1
    elif r==2: sigma=-1; num=4*x+1
    else: raise AssertionError((x,r))
    a=0; original_first=None; first_original_descent=None
    while True:
        num//=3; a+=1
        if original_first is None: original_first=num
        if first_original_descent is None and num<start: first_original_descent=(a,num)
        if num%3: break
    return num,sigma,a,original_first,first_original_descent

def replay(start:int,base:int,certificate:bool,tsv:Path):
    x=start; j=0; A=0; C=0
    cert_step=None; cert_A=None; cert_state=None
    fd_j=fd_A=0; ofd_A=ofd_j=ofd_state=0; bc_j=0
    max_red=x; max_red_j=0; max_red_A=0
    max_orig=x; max_orig_j=0; max_orig_A=0
    max_v=0; max_v_j=0; max_v_state=0; max_v_sign=0
    cur_run=0; cur_begin=0; max_run=0; max_run_begin=0; max_run_end=0
    segment_done=False; crossing_run_active=False
    rows=[]
    while True:
        if certificate and not segment_done and x<=base:
            segment_done=True; cert_step=j; cert_A=A; cert_state=x
            crossing_run_active=cur_run>0
            if not fd_j: fd_j=j; fd_A=A
        if x==1:
            if not certificate:
                cert_step=j; cert_A=A; cert_state=x
            break
        # In certificate semantics we may stop after the first barrier is known and
        # any a=1 run crossing the boundary has ended. Full replay keeps going to 1
        # for a strong independent reconstruction, but segment records stop updating.
        y,sigma,a,orig1,od=one_step(x,start)
        A_before=A; C_before=C
        j+=1; A+=a; C=4*C+sigma*pow(3,A_before)
        assert pow(3,A)*y == pow(4,j)*start-C
        if not ofd_A and od:
            off,state=od; ofd_A=A_before+off; ofd_j=j; ofd_state=state
        crossed=A>int((pow(4,j)).bit_length()) if False else (pow(3,A)>pow(4,j))
        if not bc_j and crossed: bc_j=j
        if not fd_j and y<start: fd_j=j; fd_A=A

        update_segment = (not certificate) or (not segment_done)
        if update_segment:
            if y>max_red: max_red=y; max_red_j=j; max_red_A=A
            if orig1>max_orig: max_orig=orig1; max_orig_j=j; max_orig_A=A_before+1
            if a>max_v: max_v=a; max_v_j=j; max_v_state=x; max_v_sign=sigma
            if a==1:
                if cur_run==0: cur_begin=j
                cur_run+=1
                if cur_run>max_run:
                    max_run=cur_run;max_run_begin=cur_begin;max_run_end=j
            else: cur_run=0;cur_begin=0
        elif crossing_run_active:
            if a==1:
                cur_run+=1
                if cur_run>max_run:
                    max_run=cur_run;max_run_begin=cur_begin;max_run_end=j
            else:
                cur_run=0;cur_begin=0;crossing_run_active=False

        rows.append((j,A_before,x,sigma,a,y,A,C_before,C,orig1,max_red,max_orig,int(y<start),int(crossed),int(certificate and y<=base and cert_step is None)))
        x=y
        if j>10_000_000: raise RuntimeError(f'step limit replaying {start}')

    with tsv.open('w') as f:
        f.write('j\tA_before\tx\tsigma\ta\tnext_x\tA_after\tC_before\tC_after\toriginal_first\trunning_reduced_peak\trunning_original_peak\tnext_below_start\tbarrier_crossed\tentry_edge_to_base\n')
        for row in rows: f.write('\t'.join(map(str,row))+'\n')
    if certificate and cert_step is None: raise AssertionError(f'no base entry for {start}')
    return {
      'start':start,'full_reduced_steps_to_1':j,'full_original_steps_to_1':A,
      'certificate_step':cert_step,'certificate_original_steps':cert_A,'certificate_endpoint':cert_state,
      'first_reduced_descent':fd_j,'original_steps_at_first_reduced_descent':fd_A,
      'first_original_descent':ofd_A,'first_original_descent_reduced_edge':ofd_j,'first_original_descent_state':ofd_state,
      'first_barrier':bc_j,
      'max_reduced_state_segment':max_red,'max_reduced_state_segment_step':max_red_j,'max_reduced_state_segment_original_step':max_red_A,
      'max_original_state_segment':max_orig,'max_original_state_segment_reduced_step':max_orig_j,'max_original_state_segment_original_step':max_orig_A,
      'max_single_valuation_segment':max_v,'max_single_valuation_segment_step':max_v_j,'max_single_valuation_segment_state':max_v_state,'max_single_valuation_segment_sign':max_v_sign,
      'max_v1_run_segment_or_crossing':max_run,'max_v1_run_begin_step':max_run_begin,'max_v1_run_end_step':max_run_end,
      'barrier_to_descent_gap': max(0,fd_j-bc_j) if fd_j and bc_j else 0,
      'descent_to_barrier_gap': max(0,bc_j-fd_j) if fd_j and bc_j else 0,
    }

def verify_records(summary, stats_by_start, certificate):
    errs=[]
    mapping={
      'max_reduced_steps':'certificate_step',
      'max_original_steps':'certificate_original_steps',
      'max_first_reduced_descent_edges':'first_reduced_descent',
      'max_original_steps_at_first_reduced_descent':'original_steps_at_first_reduced_descent',
      'max_first_original_descent':'first_original_descent',
      'max_reduced_state':'max_reduced_state_segment',
      'max_original_state':'max_original_state_segment',
      'max_single_valuation':'max_single_valuation_segment',
      'max_v1_run':'max_v1_run_segment_or_crossing',
      'max_first_barrier_edges':'first_barrier',
      'max_barrier_to_descent_gap':'barrier_to_descent_gap',
      'max_descent_to_barrier_gap':'descent_to_barrier_gap',
    }
    for key,field in mapping.items():
        rec=summary['records'].get(key) or {}
        val=int(rec.get('value',0)); st=int(rec.get('start',0) or 0)
        if not val: continue
        if st not in stats_by_start: errs.append(f'{key}: missing replay for start {st}');continue
        got=int(stats_by_start[st][field] or 0)
        if got!=val: errs.append(f'{key}: start {st}: aggregate={val} replay={got} field={field}')
    return errs

def main():
    ap=argparse.ArgumentParser();ap.add_argument('base_summary');ap.add_argument('extension_summary');ap.add_argument('--base',type=int,default=1_000_000_000);ap.add_argument('--output-dir',type=Path,required=True);a=ap.parse_args()
    base=load(a.base_summary); ext=load(a.extension_summary)
    if base['source_sha256']!=ext['source_sha256']: raise SystemExit('source hash mismatch')
    starts=set()
    for s in (base,ext):
        for r in s['records'].values():
            st=int((r or {}).get('start',0) or 0)
            if st: starts.add(st)
        for v in s['arrays'].get('discrepancy_max_start',[]):
            if int(v): starts.add(int(v))
    a.output_dir.mkdir(parents=True,exist_ok=True)
    stats={}
    for st in sorted(starts):
        cert=st>a.base
        tsv=a.output_dir/f'start_{st}.tsv'
        stats[st]=replay(st,a.base,cert,tsv)
    errs=[]
    errs+=['base: '+e for e in verify_records(base,stats,False)]
    errs+=['extension: '+e for e in verify_records(ext,stats,True)]
    out={'source_sha256':base['source_sha256'],'base_threshold':a.base,'starts':stats,'errors':errs,'clean':not errs}
    (a.output_dir/'RECORD_REPLAY_SUMMARY.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    (a.output_dir/'RECORD_REPLAY_SUMMARY.txt').write_text(f"source_sha256={out['source_sha256']}\nstarts_replayed={len(starts)}\nclean={str(not errs).lower()}\n"+'\n'.join(errs)+'\n')
    print(json.dumps({'starts_replayed':len(starts),'clean':not errs,'errors':errs},indent=2))
    if errs: raise SystemExit(3)
if __name__=='__main__': main()
