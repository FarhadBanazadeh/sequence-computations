#!/usr/bin/env python3
from pathlib import Path
import argparse
ap=argparse.ArgumentParser(); ap.add_argument('--output',default='source/barrier_small.h'); ap.add_argument('--max-j',type=int,default=8192); a=ap.parse_args()
P=190537; Q=150997
vals=[(j*P)//Q for j in range(a.max_j+1)]
p=Path(a.output)
with p.open('w') as f:
    f.write('/* Auto-generated exact floor(j*log_3 4) lookup within certified range. */\n')
    f.write('#ifndef BARRIER_SMALL_H\n#define BARRIER_SMALL_H\n#include <stdint.h>\n')
    f.write(f'#define BARRIER_SMALL_MAX_J {a.max_j}U\n')
    f.write(f'static const uint16_t BARRIER_SMALL_FLOOR[{a.max_j+1}] = {{\n')
    for i in range(0,len(vals),24): f.write('  '+','.join(str(x) for x in vals[i:i+24])+',\n')
    f.write('};\n#endif\n')
