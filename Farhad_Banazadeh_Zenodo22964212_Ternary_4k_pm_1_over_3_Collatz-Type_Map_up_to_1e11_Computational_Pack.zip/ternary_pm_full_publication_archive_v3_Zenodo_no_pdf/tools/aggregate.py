#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path

HORIZONS=[6,10,20,25,30,40,50,100,200,500]
DESC_HIST_MAX=4096
STOP_HIST_MAX=8192
ARRAY_SUM_KEYS=[
    'val_hist','joint_plus','joint_minus','initial_val_hist',
    'first_reduced_descent_hist','first_reduced_descent_original_hist','first_original_descent_hist','first_barrier_hist','total_reduced_steps_hist','total_original_steps_hist',
    'barrier_survive','actual_survive','discrepancy',
    'discrepancy_below_barrier_descent','discrepancy_above_barrier_nondesc',
    'theory_cutoff_violations'
]
ARRAY_MAX_KEYS=['discrepancy_max_start']
SUM_KEYS=[
    'raw_count','admissible','excluded_mult3','certified_to1','unknown_cycle','overflow','invariant_fail','step_limit','barrier_certificate_exceeded',
    'total_reduced_steps','total_original_steps','sign_plus','sign_minus','initial_plus','initial_minus',
    'first_reduced_descent_found','no_reduced_descent_certified','no_reduced_descent_unresolved','total_first_reduced_descent_edges','total_original_steps_at_first_reduced_descent',
    'first_reduced_descent_at_or_above_barrier','first_reduced_descent_below_barrier','first_reduced_descent_barrier_unknown','barrier_cross_pre_descent_no_descent',
    'first_barrier_found','no_first_barrier_certified','no_first_barrier_unresolved','total_first_barrier_edges','barrier_before_reduced_descent','reduced_descent_before_barrier','barrier_descent_same_edge',
    'first_original_descent_found','no_original_descent_certified','no_original_descent_unresolved','total_first_original_descent_steps'
]
MAX_RECORDS={
 'max_reduced_steps':('max_reduced_steps_start',),
 'max_original_steps':('max_original_steps_start',),
 'max_first_reduced_descent_edges':('max_first_reduced_descent_edges_start','original_steps_at_max_first_reduced_descent'),
 'max_original_steps_at_first_reduced_descent':('max_original_steps_at_first_reduced_descent_start','reduced_edges_at_max_original_steps_first_reduced_descent'),
 'max_first_original_descent':('max_first_original_descent_start','max_first_original_descent_reduced_edge','max_first_original_descent_state'),
 'max_reduced_state':('max_reduced_state_start','max_reduced_state_step','max_reduced_state_original_step'),
 'max_original_state':('max_original_state_start','max_original_state_reduced_step','max_original_state_original_step'),
 'max_single_valuation':('max_single_valuation_start','max_single_valuation_state','max_single_valuation_reduced_step','max_single_valuation_sign'),
 'max_v1_run':('max_v1_run_start','max_v1_run_begin_step','max_v1_run_end_step'),
 'max_first_barrier_edges':('max_first_barrier_start',),
 'max_barrier_to_descent_gap':('max_barrier_to_descent_gap_start',),
 'max_descent_to_barrier_gap':('max_descent_to_barrier_gap_start',),
 'max_discrepancy_start_any':(),
}
FIRST_KEYS=['first_unknown_start','first_overflow_start','first_invariant_start','first_step_limit_start']
PAIR_STATE={'first_unknown_start':'first_unknown_state','first_overflow_start':'first_overflow_state','first_invariant_start':'first_invariant_state'}

def parse_list(s:str): return [int(x) for x in s.split(',')] if s else []
def parse_done(p:Path):
    d={}
    for ln,line in enumerate(p.read_text().splitlines(),1):
        if not line or line.startswith('#'): continue
        if '=' not in line: raise ValueError(f'{p}:{ln}: malformed line')
        k,v=line.split('=',1)
        if k in d: raise ValueError(f'{p}:{ln}: duplicate key {k}')
        d[k]=v
    return d

def req(d,k,p):
    if k not in d: raise ValueError(f'{p}: missing {k}')
    return d[k]
def I(d,k,p): return int(req(d,k,p))
def admissible(lo,hi): return hi-lo+1-(hi//3-(lo-1)//3)
def sha256(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def choose_record(cur, d, key, p):
    v=I(d,key,p); startkey=MAX_RECORDS[key][0] if MAX_RECORDS[key] else None
    start=I(d,startkey,p) if startkey else 0
    if cur is None: take=True
    else:
        cv=cur['value']; cs=cur.get('start',0)
        take=v>cv or (v==cv and v!=0 and startkey and (cs==0 or start<cs))
    if take:
        out={'value':v}
        if startkey: out['start']=start
        for extra in MAX_RECORDS[key][1:]: out[extra]=I(d,extra,p)
        return out
    return cur

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('results_dir',type=Path)
    ap.add_argument('--expect-start',type=int)
    ap.add_argument('--expect-end',type=int)
    ap.add_argument('--require-clean',action='store_true',help='fail if any unresolved/anomaly/table exhaustion/theory violation')
    ap.add_argument('--project-root',type=Path,help='verify checkpoint source_sha256 against current source+generated headers')
    args=ap.parse_args(); root=args.results_dir
    files=sorted(root.glob('chunk_*.done'))
    if not files: raise SystemExit('no chunk_*.done files')
    agg={k:0 for k in SUM_KEYS}; arrays={}; arrmax={}; records={k:None for k in MAX_RECORDS}
    first={k:0 for k in FIRST_KEYS}; first_states={}
    identity=None; prev_hi=None; total_sec=0.0
    chunk_rows=[]
    manifests=[]
    for seq,p in enumerate(files,1):
        d=parse_done(p)
        fmt=I(d,'format_version',p); ver=req(d,'scanner_version',p); src=req(d,'source_sha256',p)
        dh=I(d,'desc_hist_max',p); sh=I(d,'stop_hist_max',p)
        if dh!=DESC_HIST_MAX or sh!=STOP_HIST_MAX: raise ValueError(f'{p}: histogram cap mismatch')
        mode=req(d,'scan_mode',p); base=I(d,'base_threshold',p); ident=(fmt,ver,src,mode,base,req(d,'horizons_values',p),dh,sh)
        if identity is None: identity=ident
        elif ident!=identity: raise ValueError(f'{p}: identity mismatch {ident} != {identity}')
        idx=I(d,'index',p); lo=I(d,'lo',p); hi=I(d,'hi',p)
        if idx!=seq: raise ValueError(f'{p}: expected index {seq}, got {idx}')
        if hi<lo: raise ValueError(f'{p}: hi<lo')
        if prev_hi is not None and lo!=prev_hi+1: raise ValueError(f'{p}: gap/overlap: prev_hi={prev_hi} lo={lo}')
        prev_hi=hi
        raw=I(d,'raw_count',p); adm=I(d,'admissible',p); excl=I(d,'excluded_mult3',p)
        if raw!=hi-lo+1 or excl!=raw-adm or adm!=admissible(lo,hi): raise ValueError(f'{p}: domain count mismatch')
        unresolved=sum(I(d,k,p) for k in ['unknown_cycle','overflow','invariant_fail','step_limit'])
        if I(d,'certified_to1',p)+unresolved!=adm: raise ValueError(f'{p}: terminal count mismatch')
        totalr=I(d,'total_reduced_steps',p)
        if I(d,'sign_plus',p)+I(d,'sign_minus',p)!=totalr: raise ValueError(f'{p}: sign totals != reduced steps')
        vh=parse_list(req(d,'val_hist',p)); jp=parse_list(req(d,'joint_plus',p)); jm=parse_list(req(d,'joint_minus',p)); iv=parse_list(req(d,'initial_val_hist',p))
        if not (len(vh)==len(jp)==len(jm)==len(iv)==81): raise ValueError(f'{p}: valuation histogram length !=81')
        if sum(vh)!=totalr or sum(jp)+sum(jm)!=totalr or any(vh[i]!=jp[i]+jm[i] for i in range(81)): raise ValueError(f'{p}: valuation/joint mismatch')
        init_expected=adm-(1 if lo<=1<=hi else 0)
        if I(d,'initial_plus',p)+I(d,'initial_minus',p)!=init_expected or sum(iv)!=init_expected: raise ValueError(f'{p}: initial histogram mismatch')
        if I(d,'first_reduced_descent_found',p)+I(d,'no_reduced_descent_certified',p)+I(d,'no_reduced_descent_unresolved',p)!=adm: raise ValueError(f'{p}: reduced descent status mismatch')
        if I(d,'first_original_descent_found',p)+I(d,'no_original_descent_certified',p)+I(d,'no_original_descent_unresolved',p)!=adm: raise ValueError(f'{p}: original descent status mismatch')
        if I(d,'first_barrier_found',p)+I(d,'no_first_barrier_certified',p)+I(d,'no_first_barrier_unresolved',p)!=adm: raise ValueError(f'{p}: barrier status mismatch')
        hfd=parse_list(req(d,'first_reduced_descent_hist',p)); hfdo=parse_list(req(d,'first_reduced_descent_original_hist',p)); hofd=parse_list(req(d,'first_original_descent_hist',p)); hbc=parse_list(req(d,'first_barrier_hist',p)); htr=parse_list(req(d,'total_reduced_steps_hist',p)); hto=parse_list(req(d,'total_original_steps_hist',p))
        if len(hfd)!=DESC_HIST_MAX+2 or len(hbc)!=DESC_HIST_MAX+2 or any(len(x)!=STOP_HIST_MAX+2 for x in [hfdo,hofd,htr,hto]): raise ValueError(f'{p}: distribution histogram length mismatch')
        if sum(hfd)!=I(d,'first_reduced_descent_found',p) or sum(hfdo)!=I(d,'first_reduced_descent_found',p): raise ValueError(f'{p}: reduced descent histogram mismatch')
        if sum(hofd)!=I(d,'first_original_descent_found',p): raise ValueError(f'{p}: original descent histogram mismatch')
        if sum(hbc)!=I(d,'first_barrier_found',p): raise ValueError(f'{p}: barrier histogram mismatch')
        if sum(htr)!=I(d,'certified_to1',p) or sum(hto)!=I(d,'certified_to1',p): raise ValueError(f'{p}: stopping histogram mismatch')
        hs=parse_list(req(d,'horizons_values',p));
        if hs!=HORIZONS: raise ValueError(f'{p}: horizon list mismatch')
        for k in ['barrier_survive','actual_survive','discrepancy','discrepancy_below_barrier_descent','discrepancy_above_barrier_nondesc','discrepancy_max_start','theory_cutoff_violations']:
            ar=parse_list(req(d,k,p))
            if len(ar)!=len(HORIZONS): raise ValueError(f'{p}: {k} length mismatch')
        disc=parse_list(d['discrepancy']); db=parse_list(d['discrepancy_below_barrier_descent']); da=parse_list(d['discrepancy_above_barrier_nondesc'])
        if any(disc[i]!=db[i]+da[i] for i in range(len(HORIZONS))): raise ValueError(f'{p}: discrepancy decomposition mismatch')
        for k in SUM_KEYS: agg[k]+=I(d,k,p)
        for k in ARRAY_SUM_KEYS:
            ar=parse_list(req(d,k,p)); arrays.setdefault(k,[0]*len(ar)); arrays[k]=[a+b for a,b in zip(arrays[k],ar)]
        for k in ARRAY_MAX_KEYS:
            ar=parse_list(req(d,k,p)); arrmax.setdefault(k,[0]*len(ar)); arrmax[k]=[max(a,b) for a,b in zip(arrmax[k],ar)]
        for k in MAX_RECORDS: records[k]=choose_record(records[k],d,k,p)
        for k in FIRST_KEYS:
            v=I(d,k,p)
            if v and (first[k]==0 or v<first[k]):
                first[k]=v
                if k in PAIR_STATE: first_states[PAIR_STATE[k]]=I(d,PAIR_STATE[k],p)
        sec=float(req(d,'seconds',p)); total_sec+=sec
        anomaly=p.with_name(p.stem+'.anomalies.tsv')
        if not anomaly.exists(): raise ValueError(f'{p}: missing anomaly file {anomaly.name}')
        manifests += [(p.name,sha256(p)),(anomaly.name,sha256(anomaly))]
        lines=anomaly.read_text().splitlines()
        anomaly_rows=max(0,len(lines)-1)
        if anomaly_rows>0 and unresolved==0 and I(d,'barrier_certificate_exceeded',p)==0: raise ValueError(f'{p}: unexplained anomaly rows')
        chunk_rows.append({'index':idx,'lo':lo,'hi':hi,'admissible':adm,'seconds':sec,'unresolved':unresolved,'anomaly_rows':anomaly_rows})
    start=chunk_rows[0]['lo']; end=chunk_rows[-1]['hi']
    if args.expect_start is not None and start!=args.expect_start: raise ValueError(f'expected start {args.expect_start}, got {start}')
    if args.expect_end is not None and end!=args.expect_end: raise ValueError(f'expected end {args.expect_end}, got {end}')
    if args.project_root is not None:
        pr=args.project_root
        parts=[pr/'source/scan_ternary_pm_v4.c',pr/'source/audit_discrepancy50.c',pr/'source/barrier_exact.h',pr/'source/barrier_small.h',pr/'source/theory_cutoffs.h']
        h=hashlib.sha256()
        for pp in parts:
            if not pp.exists(): raise ValueError(f'missing project hash input {pp}')
            h.update(pp.read_bytes())
        actual=h.hexdigest()
        if actual!=identity[2]: raise ValueError(f'checkpoint source hash {identity[2]} != current project hash {actual}')
    if agg['raw_count']!=end-start+1 or agg['admissible']!=admissible(start,end): raise ValueError('global domain count mismatch')
    unresolved=sum(agg[k] for k in ['unknown_cycle','overflow','invariant_fail','step_limit'])
    # derived direct-map branch totals
    derived={
        'original_branch_plus':agg['sign_plus'],
        'original_branch_minus':agg['sign_minus'],
        'original_branch_div3':agg['total_original_steps']-agg['total_reduced_steps'],
        'unresolved':unresolved,
    }
    clean=(unresolved==0 and agg['barrier_certificate_exceeded']==0 and sum(arrays['theory_cutoff_violations'])==0 and all(r['anomaly_rows']==0 for r in chunk_rows))
    out={
        'format_version':identity[0],'scanner_version':identity[1],'source_sha256':identity[2],'scan_mode':identity[3],'base_threshold':identity[4],
        'range':[start,end],'chunks':len(chunk_rows),'horizons':HORIZONS,'desc_hist_max':DESC_HIST_MAX,'stop_hist_max':STOP_HIST_MAX,'total_chunk_seconds':total_sec,
        'sums':agg,'arrays':arrays|arrmax,'records':records,'first_events':first|first_states,'derived':derived,'clean':clean,
        'chunk_rows':chunk_rows,
    }
    (root/'aggregate_summary.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    # concise text
    txt=[]
    txt += [f'scanner_version={identity[1]}',f'source_sha256={identity[2]}',f'scan_mode={identity[3]}',f'base_threshold={identity[4]}',f'range={start}..{end}',f'chunks={len(chunk_rows)}',f'admissible={agg["admissible"]}',f'certified_to1={agg["certified_to1"]}',f'unresolved={unresolved}',f'clean={str(clean).lower()}']
    txt += [f'total_reduced_steps={agg["total_reduced_steps"]}',f'total_original_steps={agg["total_original_steps"]}',f'original_branch_div3={derived["original_branch_div3"]}',f'original_branch_plus={derived["original_branch_plus"]}',f'original_branch_minus={derived["original_branch_minus"]}']
    for k,r in records.items(): txt.append(f'{k}={r}')
    for k in ['barrier_survive','actual_survive','discrepancy','theory_cutoff_violations']: txt.append(f'{k}={arrays[k]}')
    (root/'aggregate_summary.txt').write_text('\n'.join(txt)+'\n')
    # records table
    with (root/'records.tsv').open('w') as f:
        f.write('metric\tvalue\tstart\tdetails\n')
        for k,r in records.items():
            details={kk:vv for kk,vv in r.items() if kk not in {'value','start'}}
            f.write(f'{k}\t{r["value"]}\t{r.get("start","")}\t{json.dumps(details,sort_keys=True)}\n')
    # manifest after summary outputs exist, excluding manifest itself
    allfiles=sorted([p for p in root.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'])
    (root/'SHA256SUMS.txt').write_text(''.join(f'{sha256(p)}  {p.name}\n' for p in allfiles))
    print(json.dumps({'range':[start,end],'chunks':len(chunk_rows),'admissible':agg['admissible'],'certified':agg['certified_to1'],'unresolved':unresolved,'clean':clean,'source_sha256':identity[2],'scan_mode':identity[3],'base_threshold':identity[4]},indent=2))
    if args.require_clean and not clean: raise SystemExit(3)

if __name__=='__main__':
    try: main()
    except Exception as e:
        print(f'AGGREGATE AUDIT FAILURE: {e}',file=sys.stderr); raise SystemExit(2)
