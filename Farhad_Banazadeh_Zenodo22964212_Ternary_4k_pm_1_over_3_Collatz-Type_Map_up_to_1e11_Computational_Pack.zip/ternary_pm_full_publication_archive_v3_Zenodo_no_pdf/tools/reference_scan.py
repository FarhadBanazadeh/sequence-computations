#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

H=[6,10,20,25,30,40,50,100,200,500]
CUT=[41,82,8808,29471,38211,1060106,84746117,29226808579889,None,None]
VMAX=80
DESC_HIST_MAX=4096
STOP_HIST_MAX=8192

def v3(n):
    k=0
    while n%3==0:
        n//=3;k+=1
    return k,n

def step(x):
    r=x%3
    if r==1: sign=1; num=4*x-1
    elif r==2: sign=-1; num=4*x+1
    else: raise ValueError('bad state')
    k,y=v3(num)
    assert k>=1 and y%3 and y%2==1
    return y,num,num//3,sign,k

def better(v,start,oldv,oldstart): return v>oldv or (v==oldv and v!=0 and (oldstart==0 or start<oldstart))

def init_stats():
    return {
      'raw_count':0,'admissible':0,'excluded_mult3':0,'certified_to1':0,'unknown_cycle':0,'overflow':0,'invariant_fail':0,'step_limit':0,'barrier_certificate_exceeded':0,
      'total_reduced_steps':0,'total_original_steps':0,'sign_plus':0,'sign_minus':0,'initial_plus':0,'initial_minus':0,
      'val_hist':[0]*81,'joint_plus':[0]*81,'joint_minus':[0]*81,'initial_val_hist':[0]*81,
      'desc_hist_max':DESC_HIST_MAX,'stop_hist_max':STOP_HIST_MAX,
      'first_reduced_descent_hist':[0]*(DESC_HIST_MAX+2),'first_reduced_descent_original_hist':[0]*(STOP_HIST_MAX+2),
      'first_original_descent_hist':[0]*(STOP_HIST_MAX+2),'first_barrier_hist':[0]*(DESC_HIST_MAX+2),
      'total_reduced_steps_hist':[0]*(STOP_HIST_MAX+2),'total_original_steps_hist':[0]*(STOP_HIST_MAX+2),
      'first_reduced_descent_found':0,'no_reduced_descent_certified':0,'no_reduced_descent_unresolved':0,
      'total_first_reduced_descent_edges':0,'total_original_steps_at_first_reduced_descent':0,
      'first_reduced_descent_at_or_above_barrier':0,'first_reduced_descent_below_barrier':0,'first_reduced_descent_barrier_unknown':0,'barrier_cross_pre_descent_no_descent':0,
      'first_barrier_found':0,'no_first_barrier_certified':0,'no_first_barrier_unresolved':0,'total_first_barrier_edges':0,'max_first_barrier_edges':0,'max_first_barrier_start':0,'barrier_before_reduced_descent':0,'reduced_descent_before_barrier':0,'barrier_descent_same_edge':0,'max_barrier_to_descent_gap':0,'max_barrier_to_descent_gap_start':0,'max_descent_to_barrier_gap':0,'max_descent_to_barrier_gap_start':0,
      'barrier_survive':[0]*10,'actual_survive':[0]*10,'discrepancy':[0]*10,'discrepancy_below_barrier_descent':[0]*10,'discrepancy_above_barrier_nondesc':[0]*10,'discrepancy_max_start':[0]*10,'theory_cutoff_violations':[0]*10,
      'max_reduced_steps':0,'max_reduced_steps_start':0,'max_original_steps':0,'max_original_steps_start':0,
      'max_first_reduced_descent_edges':0,'max_first_reduced_descent_edges_start':0,'original_steps_at_max_first_reduced_descent':0,
      'max_original_steps_at_first_reduced_descent':0,'max_original_steps_at_first_reduced_descent_start':0,'reduced_edges_at_max_original_steps_first_reduced_descent':0,
      'first_original_descent_found':0,'no_original_descent_certified':0,'no_original_descent_unresolved':0,'total_first_original_descent_steps':0,
      'max_first_original_descent':0,'max_first_original_descent_start':0,'max_first_original_descent_reduced_edge':0,'max_first_original_descent_state':0,
      'max_v1_run':0,'max_v1_run_start':0,'max_v1_run_begin_step':0,'max_v1_run_end_step':0,
      'max_reduced_state':0,'max_reduced_state_start':0,'max_reduced_state_step':0,'max_reduced_state_original_step':0,
      'max_original_state':0,'max_original_state_start':0,'max_original_state_reduced_step':0,'max_original_state_original_step':0,
      'max_single_valuation':0,'max_single_valuation_start':0,'max_single_valuation_state':0,'max_single_valuation_reduced_step':0,'max_single_valuation_sign':0,
      'max_discrepancy_start_any':0,
      'first_unknown_start':0,'first_unknown_state':0,'first_overflow_start':0,'first_overflow_state':0,'first_invariant_start':0,'first_invariant_state':0,'first_step_limit_start':0,
    }

def scan(lo,hi):
    s=init_stats()
    for start in range(lo,hi+1):
        s['raw_count']+=1
        if start%3==0:
            s['excluded_mult3']+=1; continue
        s['admissible']+=1
        x=start; steps=A=0; fdj=fdA=0; ofdA=ofdj=ofdstate=0; bcj=0; cur1=cur1begin=0
        seen=set()
        if better(x,start,s['max_reduced_state'],s['max_reduced_state_start']):
            s['max_reduced_state']=x;s['max_reduced_state_start']=start;s['max_reduced_state_step']=0;s['max_reduced_state_original_step']=0
        if better(x,start,s['max_original_state'],s['max_original_state_start']):
            s['max_original_state']=x;s['max_original_state_start']=start;s['max_original_state_reduced_step']=0;s['max_original_state_original_step']=0
        while x!=1:
            if x in seen: raise AssertionError(f'cycle {start} {x}')
            seen.add(x)
            y,num,orig1,sign,v=step(x)
            assert v<=VMAX
            # mod-4 / mod-8 checks
            chi=1 if y%4==1 else -1 if y%4==3 else 0
            assert chi and sign== (chi if v%2 else -chi)
            if x%2:
                exp=(1 if v%2 else 3) if sign>0 else (7 if v%2 else 5)
                assert y%8==exp
            steps+=1; Ab=A; A+=v
            if sign>0:s['sign_plus']+=1
            else:s['sign_minus']+=1
            s['val_hist'][v]+=1; s['joint_plus' if sign>0 else 'joint_minus'][v]+=1
            if steps==1:
                s['initial_plus' if sign>0 else 'initial_minus']+=1;s['initial_val_hist'][v]+=1
            if v==1:
                if cur1==0:cur1begin=steps
                cur1+=1
                old=(s['max_v1_run'],s['max_v1_run_start'],s['max_v1_run_begin_step'])
                if cur1>old[0] or (cur1==old[0] and cur1 and (old[1]==0 or start<old[1] or (start==old[1] and cur1begin<old[2]))):
                    s['max_v1_run']=cur1;s['max_v1_run_start']=start;s['max_v1_run_begin_step']=cur1begin;s['max_v1_run_end_step']=steps
            else:cur1=cur1begin=0
            if not ofdA:
                z=orig1
                for t in range(1,v+1):
                    if z<start:
                        ofdA=Ab+t;ofdj=steps;ofdstate=z;break
                    if t<v:z//=3
            if v>s['max_single_valuation'] or (v==s['max_single_valuation'] and (s['max_single_valuation_start']==0 or start<s['max_single_valuation_start'])):
                s['max_single_valuation']=v;s['max_single_valuation_start']=start;s['max_single_valuation_state']=x;s['max_single_valuation_reduced_step']=steps;s['max_single_valuation_sign']=sign
            if better(y,start,s['max_reduced_state'],s['max_reduced_state_start']):
                s['max_reduced_state']=y;s['max_reduced_state_start']=start;s['max_reduced_state_step']=steps;s['max_reduced_state_original_step']=A
            if better(orig1,start,s['max_original_state'],s['max_original_state_start']):
                s['max_original_state']=orig1;s['max_original_state_start']=start;s['max_original_state_reduced_step']=steps;s['max_original_state_original_step']=Ab+1
            crossed=(3**A>4**steps)
            if not bcj and crossed:
                bcj=steps
                if not fdj and y>=start:s['barrier_cross_pre_descent_no_descent']+=1
            if not fdj and y<start:
                fdj=steps;fdA=A
                if crossed:s['first_reduced_descent_at_or_above_barrier']+=1
                else:s['first_reduced_descent_below_barrier']+=1
            x=y
        # certified finish
        s['certified_to1']+=1;s['total_reduced_steps']+=steps;s['total_original_steps']+=A
        s['total_reduced_steps_hist'][steps if steps<=STOP_HIST_MAX else STOP_HIST_MAX+1]+=1
        s['total_original_steps_hist'][A if A<=STOP_HIST_MAX else STOP_HIST_MAX+1]+=1
        if better(steps,start,s['max_reduced_steps'],s['max_reduced_steps_start']):s['max_reduced_steps']=steps;s['max_reduced_steps_start']=start
        if better(A,start,s['max_original_steps'],s['max_original_steps_start']):s['max_original_steps']=A;s['max_original_steps_start']=start
        if fdj:
            s['first_reduced_descent_found']+=1;s['total_first_reduced_descent_edges']+=fdj;s['total_original_steps_at_first_reduced_descent']+=fdA
            s['first_reduced_descent_hist'][fdj if fdj<=DESC_HIST_MAX else DESC_HIST_MAX+1]+=1
            s['first_reduced_descent_original_hist'][fdA if fdA<=STOP_HIST_MAX else STOP_HIST_MAX+1]+=1
            if better(fdj,start,s['max_first_reduced_descent_edges'],s['max_first_reduced_descent_edges_start']):
                s['max_first_reduced_descent_edges']=fdj;s['max_first_reduced_descent_edges_start']=start;s['original_steps_at_max_first_reduced_descent']=fdA
            if better(fdA,start,s['max_original_steps_at_first_reduced_descent'],s['max_original_steps_at_first_reduced_descent_start']):
                s['max_original_steps_at_first_reduced_descent']=fdA;s['max_original_steps_at_first_reduced_descent_start']=start;s['reduced_edges_at_max_original_steps_first_reduced_descent']=fdj
        else:s['no_reduced_descent_certified']+=1
        if ofdA:
            s['first_original_descent_found']+=1;s['total_first_original_descent_steps']+=ofdA
            s['first_original_descent_hist'][ofdA if ofdA<=STOP_HIST_MAX else STOP_HIST_MAX+1]+=1
            if better(ofdA,start,s['max_first_original_descent'],s['max_first_original_descent_start']):
                s['max_first_original_descent']=ofdA;s['max_first_original_descent_start']=start;s['max_first_original_descent_reduced_edge']=ofdj;s['max_first_original_descent_state']=ofdstate
        else:s['no_original_descent_certified']+=1
        if bcj:
            s['first_barrier_found']+=1;s['total_first_barrier_edges']+=bcj
            s['first_barrier_hist'][bcj if bcj<=DESC_HIST_MAX else DESC_HIST_MAX+1]+=1
            if better(bcj,start,s['max_first_barrier_edges'],s['max_first_barrier_start']):s['max_first_barrier_edges']=bcj;s['max_first_barrier_start']=start
        else:s['no_first_barrier_certified']+=1
        if fdj and bcj:
            if bcj<fdj:
                s['barrier_before_reduced_descent']+=1;gap=fdj-bcj
                if better(gap,start,s['max_barrier_to_descent_gap'],s['max_barrier_to_descent_gap_start']):s['max_barrier_to_descent_gap']=gap;s['max_barrier_to_descent_gap_start']=start
            elif fdj<bcj:
                s['reduced_descent_before_barrier']+=1;gap=bcj-fdj
                if better(gap,start,s['max_descent_to_barrier_gap'],s['max_descent_to_barrier_gap_start']):s['max_descent_to_barrier_gap']=gap;s['max_descent_to_barrier_gap_start']=start
            else:s['barrier_descent_same_edge']+=1
        elif fdj:s['reduced_descent_before_barrier']+=1
        elif bcj:s['barrier_before_reduced_descent']+=1
        for i,m in enumerate(H):
            bs=(bcj==0 or bcj>m); ac=(fdj==0 or fdj>m)
            if bs:s['barrier_survive'][i]+=1
            if ac:s['actual_survive'][i]+=1
            if bs!=ac:
                s['discrepancy'][i]+=1
                if (not ac) and bs:s['discrepancy_below_barrier_descent'][i]+=1
                if ac and (not bs):s['discrepancy_above_barrier_nondesc'][i]+=1
                s['discrepancy_max_start'][i]=max(s['discrepancy_max_start'][i],start);s['max_discrepancy_start_any']=max(s['max_discrepancy_start_any'],start)
                if CUT[i] is not None and start>=CUT[i]:s['theory_cutoff_violations'][i]+=1
    return s

def main():
    ap=argparse.ArgumentParser();ap.add_argument('start',type=int);ap.add_argument('end',type=int);ap.add_argument('--output',type=Path)
    a=ap.parse_args(); s=scan(a.start,a.end); txt=json.dumps(s,indent=2,sort_keys=True)+'\n'
    if a.output:a.output.write_text(txt)
    else:print(txt,end='')
if __name__=='__main__':main()
