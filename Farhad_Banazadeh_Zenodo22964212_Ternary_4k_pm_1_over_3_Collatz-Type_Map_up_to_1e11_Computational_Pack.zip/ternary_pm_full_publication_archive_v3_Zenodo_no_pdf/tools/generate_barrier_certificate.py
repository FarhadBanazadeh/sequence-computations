#!/usr/bin/env python3
"""Verify and emit a finite exact certificate for floor(j log_3 4).

Certified adjacent rational bounds:
  190537/150997 < log_3(4) < 21372011/16936918.
The cross determinant is 1, so no rational with denominator < q_lo+q_hi
lies strictly between them. Therefore for every integer 1 <= j < q_lo+q_hi,
  floor(j log_3 4) = floor(j*p_lo/q_lo).
The side inequalities are verified without floating point by comparing 3^p and 4^q.
"""
from pathlib import Path
import argparse,json,time
P=argparse.ArgumentParser();P.add_argument('--header',type=Path,default=Path('source/barrier_exact.h'));P.add_argument('--certificate',type=Path,default=Path('BARRIER_EXACT_CERTIFICATE.json'));a=P.parse_args()
plo,qlo=190537,150997
phi,qhi=21372011,16936918
det=phi*qlo-plo*qhi
if det!=1: raise SystemExit(f'determinant !=1: {det}')
t=time.time()
lo_ok=pow(3,plo) < (1 << (2*qlo))
hi_ok=pow(3,phi) > (1 << (2*qhi))
if not (lo_ok and hi_ok): raise SystemExit('side inequality failed')
maxj=qlo+qhi-1
header=f'''/* Auto-generated/verified by tools/generate_barrier_certificate.py. */
#ifndef BARRIER_EXACT_H
#define BARRIER_EXACT_H
#include <stdint.h>
#define ALPHA_LO_P {plo}ULL
#define ALPHA_LO_Q {qlo}ULL
#define ALPHA_HI_P {phi}ULL
#define ALPHA_HI_Q {qhi}ULL
#define BARRIER_CERT_MAX_J {maxj}ULL
#endif
'''
a.header.write_text(header)
a.certificate.write_text(json.dumps({
 'alpha':'log_3(4)','lower':[plo,qlo],'upper':[phi,qhi],'cross_determinant':det,
 'lower_cert':'3^p < 4^q','upper_cert':'3^p > 4^q','lower_ok':lo_ok,'upper_ok':hi_ok,
 'denominator_sum':qlo+qhi,'certified_max_j':maxj,
 'conclusion':'floor(j*log_3(4)) = floor(j*p_lo/q_lo) for 1 <= j <= certified_max_j',
 'verification_seconds':time.time()-t
},indent=2)+'\n')
print(f'certified through j={maxj}')
