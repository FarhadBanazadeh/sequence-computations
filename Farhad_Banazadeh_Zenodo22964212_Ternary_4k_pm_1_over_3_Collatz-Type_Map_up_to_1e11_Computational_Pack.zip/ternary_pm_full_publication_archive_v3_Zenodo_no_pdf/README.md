# Fresh publication scan for the ternary (4k ± 1)/3 map

This package is the fresh, audit-oriented computational release for the paper on

\[
F(k)=\begin{cases}
k/3,&k\equiv0\pmod3,\\
(4k-1)/3,&k\equiv1\pmod3,\\
(4k+1)/3,&k\equiv2\pmod3.
\end{cases}
\]

The production scanner works with the accelerated map on admissible starts `3 ∤ n`.  It is designed so that one invocation of `run_full_scan.sh` produces the complete publication archive without repeating the expensive `10^11` scan.

## Why the production run has two phases

The run is fresh from zero; it does **not** trust the old `10^9` base computation.

1. **Fresh full base:** every admissible `1 <= n <= 10^9` is followed all the way to the fixed point `1`.
2. **Fresh extension certificate:** every admissible `10^9 < n <= 10^11` is followed until it enters the freshly verified base interval.  That entry certifies convergence to `1`.  First-descent and barrier events are continued beyond the entry only when needed to determine those events exactly; an `a=1` run crossing the boundary is continued until it breaks.

This removes billions of redundant tail iterations while preserving the quantities required by the paper.  Extension step/sign/valuation totals are explicitly labelled **certificate-segment totals**, not full-to-1 tail totals.  See `DATA_SCOPE.md` for the exact semantics.

## Release identity

- Scanner version: `pm-accelerated-v4.0-freshcert`
- Checkpoint format: `4`
- Production domain: `1 <= n <= 100000000000`, `3 ∤ n`
- Expected admissible starts: `66,666,666,667`
- Fresh base threshold: `1,000,000,000`
- Default chunk: `100,000,000` raw integers
- Default threads: `4`

The exact source hash is printed by `./build.sh` and by every checkpoint.  Do not edit `source/` or the generated exact-certificate files after starting production.

## macOS workflow

From Terminal, inside the extracted folder:

```bash
chmod +x *.sh
./validate_release.sh
./benchmark_release.sh
```

The validation must end with:

```text
RELEASE VALIDATION PASSED
```

The benchmark measures this exact release on the local Mac and prints a conservative estimated scan time.  Review that output before starting the long run.

Then start production with:

```bash
THREADS=4 CHUNK=100000000 ./run_full_scan.sh
```

On macOS the script automatically relaunches itself under `caffeinate -is`, so the computation is protected from system idle sleep while the Terminal process remains running.  Keep the Mac connected to power.

In a second Terminal you may run:

```bash
cd ~/Desktop/ternary_pm_scan_fresh_v4
./monitor_progress.sh
```

The monitor is read-only and does not affect the scan.

## Resume behavior

Every chunk is written atomically.  If the run is interrupted, rerun the same command.  A checkpoint is skipped only when its interval, scan mode, base threshold, format version, scanner version, and source hash all match.  Stale or incompatible checkpoints are refused.

## What the production workflow automatically creates

The result directory (default `results_fresh_1e11`) contains:

- hardware/compiler/run metadata;
- a copy of the exact binaries used;
- project source hashes;
- full base checkpoints and anomaly files;
- extension certificate checkpoints and anomaly files;
- strict independent aggregate summaries for both phases;
- an independent finite-discrepancy audit through the complete explicit `m=50` zone;
- the complete discrepancy-case TSV for horizons through 50;
- the combined finite-certification summary through `10^11`;
- exact replay/trajectory TSV files for every global record start;
- record-replay verification summaries;
- final recursive SHA-256 manifest for the entire archive.

## Validation architecture

`validate_release.sh` checks the C scanner against independent arbitrary-precision Python implementations in both full and certificate modes, checks an invariant-heavy build, verifies deterministic results under different chunking, tests checkpoint identity rejection, checks the independent discrepancy enumerator, combines a split test domain, and replays all test record starts.

The full production hot loop is optimized, but the mathematical outputs are not reduced to samples.  Expensive redundant invariant checks are additionally exercised in the full-invariant validation build; structural checks and failure counters remain active in production.

## Important interpretation rule

For the base phase, stopping-time totals and histograms are full trajectories to `1`.

For the extension phase, `total_reduced_steps`, `total_original_steps`, sign counts, valuation histograms, and stopping histograms refer to the segment up to first entry into `[1,10^9]`.  They are deliberately not described as full-to-1 extension totals.  Terminal certification, exact first-descent data, barrier data, finite-horizon survivor counts, global peaks, maximum valuation, and the longest `a=1` run are preserved with the semantics documented in `DATA_SCOPE.md`.
