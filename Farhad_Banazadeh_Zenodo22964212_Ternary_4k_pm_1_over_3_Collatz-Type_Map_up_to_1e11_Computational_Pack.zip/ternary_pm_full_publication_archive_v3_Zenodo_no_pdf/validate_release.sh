#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"
V="validation/release_check"; rm -rf "$V"; mkdir -p "$V"
echo "[1/7] production build + full reference"
BASE_FLAGS='-O3 -march=native -flto -std=c11 -pthread -Wall -Wextra -Wformat=2 -Wshadow -Wconversion -Wsign-conversion -Werror'
INV_FLAGS='-O3 -march=native -std=c11 -pthread -Wall -Wextra -Wformat=2 -Wshadow -Wconversion -Wsign-conversion -Werror -DFULL_INVARIANTS=1'
CC=clang CFLAGS="$BASE_FLAGS" ./build.sh > "$V/build_clang.log" 2>&1; cp scanner "$V/scanner_prod"; cp audit_discrepancy50 "$V/audit_discrepancy50_prod"
# Full base-mode vs arbitrary-precision Python reference.
"$V/scanner_prod" full 0 1 5000 5000 4 "$V/full5k" > "$V/full100k.log"
python3 tools/reference_scan.py 1 5000 --output "$V/ref_full5k.json"
python3 tools/compare_reference.py "$V/full5k/chunk_000001.done" "$V/ref_full5k.json"
python3 tools/aggregate.py "$V/full5k" --expect-start 1 --expect-end 5000 --require-clean --project-root . >/dev/null
# Independent horizon<=50 discrepancy enumerator agrees with the production scanner on the same domain.
"$V/audit_discrepancy50_prod" 5000 "$V/discrepancy5k.tsv" > "$V/discrepancy5k.log"
python3 - <<'PY'
import json,re
s=json.load(open('validation/release_check/full5k/aggregate_summary.json')); t=open('validation/release_check/discrepancy5k.log').read()
for i,h in enumerate([6,10,20,25,30,40,50]):
 m=re.search(rf'horizon_{h}_count=(\d+)',t); assert m,(h,t)
 assert int(m.group(1))==s['arrays']['discrepancy'][i],(h,m.group(1),s['arrays']['discrepancy'][i])
print('independent discrepancy enumerator: PASS')
PY
echo "[2/7] certificate reference"
# Certificate-mode vs independent Python reference.
"$V/scanner_prod" certificate 1000 1001 2000 1000 4 "$V/cert1k" > "$V/cert19k.log"
python3 tools/reference_certificate.py 1001 2000 --base 1000 --output "$V/ref_cert1k.json"
python3 tools/compare_reference.py "$V/cert1k/chunk_000001.done" "$V/ref_cert1k.json"
python3 tools/aggregate.py "$V/cert1k" --expect-start 1001 --expect-end 2000 --require-clean --project-root . >/dev/null
echo "[3/7] full-invariant validation build"
# Full invariant build checks mod-3/mod-4/mod-8 on every edge in validation ranges.
CC=clang CFLAGS="$INV_FLAGS" ./build.sh > "$V/build_full_invariants.log" 2>&1; cp scanner "$V/scanner_full_invariants"
"$V/scanner_full_invariants" full 0 1 2000 2000 4 "$V/inv_full2k" >/dev/null
python3 tools/reference_scan.py 1 2000 --output "$V/ref_full2k.json"
python3 tools/compare_reference.py "$V/inv_full2k/chunk_000001.done" "$V/ref_full2k.json"
"$V/scanner_full_invariants" certificate 1000 1001 1500 500 4 "$V/inv_cert500" >/dev/null
python3 tools/reference_certificate.py 1001 1500 --base 1000 --output "$V/ref_cert500.json"
python3 tools/compare_reference.py "$V/inv_cert500/chunk_000001.done" "$V/ref_cert500.json"
echo "[4/7] deterministic chunking"
# Determinism under chunking.
"$V/scanner_prod" full 0 1 5000 1250 4 "$V/full_chunked" >/dev/null
python3 tools/aggregate.py "$V/full_chunked" --expect-start 1 --expect-end 5000 --require-clean --project-root . >/dev/null
"$V/scanner_prod" certificate 1000 1001 2000 250 4 "$V/cert_chunked" >/dev/null
python3 tools/aggregate.py "$V/cert_chunked" --expect-start 1001 --expect-end 2000 --require-clean --project-root . >/dev/null
python3 - <<'PY'
import json
from pathlib import Path
pairs=[('full5k','full_chunked'),('cert1k','cert_chunked')]
for a,b in pairs:
 A=json.loads(Path(f'validation/release_check/{a}/aggregate_summary.json').read_text())
 B=json.loads(Path(f'validation/release_check/{b}/aggregate_summary.json').read_text())
 for k in ['sums','arrays','records','first_events','derived','clean','range','horizons','desc_hist_max','stop_hist_max','scanner_version','source_sha256','scan_mode','base_threshold']:
  assert A[k]==B[k],(a,b,k)
print('release validation: deterministic payload confirmed')
PY
echo "[5/7] split-domain combine + record replay"
# End-to-end combine audit on a small split domain [1,5000] with base 1000.
"$V/scanner_prod" full 0 1 1000 1000 4 "$V/combine_base" >/dev/null
python3 tools/aggregate.py "$V/combine_base" --expect-start 1 --expect-end 1000 --require-clean --project-root . >/dev/null
python3 tools/combine_results.py "$V/combine_base/aggregate_summary.json" "$V/cert1k/aggregate_summary.json" --output-dir "$V/combined" --base-end 1000 --end 2000 >/dev/null
python3 tools/replay_records.py "$V/combine_base/aggregate_summary.json" "$V/cert1k/aggregate_summary.json" --base 1000 --output-dir "$V/record_replay" >/dev/null
echo "[6/7] stale checkpoint identity rejection"
# Check checkpoint mode/base identity protection: wrong-mode reuse must fail.
set +e
"$V/scanner_prod" full 0 1001 2000 1000 4 "$V/cert1k" >/dev/null 2>"$V/stale_identity.err"
rc=$?
set -e
[ "$rc" -ne 0 ] || { echo 'ERROR: stale mode/base checkpoint was not rejected'; exit 1; }
echo "[7/7] restore validated production binaries"
# Restore the already validated production binary without another expensive LTO rebuild.
cp "$V/scanner_prod" scanner
cp "$V/audit_discrepancy50_prod" audit_discrepancy50
cp "$V/scanner_prod" "$V/scanner_final"
echo 'RELEASE VALIDATION PASSED'
