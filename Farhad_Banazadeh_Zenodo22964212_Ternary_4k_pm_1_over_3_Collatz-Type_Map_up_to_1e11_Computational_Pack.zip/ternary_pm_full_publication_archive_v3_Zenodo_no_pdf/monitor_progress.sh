#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"
RESULTS="${RESULTS:-results_fresh_1e11}"; BASE="${BASE:-1000000000}"; END="${END:-100000000000}"; CHUNK="${CHUNK:-100000000}"
btot=$(( (BASE + CHUNK - 1) / CHUNK )); etot=$(( (END-BASE + CHUNK - 1) / CHUNK )); total=$((btot+etot))
while true; do
  b=$(find "$RESULTS/base_full" -name 'chunk_*.done' 2>/dev/null | wc -l | tr -d ' ')
  e=$(find "$RESULTS/extension_certificate" -name 'chunk_*.done' 2>/dev/null | wc -l | tr -d ' ')
  n=$((b+e)); pct=$(awk -v n="$n" -v t="$total" 'BEGIN{printf "%.1f",100*n/t}')
  clear; echo "===================================================="; echo " Ternary (4k±1)/3 fresh scan through 10^11"; echo "===================================================="
  echo "Base full chunks       : $b / $btot"; echo "Extension cert chunks  : $e / $etot"; echo "Overall chunks         : $n / $total"; echo "Overall progress       : $pct %"; echo
  if [ "$e" -gt 0 ]; then f=$(find "$RESULTS/extension_certificate" -name 'chunk_*.done' | sort | tail -1); elif [ "$b" -gt 0 ]; then f=$(find "$RESULTS/base_full" -name 'chunk_*.done' | sort | tail -1); else f=""; fi
  if [ -n "$f" ]; then echo "Latest checkpoint: $f"; grep -E '^(scan_mode|index|lo|hi|seconds|admissible|certified_to1|unknown_cycle|overflow|invariant_fail|step_limit|barrier_certificate_exceeded)=' "$f" || true; fi
  echo; echo "Updated: $(date)"; sleep 10
done
