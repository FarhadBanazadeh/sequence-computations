#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"
THREADS="${THREADS:-4}"; V="validation/benchmark"; rm -rf "$V"; mkdir -p "$V"
./build.sh >/dev/null
python3 - <<'PY'
print('Benchmarking 10 million raw integers in each phase...')
PY
./scanner full 0 1 10000000 10000000 "$THREADS" "$V/base_low10m" | tee "$V/base.log"
./scanner certificate 1000000000 99990000001 100000000000 10000000 "$THREADS" "$V/ext_top10m" | tee "$V/ext.log"
python3 - <<'PY'
import re
from pathlib import Path
def sec(p):
 t=Path(p).read_text(); m=re.search(r'chunk 1/1 .*? sec=([0-9.]+)',t); return float(m.group(1))
b=sec('validation/benchmark/base.log'); e=sec('validation/benchmark/ext.log')
# 10 base chunks of 100m = 100 benchmark units; extension 990 chunks = 9900 benchmark units.
est=100*b+9900*e
print(f'base_10m_seconds={b:.3f}')
print(f'extension_top_10m_seconds={e:.3f}')
print(f'conservative_estimated_scan_hours={est/3600:.2f}')
print('This is conservative because the extension benchmark is taken at the very top of the domain.')
PY
