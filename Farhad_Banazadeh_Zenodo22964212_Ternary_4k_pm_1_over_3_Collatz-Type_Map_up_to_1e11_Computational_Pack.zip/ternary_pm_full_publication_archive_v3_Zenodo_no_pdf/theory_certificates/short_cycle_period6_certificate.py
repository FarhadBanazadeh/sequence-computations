#!/usr/bin/env python3
"""Exact finite certificate for the period <= 6 exclusion used in the paper.

The proof itself is largely hand algebra.  This script independently checks the
only residual signed congruence at period 4 after the product-localization bound.
"""
from itertools import product

# For a nontrivial positive cycle every state is odd and !=1, hence min >= 5.
# Exact integer-power comparisons showing the only possible total valuation A
# for ell=2..6 is (ell,A)=(4,5).
checks = {
    2: ((19**2, 5**2 * 3**2, '>'), (21**2, 5**2 * 3**3, '<')),
    3: ((19**3, 5**3 * 3**3, '>'), (21**3, 5**3 * 3**4, '<')),
    4: ((19**4, 5**4 * 3**4, '>'), (19**4, 5**4 * 3**5, '<'),
        (21**4, 5**4 * 3**5, '>'), (21**4, 5**4 * 3**6, '<')),
    5: ((19**5, 5**5 * 3**6, '>'), (21**5, 5**5 * 3**7, '<')),
    6: ((19**6, 5**6 * 3**7, '>'), (21**6, 5**6 * 3**8, '<')),
}

def ok(a,b,op):
    return a>b if op=='>' else a<b
for ell, rows in checks.items():
    for row in rows:
        assert ok(*row), (ell,row)

# For ell=4,A=5, rotate so valuations are (1,1,1,2).
# Then C = 64*s0+48*s1+36*s2+27*s3 and D=4^4-3^5=13.
residues=[]
for s in product((-1,1), repeat=4):
    C=64*s[0]+48*s[1]+36*s[2]+27*s[3]
    residues.append(C % 13)
    assert C % 13 != 0, (s,C)

print('period<=6 certificate: PASS')
print('period-4 residues mod 13:', sorted(set(residues)))
