#!/usr/bin/env python3
"""Certificate data for the computationally-assisted cycle-length lower bound.

Uses the verified minimum-state exclusion m > 10^11 and standard Legendre
continued-fraction theory.  The script checks every rational inequality used in
the paper exactly, except that the two logarithmic brackets are certified by
integer power comparisons (also present in BARRIER_EXACT_CERTIFICATE.json).
"""
from fractions import Fraction

M=100_000_000_001
eps=Fraction(1,4*M-1)
qmax=150_996
assert 4*M-1 > 2*qmax*qmax

rminus=Fraction(31_202,24_727)
rplus=Fraction(31_867,25_254)
c10=Fraction(190_537,150_997)
c11=Fraction(21_372_011,16_936_918)

# Consecutive convergent determinants around the relevant region.
assert 31_202*25_254 - 31_867*24_727 == -1
assert 31_867*150_997 - 190_537*25_254 == 1
assert 190_537*16_936_918 - 21_372_011*150_997 == -1

# Exact rational gaps used to place the cycle-localization window inside
# (31202/24727, 31867/25254).
assert c10-rminus == Fraction(5,3_733_702_819)
assert rplus-c11 == Fraction(28,106_931_231_793)
assert c10-rminus > eps
assert rplus-c11 > eps

# Exact bracketing of alpha=log_3(4): p/q < alpha iff 3^p < 4^q.
# These are the same endpoint checks stored in BARRIER_EXACT_CERTIFICATE.json.
assert pow(3,190_537) < pow(4,150_997)
assert pow(3,21_372_011) > pow(4,16_936_918)

# Continued-fraction prefix through the lower certified bracket.
cf=[1,3,1,4,1,1,11,1,46,1,5]
p0,p1=0,1
q0,q1=1,0
convs=[]
for a in cf:
    p=a*p1+p0; q=a*q1+q0
    convs.append((p,q))
    p0,p1=p1,p; q0,q1=q1,q
assert convs[-3:] == [(31_202,24_727),(31_867,25_254),(190_537,150_997)]
# The upper bracket has continued fraction equal to the same prefix followed by 112.
def cf_of_fraction(fr):
    p,q=fr.numerator,fr.denominator; out=[]
    while q:
        a=p//q; out.append(a); p,q=q,p-a*q
    return out
assert cf_of_fraction(c10) == cf
assert cf_of_fraction(c11) == cf+[112]

# A >= 190537 once ell >= 150997 because L > rminus and
# 150997*rminus is already > 190536.
assert Fraction(150_997)*rminus > 190_536

print('cycle-length lower-bound certificate: PASS')
print('epsilon =', eps)
print('epsilon < 1/(2*150996^2):', eps < Fraction(1,2*qmax*qmax))
print('c10-rminus =', c10-rminus)
print('rplus-c11 =', rplus-c11)
print('continued-fraction prefix =', cf)
print('relevant convergents =', convs[-3:])
print('upper rational bracket =', c11)
