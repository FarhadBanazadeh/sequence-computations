# Auxiliary theory certificates

These files support two theorem-level additions that are logically separate from the frozen production scan.

## `short_cycle_period6_certificate.py`

Checks the exact rational power comparisons used to reduce periods 2--6 to the sole candidate `(ell,A)=(4,5)`, then checks the 16 signed period-4 residues modulo 13.  The paper also gives the corresponding hand proof.

## `cycle_length_lower_bound_certificate.py`

Checks the exact rational inequalities used in the finite-verification-assisted cycle bound.  It verifies:

- `epsilon = 1/(400000000003)` is smaller than the Legendre threshold for every denominator at most 150,996;
- the relevant continued-fraction convergents are `31202/24727`, `31867/25254`, and `190537/150997`;
- the rational upper bracket `21372011/16936918` shares the certified continued-fraction prefix;
- exact power comparisons bracket `log_3(4)`;
- the rational gap inequalities place the cycle-localization interval between the preceding two convergents.

These scripts were added after production.  They do not modify the scanner source, production binaries, production checkpoints, or the frozen production source/certificate identity.
