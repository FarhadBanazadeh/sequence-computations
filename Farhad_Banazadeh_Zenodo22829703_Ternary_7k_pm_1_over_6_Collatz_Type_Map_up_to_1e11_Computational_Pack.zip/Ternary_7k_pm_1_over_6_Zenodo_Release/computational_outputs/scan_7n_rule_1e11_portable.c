#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>

typedef unsigned __int128 u128;

/* ========================= USER CONFIG ========================= */

static const uint64_t LIMIT = 100000000000ULL;       /* 10^11 */
static const uint64_t GROUPS_PER_CHUNK = 5000000ULL; /* ~10,000,000 valid starts/chunk */
static const uint64_t CHECKPOINT_EVERY_CHUNKS = 10ULL;
static const uint64_t PRINT_EVERY_CHUNKS = 1ULL;
static const uint32_t MAX_PATH_STEPS = 1000000U;      /* safety cap */

#define TOPK 10
#define MAX_LOCAL_RECORDS 256
#define CHECKPOINT_FILE "scan_checkpoint.bin"
#define CHECKPOINT_TMP  "scan_checkpoint.tmp"
#define PROGRESS_CSV    "scan_progress.csv"
#define HISTORY_BIN     "chunk_history.bin"
#define FINAL_SUMMARY   "final_summary.txt"
#define TOP_STOP_CSV    "top10_stopping.csv"
#define TOP_TOTAL_CSV   "top10_total_steps.csv"
#define TOP_PEAK_CSV    "top10_peaks.csv"
#define HIST_CSV        "historical_stopping_records.csv"
#define CYCLES_CSV      "cycles.csv"
#define UNRESOLVED_CSV  "unresolved.csv"

/* =============================================================== */

typedef struct {
    uint64_t n;
    uint32_t sigma;
    u128 first_lower;
} StopEntry;

typedef struct {
    uint64_t n;
    uint32_t steps;
} TotalEntry;

typedef struct {
    uint64_t n;
    u128 peak;
    uint32_t steps_to_peak;
} PeakEntry;

typedef struct {
    uint64_t n;
    uint32_t sigma;
    u128 first_lower;
} HistEntry;

typedef struct {
    uint32_t count;
    uint32_t overflow;
    HistEntry rec[MAX_LOCAL_RECORDS];
} ChunkHistory;

typedef struct {
    uint64_t starts;
    uint64_t reached_one;
    uint64_t cycles;
    uint64_t unresolved;

    StopEntry top_stop[TOPK];
    TotalEntry top_total[TOPK];
    PeakEntry top_peak[TOPK];

    ChunkHistory history;

    uint64_t chunk_id;
    uint64_t k_begin;
    uint64_t k_end;
    double seconds;
} ChunkResult;

typedef struct {
    char magic[16];
    uint32_t version;
    uint32_t reserved;

    uint64_t limit;
    uint64_t groups_per_chunk;
    uint64_t num_chunks;

    uint64_t completed_chunks;
    uint64_t starts;
    uint64_t reached_one;
    uint64_t cycles;
    uint64_t unresolved;

    StopEntry top_stop[TOPK];
    TotalEntry top_total[TOPK];
    PeakEntry top_peak[TOPK];
} CheckpointHeader;

typedef enum {
    PATH_REACHED_ONE = 0,
    PATH_CYCLE = 1,
    PATH_UNRESOLVED = 2
} PathStatus;

typedef struct {
    PathStatus status;
    uint32_t total_steps;
    uint32_t sigma;
    u128 first_lower;
    u128 peak;
    uint32_t steps_to_peak;
    u128 last_value;
    uint32_t cycle_length_hint;
} PathResult;

/* ------------------------- globals ------------------------- */

static uint64_t g_num_groups = 0;
static uint64_t g_num_chunks = 0;

static atomic_uint_fast64_t g_next_chunk;
static atomic_bool g_stop_requested;

static pthread_mutex_t g_merge_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t g_log_mu   = PTHREAD_MUTEX_INITIALIZER;

static uint8_t *g_done = NULL;

static CheckpointHeader g_state;

static FILE *g_progress_fp = NULL;
static FILE *g_cycles_fp = NULL;
static FILE *g_unresolved_fp = NULL;

static int g_history_fd = -1;

/* ------------------------- utilities ------------------------- */

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

static void u128_to_str(u128 v, char *buf, size_t cap) {
    char tmp[64];
    size_t i = 0;

    if (cap == 0) return;
    if (v == 0) {
        if (cap >= 2) { buf[0] = '0'; buf[1] = '\0'; }
        return;
    }

    while (v > 0 && i < sizeof(tmp)) {
        tmp[i++] = (char)('0' + (unsigned)(v % 10));
        v /= 10;
    }

    size_t out = 0;
    while (i > 0 && out + 1 < cap) {
        buf[out++] = tmp[--i];
    }
    buf[out] = '\0';
}

static inline bool valid_start_u64(uint64_t n) {
    return (n & 1ULL) && (n % 3ULL != 0ULL);
}

static inline u128 strip_2_3(u128 x) {
    while ((x & 1u) == 0u) x >>= 1;
    while (x % 3u == 0u) x /= 3u;
    return x;
}

/*
 T(n) for n odd and not divisible by 3:
   n == 1 mod 6 -> R((7n-1)/6)
   n == 5 mod 6 -> R((7n+1)/6)
*/
static inline u128 T(u128 n) {
    const unsigned r = (unsigned)(n % 6u);
    u128 x;

    if (r == 1u) {
        x = (7u * n - 1u) / 6u;
    } else if (r == 5u) {
        x = (7u * n + 1u) / 6u;
    } else {
        /* This should never happen if invariants hold. */
        return 0;
    }

    return strip_2_3(x);
}

/* ------------------------- top-k helpers ------------------------- */

static bool stop_better(const StopEntry *a, const StopEntry *b) {
    if (a->sigma != b->sigma) return a->sigma > b->sigma;
    if (a->n == 0) return false;
    if (b->n == 0) return true;
    return a->n < b->n;
}

static bool total_better(const TotalEntry *a, const TotalEntry *b) {
    if (a->steps != b->steps) return a->steps > b->steps;
    if (a->n == 0) return false;
    if (b->n == 0) return true;
    return a->n < b->n;
}

static bool peak_better(const PeakEntry *a, const PeakEntry *b) {
    if (a->peak != b->peak) return a->peak > b->peak;
    if (a->n == 0) return false;
    if (b->n == 0) return true;
    return a->n < b->n;
}

static void insert_stop(StopEntry arr[TOPK], StopEntry e) {
    if (e.n == 0 || e.sigma == 0) return;

    for (int i = 0; i < TOPK; ++i) {
        if (arr[i].n == e.n) {
            if (stop_better(&e, &arr[i])) arr[i] = e;
            return;
        }
    }

    int pos = -1;
    for (int i = 0; i < TOPK; ++i) {
        if (arr[i].n == 0 || stop_better(&e, &arr[i])) {
            pos = i;
            break;
        }
    }
    if (pos < 0) return;

    for (int i = TOPK - 1; i > pos; --i) arr[i] = arr[i - 1];
    arr[pos] = e;
}

static void insert_total(TotalEntry arr[TOPK], TotalEntry e) {
    if (e.n == 0) return;

    for (int i = 0; i < TOPK; ++i) {
        if (arr[i].n == e.n) {
            if (total_better(&e, &arr[i])) arr[i] = e;
            return;
        }
    }

    int pos = -1;
    for (int i = 0; i < TOPK; ++i) {
        if (arr[i].n == 0 || total_better(&e, &arr[i])) {
            pos = i;
            break;
        }
    }
    if (pos < 0) return;

    for (int i = TOPK - 1; i > pos; --i) arr[i] = arr[i - 1];
    arr[pos] = e;
}

static void insert_peak(PeakEntry arr[TOPK], PeakEntry e) {
    if (e.n == 0) return;

    for (int i = 0; i < TOPK; ++i) {
        if (arr[i].n == e.n) {
            if (peak_better(&e, &arr[i])) arr[i] = e;
            return;
        }
    }

    int pos = -1;
    for (int i = 0; i < TOPK; ++i) {
        if (arr[i].n == 0 || peak_better(&e, &arr[i])) {
            pos = i;
            break;
        }
    }
    if (pos < 0) return;

    for (int i = TOPK - 1; i > pos; --i) arr[i] = arr[i - 1];
    arr[pos] = e;
}

/* ------------------------- path analysis ------------------------- */

/*
 Brent-style cycle detection is folded into the ordinary orbit.
 It adds comparisons/bookkeeping but no extra T() evaluations.
*/
static PathResult analyze_path(uint64_t start) {
    PathResult r;
    memset(&r, 0, sizeof(r));

    u128 s = (u128)start;
    u128 x = s;
    r.peak = s;
    r.last_value = s;

    if (start == 1ULL) {
        r.status = PATH_REACHED_ONE;
        r.total_steps = 0;
        return r;
    }

    u128 tortoise = x;
    uint64_t power = 1;
    uint64_t lam = 0;

    for (uint32_t step = 1; step <= MAX_PATH_STEPS; ++step) {
        x = T(x);

        if (x == 0) {
            r.status = PATH_UNRESOLVED;
            r.total_steps = step;
            r.last_value = x;
            return r;
        }

        r.last_value = x;

        if (x > r.peak) {
            r.peak = x;
            r.steps_to_peak = step;
        }

        if (r.sigma == 0 && x < s) {
            r.sigma = step;
            r.first_lower = x;
        }

        if (x == 1) {
            r.status = PATH_REACHED_ONE;
            r.total_steps = step;
            return r;
        }

        ++lam;
        if (x == tortoise) {
            r.status = PATH_CYCLE;
            r.total_steps = step;
            r.cycle_length_hint = (uint32_t)(lam > UINT32_MAX ? UINT32_MAX : lam);
            return r;
        }

        if (lam == power) {
            tortoise = x;
            if (power <= UINT64_MAX / 2) power <<= 1;
            lam = 0;
        }
    }

    r.status = PATH_UNRESOLVED;
    r.total_steps = MAX_PATH_STEPS;
    return r;
}

/* ------------------------- history ------------------------- */

static void hist_maybe_add(ChunkHistory *h, uint64_t n, uint32_t sigma, u128 first_lower,
                           uint32_t *local_record_sigma) {
    if (sigma <= *local_record_sigma) return;

    *local_record_sigma = sigma;

    if (h->count < MAX_LOCAL_RECORDS) {
        HistEntry *e = &h->rec[h->count++];
        e->n = n;
        e->sigma = sigma;
        e->first_lower = first_lower;
    } else {
        h->overflow = 1;
    }
}

static bool write_chunk_history(uint64_t chunk_id, const ChunkHistory *h) {
    off_t off = (off_t)(chunk_id * (uint64_t)sizeof(ChunkHistory));
    const unsigned char *p = (const unsigned char *)h;
    size_t left = sizeof(*h);

    while (left > 0) {
        ssize_t w = pwrite(g_history_fd, p, left, off);
        if (w < 0) {
            if (errno == EINTR) continue;
            perror("pwrite history");
            return false;
        }
        p += (size_t)w;
        off += w;
        left -= (size_t)w;
    }
    return true;
}

/* ------------------------- logs ------------------------- */

static void log_cycle(uint64_t chunk_id, uint64_t n, const PathResult *p) {
    char last[64], peak[64];
    u128_to_str(p->last_value, last, sizeof(last));
    u128_to_str(p->peak, peak, sizeof(peak));

    pthread_mutex_lock(&g_log_mu);
    fprintf(g_cycles_fp,
            "%" PRIu64 ",%" PRIu64 ",%u,%u,%s,%s\n",
            chunk_id, n, p->total_steps, p->cycle_length_hint, last, peak);
    fflush(g_cycles_fp);
    pthread_mutex_unlock(&g_log_mu);
}

static void log_unresolved(uint64_t chunk_id, uint64_t n, const PathResult *p) {
    char last[64], peak[64];
    u128_to_str(p->last_value, last, sizeof(last));
    u128_to_str(p->peak, peak, sizeof(peak));

    pthread_mutex_lock(&g_log_mu);
    fprintf(g_unresolved_fp,
            "%" PRIu64 ",%" PRIu64 ",%u,%s,%s\n",
            chunk_id, n, p->total_steps, last, peak);
    fflush(g_unresolved_fp);
    pthread_mutex_unlock(&g_log_mu);
}

/* ------------------------- chunk ------------------------- */

static void process_one_start(ChunkResult *cr, uint64_t n, uint32_t *local_record_sigma) {
    PathResult p = analyze_path(n);

    ++cr->starts;

    if (p.sigma > 0) {
        StopEntry se = { n, p.sigma, p.first_lower };
        insert_stop(cr->top_stop, se);
        hist_maybe_add(&cr->history, n, p.sigma, p.first_lower, local_record_sigma);
    }

    PeakEntry pe = { n, p.peak, p.steps_to_peak };
    insert_peak(cr->top_peak, pe);

    if (p.status == PATH_REACHED_ONE) {
        ++cr->reached_one;
        TotalEntry te = { n, p.total_steps };
        insert_total(cr->top_total, te);
    } else if (p.status == PATH_CYCLE) {
        ++cr->cycles;
        log_cycle(cr->chunk_id, n, &p);
    } else {
        ++cr->unresolved;
        log_unresolved(cr->chunk_id, n, &p);
    }
}

static ChunkResult compute_chunk(uint64_t chunk_id) {
    ChunkResult cr;
    memset(&cr, 0, sizeof(cr));
    cr.chunk_id = chunk_id;

    uint64_t kb = chunk_id * GROUPS_PER_CHUNK;
    uint64_t ke = kb + GROUPS_PER_CHUNK;
    if (ke > g_num_groups) ke = g_num_groups;

    cr.k_begin = kb;
    cr.k_end = ke;

    double t0 = now_sec();
    uint32_t local_record_sigma = 0;

    for (uint64_t k = kb; k < ke; ++k) {
        uint64_t n1 = 6ULL * k + 1ULL;
        if (n1 <= LIMIT) {
            process_one_start(&cr, n1, &local_record_sigma);
        }

        uint64_t n5 = 6ULL * k + 5ULL;
        if (n5 <= LIMIT) {
            process_one_start(&cr, n5, &local_record_sigma);
        }
    }

    cr.seconds = now_sec() - t0;
    return cr;
}

/* ------------------------- checkpoint ------------------------- */

static bool save_checkpoint_locked(void) {
    FILE *fp = fopen(CHECKPOINT_TMP, "wb");
    if (!fp) {
        perror("fopen checkpoint tmp");
        return false;
    }

    if (fwrite(&g_state, sizeof(g_state), 1, fp) != 1) {
        perror("fwrite checkpoint header");
        fclose(fp);
        return false;
    }

    if (fwrite(g_done, 1, g_num_chunks, fp) != g_num_chunks) {
        perror("fwrite checkpoint bitmap");
        fclose(fp);
        return false;
    }

    fflush(fp);
    fsync(fileno(fp));
    fclose(fp);

    if (rename(CHECKPOINT_TMP, CHECKPOINT_FILE) != 0) {
        perror("rename checkpoint");
        return false;
    }

    return true;
}

static bool load_checkpoint(void) {
    FILE *fp = fopen(CHECKPOINT_FILE, "rb");
    if (!fp) return false;

    CheckpointHeader h;
    if (fread(&h, sizeof(h), 1, fp) != 1) {
        fclose(fp);
        return false;
    }

    if (strncmp(h.magic, "T7R23SCANv1", 11) != 0 ||
        h.version != 1 ||
        h.limit != LIMIT ||
        h.groups_per_chunk != GROUPS_PER_CHUNK ||
        h.num_chunks != g_num_chunks) {
        fprintf(stderr, "Checkpoint configuration mismatch; refusing to load it.\n");
        fclose(fp);
        exit(EXIT_FAILURE);
    }

    if (fread(g_done, 1, g_num_chunks, fp) != g_num_chunks) {
        fprintf(stderr, "Checkpoint bitmap is incomplete.\n");
        fclose(fp);
        exit(EXIT_FAILURE);
    }

    fclose(fp);
    g_state = h;
    return true;
}

/* ------------------------- merge + progress ------------------------- */

static uint64_t chunk_low_n(const ChunkResult *cr) {
    return 6ULL * cr->k_begin + 1ULL;
}

static uint64_t chunk_high_n(const ChunkResult *cr) {
    if (cr->k_end == 0) return 0;
    uint64_t k = cr->k_end - 1;
    uint64_t a = 6ULL * k + 1ULL;
    uint64_t b = 6ULL * k + 5ULL;
    if (b <= LIMIT) return b;
    return a <= LIMIT ? a : LIMIT;
}

static void print_progress_locked(const ChunkResult *cr) {
    char stop_lower[64] = "-";
    char peakbuf[64] = "-";

    StopEntry s = g_state.top_stop[0];
    PeakEntry p = g_state.top_peak[0];
    TotalEntry t = g_state.top_total[0];

    if (s.n) u128_to_str(s.first_lower, stop_lower, sizeof(stop_lower));
    if (p.n) u128_to_str(p.peak, peakbuf, sizeof(peakbuf));

    double rate = cr->seconds > 0.0 ? (double)cr->starts / cr->seconds : 0.0;
    double pct = g_num_chunks ? 100.0 * (double)g_state.completed_chunks / (double)g_num_chunks : 100.0;

    printf("\n"
           "============================================================\n"
           "chunk:          %" PRIu64 " / %" PRIu64 "   (%.2f%% complete)\n"
           "n-range:        [%" PRIu64 ", %" PRIu64 "]\n"
           "chunk starts:   %" PRIu64 "\n"
           "chunk seconds:  %.3f\n"
           "chunk rate:     %.0f starts/sec\n"
           "total starts:   %" PRIu64 "\n"
           "reached 1:      %" PRIu64 "\n"
           "cycles:         %" PRIu64 "\n"
           "unresolved:     %" PRIu64 "\n",
           cr->chunk_id + 1, g_num_chunks, pct,
           chunk_low_n(cr), chunk_high_n(cr),
           cr->starts, cr->seconds, rate,
           g_state.starts, g_state.reached_one,
           g_state.cycles, g_state.unresolved);

    if (s.n) {
        printf("best stopping:  n=%" PRIu64 " sigma=%u first_lower=%s\n",
               s.n, s.sigma, stop_lower);
    }
    if (t.n) {
        printf("best total:     n=%" PRIu64 " steps=%u\n", t.n, t.steps);
    }
    if (p.n) {
        printf("best peak:      n=%" PRIu64 " peak=%s step=%u\n",
               p.n, peakbuf, p.steps_to_peak);
    }

    printf("============================================================\n");
    fflush(stdout);
}

static void append_progress_csv_locked(const ChunkResult *cr) {
    StopEntry s = g_state.top_stop[0];
    TotalEntry t = g_state.top_total[0];
    PeakEntry p = g_state.top_peak[0];

    char lower[64] = "";
    char peak[64] = "";
    if (s.n) u128_to_str(s.first_lower, lower, sizeof(lower));
    if (p.n) u128_to_str(p.peak, peak, sizeof(peak));

    fprintf(g_progress_fp,
            "%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%.6f,"
            "%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ","
            "%" PRIu64 ",%u,%s,"
            "%" PRIu64 ",%u,"
            "%" PRIu64 ",%s,%u\n",
            cr->chunk_id,
            chunk_low_n(cr), chunk_high_n(cr), cr->starts, cr->seconds,
            g_state.starts, g_state.reached_one, g_state.cycles, g_state.unresolved,
            s.n, s.sigma, lower,
            t.n, t.steps,
            p.n, peak, p.steps_to_peak);
    fflush(g_progress_fp);
}

static void merge_chunk(ChunkResult *cr) {
    pthread_mutex_lock(&g_merge_mu);

    if (g_done[cr->chunk_id]) {
        pthread_mutex_unlock(&g_merge_mu);
        return;
    }

    for (int i = 0; i < TOPK; ++i) {
        insert_stop(g_state.top_stop, cr->top_stop[i]);
        insert_total(g_state.top_total, cr->top_total[i]);
        insert_peak(g_state.top_peak, cr->top_peak[i]);
    }

    g_state.starts += cr->starts;
    g_state.reached_one += cr->reached_one;
    g_state.cycles += cr->cycles;
    g_state.unresolved += cr->unresolved;

    g_done[cr->chunk_id] = 1;
    ++g_state.completed_chunks;

    append_progress_csv_locked(cr);

    if (PRINT_EVERY_CHUNKS > 0 &&
        (g_state.completed_chunks % PRINT_EVERY_CHUNKS == 0 ||
         g_state.completed_chunks == g_num_chunks)) {
        print_progress_locked(cr);
    }

    if (CHECKPOINT_EVERY_CHUNKS > 0 &&
        (g_state.completed_chunks % CHECKPOINT_EVERY_CHUNKS == 0 ||
         g_state.completed_chunks == g_num_chunks)) {
        save_checkpoint_locked();
    }

    pthread_mutex_unlock(&g_merge_mu);
}

/* ------------------------- worker ------------------------- */

static void *worker_main(void *arg) {
    (void)arg;

    while (!atomic_load_explicit(&g_stop_requested, memory_order_relaxed)) {
        uint64_t cid = atomic_fetch_add_explicit(&g_next_chunk, 1, memory_order_relaxed);
        if (cid >= g_num_chunks) break;

        if (g_done[cid]) continue;

        ChunkResult cr = compute_chunk(cid);

        if (!write_chunk_history(cid, &cr.history)) {
            fprintf(stderr, "Failed to save chunk history for chunk %" PRIu64 "\n", cid);
            atomic_store(&g_stop_requested, true);
            break;
        }

        merge_chunk(&cr);
    }

    return NULL;
}

/* ------------------------- final reports ------------------------- */

static void write_top_csvs(void) {
    FILE *fp;

    fp = fopen(TOP_STOP_CSV, "w");
    if (!fp) { perror("top stop csv"); exit(EXIT_FAILURE); }
    fprintf(fp, "rank,n,sigma,first_lower\n");
    for (int i = 0; i < TOPK; ++i) {
        if (!g_state.top_stop[i].n) continue;
        char x[64];
        u128_to_str(g_state.top_stop[i].first_lower, x, sizeof(x));
        fprintf(fp, "%d,%" PRIu64 ",%u,%s\n",
                i + 1, g_state.top_stop[i].n, g_state.top_stop[i].sigma, x);
    }
    fclose(fp);

    fp = fopen(TOP_TOTAL_CSV, "w");
    if (!fp) { perror("top total csv"); exit(EXIT_FAILURE); }
    fprintf(fp, "rank,n,total_steps_to_1\n");
    for (int i = 0; i < TOPK; ++i) {
        if (!g_state.top_total[i].n) continue;
        fprintf(fp, "%d,%" PRIu64 ",%u\n",
                i + 1, g_state.top_total[i].n, g_state.top_total[i].steps);
    }
    fclose(fp);

    fp = fopen(TOP_PEAK_CSV, "w");
    if (!fp) { perror("top peak csv"); exit(EXIT_FAILURE); }
    fprintf(fp, "rank,n,peak,step_of_peak\n");
    for (int i = 0; i < TOPK; ++i) {
        if (!g_state.top_peak[i].n) continue;
        char x[64];
        u128_to_str(g_state.top_peak[i].peak, x, sizeof(x));
        fprintf(fp, "%d,%" PRIu64 ",%s,%u\n",
                i + 1, g_state.top_peak[i].n, x, g_state.top_peak[i].steps_to_peak);
    }
    fclose(fp);
}

/*
 Reconstruct the true historical stopping-time records in increasing n order.
 Each chunk stored its own local record staircase while scanning in increasing n.
*/
static void write_historical_csv(void) {
    FILE *fp = fopen(HIST_CSV, "w");
    if (!fp) { perror("historical csv"); exit(EXIT_FAILURE); }

    fprintf(fp, "record_index,n,new_sigma,first_lower,chunk_id\n");

    uint32_t global_record = 0;
    uint64_t record_index = 0;
    bool overflow_seen = false;

    for (uint64_t cid = 0; cid < g_num_chunks; ++cid) {
        if (!g_done[cid]) continue;

        ChunkHistory h;
        off_t off = (off_t)(cid * (uint64_t)sizeof(ChunkHistory));
        unsigned char *p = (unsigned char *)&h;
        size_t left = sizeof(h);

        while (left > 0) {
            ssize_t r = pread(g_history_fd, p, left, off);
            if (r < 0) {
                if (errno == EINTR) continue;
                perror("pread history");
                fclose(fp);
                exit(EXIT_FAILURE);
            }
            if (r == 0) {
                fprintf(stderr, "Unexpected EOF in history file.\n");
                fclose(fp);
                exit(EXIT_FAILURE);
            }
            p += (size_t)r;
            off += r;
            left -= (size_t)r;
        }

        if (h.overflow) overflow_seen = true;

        for (uint32_t j = 0; j < h.count; ++j) {
            HistEntry e = h.rec[j];
            if (e.sigma > global_record) {
                global_record = e.sigma;
                ++record_index;

                char lower[64];
                u128_to_str(e.first_lower, lower, sizeof(lower));
                fprintf(fp, "%" PRIu64 ",%" PRIu64 ",%u,%s,%" PRIu64 "\n",
                        record_index, e.n, e.sigma, lower, cid);
            }
        }
    }

    fclose(fp);

    if (overflow_seen) {
        fprintf(stderr,
                "WARNING: at least one chunk exceeded MAX_LOCAL_RECORDS=%d.\n"
                "Historical record CSV may be incomplete. Reduce GROUPS_PER_CHUNK or increase MAX_LOCAL_RECORDS.\n",
                MAX_LOCAL_RECORDS);
    }
}

static void write_final_summary(void) {
    FILE *fp = fopen(FINAL_SUMMARY, "w");
    if (!fp) { perror("final summary"); exit(EXIT_FAILURE); }

    fprintf(fp,
            "7n±1 / 6 reduced by all factors 2 and 3\n"
            "============================================================\n"
            "LIMIT:                 %" PRIu64 "\n"
            "GROUPS_PER_CHUNK:      %" PRIu64 "\n"
            "NUM_CHUNKS:            %" PRIu64 "\n"
            "COMPLETED_CHUNKS:      %" PRIu64 "\n"
            "VALID STARTS TESTED:   %" PRIu64 "\n"
            "REACHED 1:             %" PRIu64 "\n"
            "CYCLES FOUND:          %" PRIu64 "\n"
            "UNRESOLVED:            %" PRIu64 "\n"
            "MAX_PATH_STEPS CAP:    %u\n\n",
            LIMIT, GROUPS_PER_CHUNK, g_num_chunks, g_state.completed_chunks,
            g_state.starts, g_state.reached_one, g_state.cycles, g_state.unresolved,
            MAX_PATH_STEPS);

    fprintf(fp, "TOP %d STOPPING TIMES\n", TOPK);
    fprintf(fp, "rank,n,sigma,first_lower\n");
    for (int i = 0; i < TOPK; ++i) {
        if (!g_state.top_stop[i].n) continue;
        char x[64];
        u128_to_str(g_state.top_stop[i].first_lower, x, sizeof(x));
        fprintf(fp, "%d,%" PRIu64 ",%u,%s\n",
                i + 1, g_state.top_stop[i].n, g_state.top_stop[i].sigma, x);
    }

    fprintf(fp, "\nTOP %d TOTAL STEPS TO 1\n", TOPK);
    fprintf(fp, "rank,n,total_steps\n");
    for (int i = 0; i < TOPK; ++i) {
        if (!g_state.top_total[i].n) continue;
        fprintf(fp, "%d,%" PRIu64 ",%u\n",
                i + 1, g_state.top_total[i].n, g_state.top_total[i].steps);
    }

    fprintf(fp, "\nTOP %d PEAKS\n", TOPK);
    fprintf(fp, "rank,n,peak,step_of_peak\n");
    for (int i = 0; i < TOPK; ++i) {
        if (!g_state.top_peak[i].n) continue;
        char x[64];
        u128_to_str(g_state.top_peak[i].peak, x, sizeof(x));
        fprintf(fp, "%d,%" PRIu64 ",%s,%u\n",
                i + 1, g_state.top_peak[i].n, x, g_state.top_peak[i].steps_to_peak);
    }

    fprintf(fp,
            "\nIMPORTANT INTERPRETATION\n"
            "This is a finite computation up to LIMIT. It is not a proof for all integers.\n"
            "If UNRESOLVED=0 and CYCLES FOUND=0, every tested valid start reached 1 within the safety cap.\n");

    fclose(fp);
}

/* ------------------------- setup ------------------------- */

static void signal_handler(int sig) {
    (void)sig;
    atomic_store_explicit(&g_stop_requested, true, memory_order_relaxed);
}

static uint64_t count_groups(uint64_t limit) {
    if (limit < 1) return 0;
    return (limit - 1ULL) / 6ULL + 1ULL;
}

static uint64_t count_valid_starts(uint64_t limit) {
    uint64_t a = limit >= 1 ? (limit - 1ULL) / 6ULL + 1ULL : 0;
    uint64_t b = limit >= 5 ? (limit - 5ULL) / 6ULL + 1ULL : 0;
    return a + b;
}

static void open_logs(void) {
    bool new_progress = access(PROGRESS_CSV, F_OK) != 0;
    bool new_cycles = access(CYCLES_CSV, F_OK) != 0;
    bool new_unresolved = access(UNRESOLVED_CSV, F_OK) != 0;

    g_progress_fp = fopen(PROGRESS_CSV, "a");
    g_cycles_fp = fopen(CYCLES_CSV, "a");
    g_unresolved_fp = fopen(UNRESOLVED_CSV, "a");

    if (!g_progress_fp || !g_cycles_fp || !g_unresolved_fp) {
        perror("open log files");
        exit(EXIT_FAILURE);
    }

    if (new_progress) {
        fprintf(g_progress_fp,
                "chunk_id,n_low,n_high,chunk_starts,chunk_seconds,"
                "cumulative_starts,reached_one,cycles,unresolved,"
                "best_stop_n,best_sigma,best_first_lower,"
                "best_total_n,best_total_steps,"
                "best_peak_n,best_peak,best_peak_step\n");
        fflush(g_progress_fp);
    }

    if (new_cycles) {
        fprintf(g_cycles_fp, "chunk_id,n,steps_when_detected,cycle_length_hint,last_value,peak\n");
        fflush(g_cycles_fp);
    }

    if (new_unresolved) {
        fprintf(g_unresolved_fp, "chunk_id,n,steps,last_value,peak\n");
        fflush(g_unresolved_fp);
    }
}

static void open_history_file(void) {
    g_history_fd = open(HISTORY_BIN, O_CREAT | O_RDWR, 0644);
    if (g_history_fd < 0) {
        perror("open history bin");
        exit(EXIT_FAILURE);
    }

    off_t need = (off_t)(g_num_chunks * (uint64_t)sizeof(ChunkHistory));
    if (ftruncate(g_history_fd, need) != 0) {
        perror("ftruncate history bin");
        exit(EXIT_FAILURE);
    }
}

static unsigned detect_threads(void) {
    /* Portable fallback: user can override with ./scan7 N */
    return 4u;
}

/* ------------------------- main ------------------------- */

int main(int argc, char **argv) {
    unsigned threads = detect_threads();

    if (argc >= 2) {
        long t = strtol(argv[1], NULL, 10);
        if (t < 1 || t > 256) {
            fprintf(stderr, "Usage: %s [threads 1..256]\n", argv[0]);
            return EXIT_FAILURE;
        }
        threads = (unsigned)t;
    }

    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    g_num_groups = count_groups(LIMIT);
    g_num_chunks = (g_num_groups + GROUPS_PER_CHUNK - 1ULL) / GROUPS_PER_CHUNK;

    if (g_num_chunks == 0) {
        fprintf(stderr, "Nothing to do.\n");
        return EXIT_FAILURE;
    }

    g_done = calloc((size_t)g_num_chunks, 1);
    if (!g_done) {
        perror("calloc done bitmap");
        return EXIT_FAILURE;
    }

    memset(&g_state, 0, sizeof(g_state));
    snprintf(g_state.magic, sizeof(g_state.magic), "T7R23SCANv1");
    g_state.version = 1;
    g_state.limit = LIMIT;
    g_state.groups_per_chunk = GROUPS_PER_CHUNK;
    g_state.num_chunks = g_num_chunks;

    bool resumed = load_checkpoint();

    open_logs();
    open_history_file();

    atomic_init(&g_next_chunk, 0);
    atomic_init(&g_stop_requested, false);

    uint64_t expected = count_valid_starts(LIMIT);

    printf("============================================================\n");
    printf("7n±1 / 6 with complete removal of factors 2 and 3\n");
    printf("LIMIT:             %" PRIu64 "\n", LIMIT);
    printf("Expected starts:   %" PRIu64 "\n", expected);
    printf("Chunks:            %" PRIu64 "\n", g_num_chunks);
    printf("Threads:           %u\n", threads);
    printf("128-bit arithmetic: enabled (__uint128_t)\n");
    printf("Checkpoint:        %s\n", resumed ? "resumed" : "new run");
    printf("Completed chunks:  %" PRIu64 "\n", g_state.completed_chunks);
    printf("Press Ctrl-C once for a clean stop + checkpoint.\n");
    printf("============================================================\n");
    fflush(stdout);

    pthread_t *th = calloc(threads, sizeof(*th));
    if (!th) {
        perror("calloc threads");
        return EXIT_FAILURE;
    }

    for (unsigned i = 0; i < threads; ++i) {
        if (pthread_create(&th[i], NULL, worker_main, NULL) != 0) {
            perror("pthread_create");
            atomic_store(&g_stop_requested, true);
            threads = i;
            break;
        }
    }

    for (unsigned i = 0; i < threads; ++i) {
        pthread_join(th[i], NULL);
    }

    pthread_mutex_lock(&g_merge_mu);
    save_checkpoint_locked();
    pthread_mutex_unlock(&g_merge_mu);

    bool complete = (g_state.completed_chunks == g_num_chunks);

    if (complete) {
        write_top_csvs();
        write_historical_csv();
        write_final_summary();

        printf("\nSCAN COMPLETE.\n");
        printf("Final files:\n");
        printf("  %s\n  %s\n  %s\n  %s\n  %s\n",
               FINAL_SUMMARY, TOP_STOP_CSV, TOP_TOTAL_CSV, TOP_PEAK_CSV, HIST_CSV);

        if (g_state.starts != expected) {
            fprintf(stderr,
                    "WARNING: expected %" PRIu64 " starts, but processed %" PRIu64 ".\n",
                    expected, g_state.starts);
        }
    } else {
        printf("\nStopped cleanly after %" PRIu64 " / %" PRIu64 " chunks.\n",
               g_state.completed_chunks, g_num_chunks);
        printf("Checkpoint saved. Run the same command again to continue.\n");
    }

    if (g_progress_fp) fclose(g_progress_fp);
    if (g_cycles_fp) fclose(g_cycles_fp);
    if (g_unresolved_fp) fclose(g_unresolved_fp);
    if (g_history_fd >= 0) close(g_history_fd);

    free(th);
    free(g_done);

    return complete ? EXIT_SUCCESS : 2;
}
