Ternary (7k +/- 1)/6 Collatz-Type Map with a Single Observed Attractor
Complete (2,3)-Adic Reduction, Algebraic Cycle Analysis, and Exhaustive Computational Verification up to 10^11

Author: Farhad Banazadeh
ORCID: 0009-0004-7023-0298
Date: 12 September 2026

This archive contains the corrected LaTeX source and the complete computational materials supplied from the finished T7_scan_1e11 run. The article PDF is distributed separately and is intentionally not duplicated inside this archive.

Textual correction in Section 8 (Computational methodology):
- the scan contains 3334 chunks;
- the final chunk covered [99,990,000,001, 99,999,999,997];
- it contained 3,333,333 admissible starts.
The previously printed range [99,960,000,001, 99,989,999,999] corresponds to chunk 3332. This correction does not affect the reported total of 33,333,333,333 admissible starts or any computational result.

Core finite result:
- admissible starts tested: 33,333,333,333
- reached 1: 33,333,333,333
- cycles found: 0
- unresolved: 0
- safety cap: 1,000,000 reduced iterations

The finite computation is not a proof of global convergence.
Repository: https://github.com/FarhadBanazadeh/sequence-computations
