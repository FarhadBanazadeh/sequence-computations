Ternary minus-map V3 Computational Pack
========================================

Associated manuscript:
  A Ternary (4k - 1(2))/3 Collatz-Type Map
  Exact 3-Adic Symbolic Dynamics, a Density-One First-Descent Theorem,
  Algebraic Cycle Analysis, and Exhaustive Computational Verification up to 10^11
  Farhad Banazadeh, 2026

Map
---
For positive x not divisible by 3:
  r = x mod 3 in {1,2}
  T(x) = (4x-r) / 3^v3(4x-r)

Purpose
-------
This archive contains the computational evidence and reproducibility material
used by the V3 manuscript.  It intentionally does NOT duplicate the article PDF
or LaTeX source; those should be uploaded as separate files in the same Zenodo
record.

Directory guide
---------------
source/
  scan_ternary_minus_1e11_v2.c
      Historical V2 scanner used for the archived terminal-cycle classification.
  scan_ternary_minus_1e11_v5_1.c
      Historical first-descent scanner used for the archived first-lower data.
  scan_ternary_minus_1e11_v5_2.c
      Audit-hardened scanner.  It preserves the map but strengthens checkpoint
      identity, parsing, required-field and consistency validation.

data/classification_1e9/
  10 archived V2 checkpoints covering 1 <= n <= 10^9.

data/classification_1e9_to_1e11/
  990 archived V2 checkpoints covering 10^9 < n <= 10^11.

data/first_descent_1e9/
  10 archived V5.1 first-descent checkpoints covering 1 <= n <= 10^9.

data/first_descent_1e9_to_1e11/
  990 archived V5.1 first-descent checkpoints covering 10^9 < n <= 10^11.

validation/
  Fresh V5.1/V5.2 validation outputs, including a V5.2 production-scale rerun
  of 76,000,000,001 <= n <= 76,100,000,000 containing the global 355-step
  first-descent record.

exact_dp/
  An independent exact-rational Python implementation of the finite-horizon
  valuation-barrier dynamic program and its certified output through depth 500.

record_trace/
  The historical 355-step trace plus the corrected final residue certification.

audits/
  Computational audit D.1, numerical cross-check, and exact-rational DP audit.

AGGREGATE_RESULTS.txt
  Independently regenerated aggregate totals from the 2000 archived checkpoint
  files in this pack.

SHA256SUMS.txt
  SHA-256 hashes for every file in the pack except SHA256SUMS.txt itself.

Important scope statement
-------------------------
The complete 1 <= n <= 10^11 domain was NOT freshly recomputed from zero with
V5.2 during the final audit.  The complete-domain claims come from the archived
exhaustive checkpoint collection, independently re-aggregated and structurally
audited.  V5.2 was freshly rerun on validation ranges and a 100-million-integer
production interval containing the hardest first-descent record.

Corrected final transition of the 355-step record
-------------------------------------------------
  x = 491,591,720,993
  x mod 3 = 2, so r = 2
  4x-r = 1,966,366,883,970
  v3(4x-r) = 5
  T(x) = 8,092,044,790

The numerical next state, valuation, first-descent time, and all aggregate
results are unchanged by this correction; the earlier error was only a residue
annotation transcription.

Portability
-----------
Precompiled binaries are deliberately omitted.  Compile the C sources locally.
For GCC/Clang, a typical command is:
  cc -O3 -pthread -std=c11 source/scan_ternary_minus_1e11_v5_2.c -o scanner

Exact-DP reproduction:
  python3 exact_dp/exact_rational_dp.py

The exact command-line interface for each historical scanner is documented by
its source usage text.  Thread count may affect run time but not deterministic
checkpoint results.

Zenodo packaging
----------------
Recommended Zenodo record files:
  1. manuscript PDF
  2. manuscript .tex source
  3. this computational ZIP

The manuscript .tex is intentionally not duplicated inside this ZIP.
