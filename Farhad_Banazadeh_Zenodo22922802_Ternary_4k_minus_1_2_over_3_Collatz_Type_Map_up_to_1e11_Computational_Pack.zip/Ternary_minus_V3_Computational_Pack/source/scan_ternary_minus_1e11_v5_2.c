/*
 * scan_ternary_minus_1e11_v5_2.c
 *
 * Chunked/checkpoint scanner for the accelerated ternary map
 *
 *   T(x) = (4*x-r) / 3^v3(4*x-r), r=x mod 3 in {1,2}
 *
 * Known positive attractors:
 *   {1}, {2}, 22 -> 29 -> 38 -> 50 -> 22
 *
 * Exact orbit arithmetic supports unsigned __int128.
 * Performance V2 uses a 64-bit fast path whenever the current transition
 * is provably safe in uint64_t, and automatically promotes to 128-bit.
 *
 * Usage:
 *   ./scan_ternary_minus_1e11 START END CHUNK THREADS RESULTS_DIR
 *
 * Example validation:
 *   ./scan_ternary_minus_1e11 1 1000000 100000 4 test_chunks
 *
 * Example new-domain scan:
 *   ./scan_ternary_minus_1e11 1000000001 100000000000 100000000 4 results_1e11_chunks
 *
 * A chunk is considered complete only after its .done file is atomically renamed
 * into place. Re-running the same command skips completed chunks and reconstructs
 * session totals from their saved records.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>

typedef unsigned __int128 u128;

#define WORK_BLOCK 65536ULL
#define LINEBUF 1024
#define NO_LOWER_LOG_CAP 256

typedef struct {
    uint64_t tested, to1, to2, to4, unknown, overflow;
    uint64_t lower_found, no_lower;
    uint64_t known_no_lower, unresolved_no_lower;
    uint64_t no_lower_logged;
    uint64_t no_lower_starts[NO_LOWER_LOG_CAP];
    u128 total_steps, total_v3;
    u128 total_first_lower_steps;
    uint64_t max_first_lower_steps, max_first_lower_start;
    uint64_t max_steps, max_steps_start;
    uint64_t max_v3, max_v3_start;
    u128 max_peak;
    uint64_t max_peak_start;
    uint64_t unknown_start;
    u128 unknown_state;
} Stats;

typedef struct {
    uint64_t lo, hi;
    _Atomic uint64_t next_raw;
    Stats *locals;
} ChunkCtx;

static inline u128 u128_max(void) { return ~(u128)0; }

static void u128_to_str(u128 x, char *buf, size_t n) {
    char tmp[64];
    size_t i = 0, j = 0;
    if (n == 0) return;
    if (x == 0) { if (n > 1) { buf[0]='0'; buf[1]='\0'; } return; }
    while (x && i < sizeof(tmp)) { tmp[i++] = (char)('0' + (unsigned)(x % 10)); x /= 10; }
    while (i && j + 1 < n) buf[j++] = tmp[--i];
    buf[j] = '\0';
}

static int str_to_u128(const char *s, u128 *out) {
    u128 x = 0, mx = u128_max();
    if (!s || !*s) return 0;
    for (; *s; ++s) {
        if (*s < '0' || *s > '9') return 0;
        unsigned d = (unsigned)(*s - '0');
        if (x > (mx - d) / 10) return 0;
        x = x * 10 + d;
    }
    *out = x;
    return 1;
}

static inline int attractor_id(u128 x) {
    if (x == 1) return 1;
    if (x == 2) return 2;
    if (x == 22 || x == 29 || x == 38 || x == 50) return 4;
    return 0;
}

static inline int map_step(u128 x, u128 *next, uint32_t *v) {
    /*
     * Fast path: almost all states in the measured domain fit in uint64_t.
     * Keep division/modulo in native 64-bit arithmetic whenever 4*x-r is
     * also guaranteed to fit. Otherwise promote exactly to unsigned __int128.
     */
    if (x <= (u128)UINT64_MAX) {
        uint64_t a = (uint64_t)x;
        unsigned r = (unsigned)(a % 3ULL);
        if (r == 0) return 0;

        if (a <= UINT64_MAX/4ULL + 1ULL) {
            uint64_t y = 4ULL*a - (uint64_t)r;
            uint32_t k = 0;
            do { y /= 3ULL; ++k; } while (y % 3ULL == 0);
            *next = (u128)y;
            *v = k;
            return 1;
        }
    }

    unsigned r = (unsigned)(x % (u128)3);
    if (r == 0) return 0;

    /* 4*x-r <= UMAX.  For UMAX=4q+3 and r in {1,2}, x=q+1 is safe. */
    if (x > u128_max()/4 + 1) return 0;

    u128 y = 4*x - (u128)r;
    uint32_t k = 0;
    do { y /= (u128)3; ++k; } while (y % (u128)3 == 0);
    *next = y;
    *v = k;
    return 1;
}

static inline void log_no_lower(Stats *s, uint64_t start) {
    ++s->no_lower;
    if (s->no_lower_logged < NO_LOWER_LOG_CAP)
        s->no_lower_starts[s->no_lower_logged++] = start;
}

static inline void record_known_no_lower(Stats *s, uint64_t start) {
    ++s->known_no_lower;
    log_no_lower(s,start);
}

static inline void record_unresolved_no_lower(Stats *s, uint64_t start) {
    ++s->unresolved_no_lower;
    log_no_lower(s,start);
}

static inline void finish_known(Stats *s, uint64_t start, int a,
                                uint64_t steps, uint64_t vsum, u128 peak) {
    ++s->tested;
    if (a == 1) ++s->to1;
    else if (a == 2) ++s->to2;
    else ++s->to4;
    s->total_steps += (u128)steps;
    s->total_v3 += (u128)vsum;
    if (steps > s->max_steps) { s->max_steps=steps; s->max_steps_start=start; }
    if (vsum > s->max_v3) { s->max_v3=vsum; s->max_v3_start=start; }
    if (peak > s->max_peak) { s->max_peak=peak; s->max_peak_start=start; }
}

static inline void scan_one(uint64_t start, Stats *s) {
    u128 x = (u128)start, peak = (u128)start;
    u128 tortoise = x;
    uint64_t power = 1, lam = 0, steps = 0, vsum = 0;
    uint64_t first_lower_steps = 0;

    for (;;) {
        int a = attractor_id(x);
        if (a) {
            /*
             * For the large production domain, every successful descent must
             * occur before entry into a tiny known attractor.  For validation
             * ranges, starts already inside {1,2,22,29,38,50} can legitimately
             * have no strict first-lower event.
             */
            if (first_lower_steps) {
                ++s->lower_found;
                s->total_first_lower_steps += (u128)first_lower_steps;
                if (first_lower_steps > s->max_first_lower_steps) {
                    s->max_first_lower_steps = first_lower_steps;
                    s->max_first_lower_start = start;
                }
            } else {
                record_known_no_lower(s,start);
            }
            finish_known(s,start,a,steps,vsum,peak);
            return;
        }

        u128 y; uint32_t v;
        if (!map_step(x,&y,&v)) {
            ++s->tested; ++s->overflow;
            if (first_lower_steps) {
                ++s->lower_found;
                s->total_first_lower_steps += (u128)first_lower_steps;
                if (first_lower_steps > s->max_first_lower_steps) {
                    s->max_first_lower_steps = first_lower_steps;
                    s->max_first_lower_start = start;
                }
            } else record_unresolved_no_lower(s,start);
            return;
        }

        ++steps; vsum += v;
        if (y > peak) peak = y;

        if (!first_lower_steps && y < (u128)start)
            first_lower_steps = steps;

        x = y;
        ++lam;

        if (x == tortoise) {
            ++s->tested; ++s->unknown;
            s->total_steps += (u128)steps; s->total_v3 += (u128)vsum;
            if (first_lower_steps) {
                ++s->lower_found;
                s->total_first_lower_steps += (u128)first_lower_steps;
                if (first_lower_steps > s->max_first_lower_steps) {
                    s->max_first_lower_steps = first_lower_steps;
                    s->max_first_lower_start = start;
                }
            } else record_unresolved_no_lower(s,start);
            if (steps > s->max_steps) { s->max_steps=steps; s->max_steps_start=start; }
            if (vsum > s->max_v3) { s->max_v3=vsum; s->max_v3_start=start; }
            if (peak > s->max_peak) { s->max_peak=peak; s->max_peak_start=start; }
            if (!s->unknown_start) { s->unknown_start=start; s->unknown_state=x; }
            return;
        }
        if (lam == power) {
            tortoise = x;
            if (power <= UINT64_MAX/2) power <<= 1;
            lam = 0;
        }
    }
}

typedef struct { ChunkCtx *ctx; Stats *s; } WorkerArg;

static void *worker(void *p) {
    WorkerArg *a = (WorkerArg*)p;
    ChunkCtx *c = a->ctx; Stats *s = a->s;
    memset(s,0,sizeof(*s));

    for (;;) {
        uint64_t lo = atomic_fetch_add_explicit(&c->next_raw, WORK_BLOCK, memory_order_relaxed);
        if (lo > c->hi) break;
        uint64_t hi = (c->hi - lo + 1 < WORK_BLOCK) ? c->hi : lo + WORK_BLOCK - 1;
        for (uint64_t n=lo; n<=hi; ++n) {
            if (n % 3) scan_one(n,s);
            if (n == UINT64_MAX) break;
        }
    }
    return NULL;
}

static void merge(Stats *d, const Stats *s) {
    d->tested += s->tested; d->to1 += s->to1; d->to2 += s->to2; d->to4 += s->to4;
    d->unknown += s->unknown; d->overflow += s->overflow;
    d->lower_found += s->lower_found; d->no_lower += s->no_lower;
    d->known_no_lower += s->known_no_lower; d->unresolved_no_lower += s->unresolved_no_lower;
    for (uint64_t i=0; i<s->no_lower_logged && d->no_lower_logged<NO_LOWER_LOG_CAP; ++i)
        d->no_lower_starts[d->no_lower_logged++] = s->no_lower_starts[i];
    d->total_steps += s->total_steps; d->total_v3 += s->total_v3;
    d->total_first_lower_steps += s->total_first_lower_steps;
    if (s->max_first_lower_steps > d->max_first_lower_steps) {
        d->max_first_lower_steps=s->max_first_lower_steps;
        d->max_first_lower_start=s->max_first_lower_start;
    }
    if (s->max_steps > d->max_steps) { d->max_steps=s->max_steps; d->max_steps_start=s->max_steps_start; }
    if (s->max_v3 > d->max_v3) { d->max_v3=s->max_v3; d->max_v3_start=s->max_v3_start; }
    if (s->max_peak > d->max_peak) { d->max_peak=s->max_peak; d->max_peak_start=s->max_peak_start; }
    if (!d->unknown_start && s->unknown_start) { d->unknown_start=s->unknown_start; d->unknown_state=s->unknown_state; }
}

static int mkdir_if_needed(const char *p) {
    if (mkdir(p,0755)==0 || errno==EEXIST) return 1;
    perror("mkdir"); return 0;
}

static int save_done(const char *dir, uint64_t idx, uint64_t lo, uint64_t hi,
                     double sec, const Stats *s) {
    char path[512], tmp[520], a[64], b[64], c[64];
    snprintf(path,sizeof(path),"%s/chunk_%06" PRIu64 ".done",dir,idx);
    snprintf(tmp,sizeof(tmp),"%s.tmp",path);
    FILE *f=fopen(tmp,"w"); if(!f) return 0;
    u128_to_str(s->total_steps,a,sizeof(a)); u128_to_str(s->total_v3,b,sizeof(b));
    u128_to_str(s->max_peak,c,sizeof(c));
    fprintf(f,"format_version=2\nindex=%" PRIu64 "\nlo=%" PRIu64 "\nhi=%" PRIu64 "\nseconds=%.9f\n",idx,lo,hi,sec);
    fprintf(f,"tested=%" PRIu64 "\nto1=%" PRIu64 "\nto2=%" PRIu64 "\nto4=%" PRIu64 "\nunknown=%" PRIu64 "\noverflow=%" PRIu64 "\n",
            s->tested,s->to1,s->to2,s->to4,s->unknown,s->overflow);
    fprintf(f,"total_steps=%s\ntotal_v3=%s\n",a,b);
    u128_to_str(s->total_first_lower_steps,a,sizeof(a));
    fprintf(f,"lower_found=%" PRIu64 "\nno_lower=%" PRIu64 "\nknown_no_lower=%" PRIu64 "\nunresolved_no_lower=%" PRIu64 "\ntotal_first_lower_steps=%s\n",
            s->lower_found,s->no_lower,s->known_no_lower,s->unresolved_no_lower,a);
    fprintf(f,"max_first_lower_steps=%" PRIu64 "\nmax_first_lower_start=%" PRIu64 "\n",
            s->max_first_lower_steps,s->max_first_lower_start);
    fprintf(f,"no_lower_logged=%" PRIu64 "\n",s->no_lower_logged);
    fprintf(f,"no_lower_starts=");
    for (uint64_t i=0;i<s->no_lower_logged;++i)
        fprintf(f,"%s%" PRIu64,(i?",":""),s->no_lower_starts[i]);
    fprintf(f,"\n");
    fprintf(f,"max_steps=%" PRIu64 "\nmax_steps_start=%" PRIu64 "\n",s->max_steps,s->max_steps_start);
    fprintf(f,"max_v3=%" PRIu64 "\nmax_v3_start=%" PRIu64 "\n",s->max_v3,s->max_v3_start);
    fprintf(f,"max_peak=%s\nmax_peak_start=%" PRIu64 "\n",c,s->max_peak_start);
    fprintf(f,"unknown_start=%" PRIu64 "\n",s->unknown_start);
    u128_to_str(s->unknown_state,c,sizeof(c)); fprintf(f,"unknown_state=%s\n",c);
    if (fclose(f)!=0) return 0;
    if (rename(tmp,path)!=0) { perror("rename"); return 0; }
    return 1;
}

static int parse_u64_strict(const char *s, uint64_t *out) {
    if (!s || !*s || *s=='-' || *s=='+') return 0;
    errno=0; char *end=NULL;
    unsigned long long v=strtoull(s,&end,10);
    if (errno==ERANGE || !end || *end!='\0') return 0;
    *out=(uint64_t)v; return 1;
}

static int parse_double_strict(const char *s, double *out) {
    if (!s || !*s) return 0;
    errno=0; char *end=NULL;
    double v=strtod(s,&end);
    if (errno==ERANGE || !end || *end!='\0' || v<0.0) return 0;
    *out=v; return 1;
}

static int load_done(const char *dir, uint64_t expected_idx,
                     uint64_t expected_lo, uint64_t expected_hi,
                     Stats *s, double *sec) {
    enum {
        F_VER=1ULL<<0, F_IDX=1ULL<<1, F_LO=1ULL<<2, F_HI=1ULL<<3, F_SEC=1ULL<<4,
        F_TESTED=1ULL<<5, F_TO1=1ULL<<6, F_TO2=1ULL<<7, F_TO4=1ULL<<8,
        F_UNKNOWN=1ULL<<9, F_OVERFLOW=1ULL<<10, F_TSTEPS=1ULL<<11, F_TV3=1ULL<<12,
        F_LOWER=1ULL<<13, F_NOLOWER=1ULL<<14, F_KNOWNNL=1ULL<<15, F_UNRESNL=1ULL<<16,
        F_TFL=1ULL<<17, F_MFL=1ULL<<18, F_MFLS=1ULL<<19, F_NLL=1ULL<<20,
        F_NLS=1ULL<<21, F_MS=1ULL<<22, F_MSS=1ULL<<23, F_MV=1ULL<<24,
        F_MVS=1ULL<<25, F_MP=1ULL<<26, F_MPS=1ULL<<27, F_US=1ULL<<28, F_USTATE=1ULL<<29
    };
    const uint64_t REQUIRED=(1ULL<<30)-1;
    char path[512], line[LINEBUF];
    snprintf(path,sizeof(path),"%s/chunk_%06" PRIu64 ".done",dir,expected_idx);
    FILE *f=fopen(path,"r"); if(!f) return 0;
    Stats tmp; memset(&tmp,0,sizeof(tmp)); double tmpsec=0.0;
    uint64_t mask=0, ver=0, idx=0, lo=0, hi=0, declared_logged=0;
    int ok=1;
    while(ok && fgets(line,sizeof(line),f)) {
        if (!strchr(line,'\n') && !feof(f)) { ok=0; break; }
        char *eq=strchr(line,'='); if(!eq) { ok=0; break; }
        *eq++='\0'; eq[strcspn(eq,"\r\n")]='\0';
#define U64_FIELD(name,bit,dst) if(!strcmp(line,name)) { if((mask&(bit)) || !parse_u64_strict(eq,&(dst))) ok=0; else mask|=(bit); }
        if(!strcmp(line,"format_version")) { if((mask&F_VER)||!parse_u64_strict(eq,&ver)) ok=0; else mask|=F_VER; }
        else if(!strcmp(line,"index")) { if((mask&F_IDX)||!parse_u64_strict(eq,&idx)) ok=0; else mask|=F_IDX; }
        else if(!strcmp(line,"lo")) { if((mask&F_LO)||!parse_u64_strict(eq,&lo)) ok=0; else mask|=F_LO; }
        else if(!strcmp(line,"hi")) { if((mask&F_HI)||!parse_u64_strict(eq,&hi)) ok=0; else mask|=F_HI; }
        else if(!strcmp(line,"seconds")) { if((mask&F_SEC)||!parse_double_strict(eq,&tmpsec)) ok=0; else mask|=F_SEC; }
        else if(!strcmp(line,"tested")) { if((mask&F_TESTED) || !parse_u64_strict(eq,&(tmp.tested))) ok=0; else mask|=F_TESTED; }
        else if(!strcmp(line,"to1")) { if((mask&F_TO1) || !parse_u64_strict(eq,&(tmp.to1))) ok=0; else mask|=F_TO1; }
        else if(!strcmp(line,"to2")) { if((mask&F_TO2) || !parse_u64_strict(eq,&(tmp.to2))) ok=0; else mask|=F_TO2; }
        else if(!strcmp(line,"to4")) { if((mask&F_TO4) || !parse_u64_strict(eq,&(tmp.to4))) ok=0; else mask|=F_TO4; }
        else if(!strcmp(line,"unknown")) { if((mask&F_UNKNOWN) || !parse_u64_strict(eq,&(tmp.unknown))) ok=0; else mask|=F_UNKNOWN; }
        else if(!strcmp(line,"overflow")) { if((mask&F_OVERFLOW) || !parse_u64_strict(eq,&(tmp.overflow))) ok=0; else mask|=F_OVERFLOW; }
        else if(!strcmp(line,"total_steps")) { if((mask&F_TSTEPS)||!str_to_u128(eq,&tmp.total_steps)) ok=0; else mask|=F_TSTEPS; }
        else if(!strcmp(line,"total_v3")) { if((mask&F_TV3)||!str_to_u128(eq,&tmp.total_v3)) ok=0; else mask|=F_TV3; }
        else if(!strcmp(line,"lower_found")) { if((mask&F_LOWER) || !parse_u64_strict(eq,&(tmp.lower_found))) ok=0; else mask|=F_LOWER; }
        else if(!strcmp(line,"no_lower")) { if((mask&F_NOLOWER) || !parse_u64_strict(eq,&(tmp.no_lower))) ok=0; else mask|=F_NOLOWER; }
        else if(!strcmp(line,"known_no_lower")) { if((mask&F_KNOWNNL) || !parse_u64_strict(eq,&(tmp.known_no_lower))) ok=0; else mask|=F_KNOWNNL; }
        else if(!strcmp(line,"unresolved_no_lower")) { if((mask&F_UNRESNL) || !parse_u64_strict(eq,&(tmp.unresolved_no_lower))) ok=0; else mask|=F_UNRESNL; }
        else if(!strcmp(line,"total_first_lower_steps")) { if((mask&F_TFL)||!str_to_u128(eq,&tmp.total_first_lower_steps)) ok=0; else mask|=F_TFL; }
        else if(!strcmp(line,"max_first_lower_steps")) { if((mask&F_MFL) || !parse_u64_strict(eq,&(tmp.max_first_lower_steps))) ok=0; else mask|=F_MFL; }
        else if(!strcmp(line,"max_first_lower_start")) { if((mask&F_MFLS) || !parse_u64_strict(eq,&(tmp.max_first_lower_start))) ok=0; else mask|=F_MFLS; }
        else if(!strcmp(line,"no_lower_logged")) { if((mask&F_NLL)||!parse_u64_strict(eq,&declared_logged)) ok=0; else mask|=F_NLL; }
        else if(!strcmp(line,"no_lower_starts")) {
            if(mask&F_NLS) { ok=0; continue; }
            tmp.no_lower_logged=0;
            if (*eq) {
                char *tok=strtok(eq,",");
                while(tok) {
                    uint64_t v;
                    if(tmp.no_lower_logged>=NO_LOWER_LOG_CAP || !parse_u64_strict(tok,&v)) { ok=0; break; }
                    tmp.no_lower_starts[tmp.no_lower_logged++]=v;
                    tok=strtok(NULL,",");
                }
            }
            if(ok) mask|=F_NLS;
        }
        else if(!strcmp(line,"max_steps")) { if((mask&F_MS) || !parse_u64_strict(eq,&(tmp.max_steps))) ok=0; else mask|=F_MS; }
        else if(!strcmp(line,"max_steps_start")) { if((mask&F_MSS) || !parse_u64_strict(eq,&(tmp.max_steps_start))) ok=0; else mask|=F_MSS; }
        else if(!strcmp(line,"max_v3")) { if((mask&F_MV) || !parse_u64_strict(eq,&(tmp.max_v3))) ok=0; else mask|=F_MV; }
        else if(!strcmp(line,"max_v3_start")) { if((mask&F_MVS) || !parse_u64_strict(eq,&(tmp.max_v3_start))) ok=0; else mask|=F_MVS; }
        else if(!strcmp(line,"max_peak")) { if((mask&F_MP)||!str_to_u128(eq,&tmp.max_peak)) ok=0; else mask|=F_MP; }
        else if(!strcmp(line,"max_peak_start")) { if((mask&F_MPS) || !parse_u64_strict(eq,&(tmp.max_peak_start))) ok=0; else mask|=F_MPS; }
        else if(!strcmp(line,"unknown_start")) { if((mask&F_US) || !parse_u64_strict(eq,&(tmp.unknown_start))) ok=0; else mask|=F_US; }
        else if(!strcmp(line,"unknown_state")) { if((mask&F_USTATE)||!str_to_u128(eq,&tmp.unknown_state)) ok=0; else mask|=F_USTATE; }
        else { ok=0; }
#undef U64_FIELD
    }
    if(ferror(f)) ok=0;
    fclose(f);
    if(!ok || mask!=REQUIRED || ver!=2 || idx!=expected_idx || lo!=expected_lo || hi!=expected_hi) return -1;
    if(declared_logged!=tmp.no_lower_logged || declared_logged>NO_LOWER_LOG_CAP) return -1;
    if(tmp.known_no_lower + tmp.unresolved_no_lower != tmp.no_lower) return -1;
    if(tmp.lower_found + tmp.no_lower != tmp.tested) return -1;
    if(tmp.to1 + tmp.to2 + tmp.to4 + tmp.unknown + tmp.overflow != tmp.tested) return -1;
    *s=tmp; *sec=tmpsec; return 1;
}

static void show_chunk(uint64_t idx,uint64_t chunks,uint64_t lo,uint64_t hi,double sec,
                       const Stats *c,const Stats *session) {
    char peak[64], st[64], tv[64], sp[64];
    u128_to_str(c->max_peak,peak,sizeof(peak));
    u128_to_str(session->total_steps,st,sizeof(st));
    u128_to_str(session->total_v3,tv,sizeof(tv));
    u128_to_str(session->max_peak,sp,sizeof(sp));
    double pct=100.0*(double)idx/(double)chunks;
    printf("\nchunk:          %" PRIu64 " / %" PRIu64 "   (%.2f%% complete)\n",idx,chunks,pct);
    printf("n-range:        [%" PRIu64 ", %" PRIu64 "]\n",lo,hi);
    printf("chunk starts:   %" PRIu64 "\n",c->tested);
    printf("chunk seconds:  %.3f\n",sec);
    printf("chunk rate:     %.0f starts/sec\n",sec>0?(double)c->tested/sec:0.0);
    printf("outcomes:       1=%" PRIu64 "  2=%" PRIu64 "  cycle4=%" PRIu64 "  new=%" PRIu64 "  ovf=%" PRIu64 "\n",
           c->to1,c->to2,c->to4,c->unknown,c->overflow);
    printf("chunk max steps: n=%" PRIu64 " steps=%" PRIu64 "\n",c->max_steps_start,c->max_steps);
    printf("chunk max v3:    n=%" PRIu64 " v3=%" PRIu64 "\n",c->max_v3_start,c->max_v3);
    printf("chunk max peak:  n=%" PRIu64 " peak=%s\n",c->max_peak_start,peak);
    printf("first-lower:      found=%" PRIu64 "  no_lower=%" PRIu64 " (known=%" PRIu64 ", unresolved=%" PRIu64 ")\n",c->lower_found,c->no_lower,c->known_no_lower,c->unresolved_no_lower);
    printf("chunk max first-lower: n=%" PRIu64 " steps=%" PRIu64 "\n",
           c->max_first_lower_start,c->max_first_lower_steps);
    printf("session totals:\n");
    printf("starts:         %" PRIu64 "\n",session->tested);
    printf("to 1:           %" PRIu64 "\n",session->to1);
    printf("to 2:           %" PRIu64 "\n",session->to2);
    printf("cycle4:         %" PRIu64 "\n",session->to4);
    printf("new:            %" PRIu64 "\n",session->unknown);
    printf("overflow:       %" PRIu64 "\n",session->overflow);
    printf("first-lower:    found=%" PRIu64 "  no_lower=%" PRIu64 " (known=%" PRIu64 ", unresolved=%" PRIu64 ")\n",
           session->lower_found,session->no_lower,session->known_no_lower,session->unresolved_no_lower);
    printf("max first-lower: n=%" PRIu64 " steps=%" PRIu64 "\n",
           session->max_first_lower_start,session->max_first_lower_steps);
    printf("total steps:    %s\n",st);
    printf("total v3:       %s\n",tv);
    printf("max steps:      n=%" PRIu64 " steps=%" PRIu64 "\n",session->max_steps_start,session->max_steps);
    printf("max v3:         n=%" PRIu64 " v3=%" PRIu64 "\n",session->max_v3_start,session->max_v3);
    printf("max peak:       n=%" PRIu64 " peak=%s\n",session->max_peak_start,sp);
    fflush(stdout);
}


static void print_first_lower_trace(uint64_t start) {
    if (!start) return;
    u128 x=(u128)start;
    uint64_t j=0;
    char xs[64], ys[64];

    printf("\nFIRST-LOWER RECORD TRACE\n");
    printf("start=%" PRIu64 "\n",start);
    printf("step  from  v3  to\n");

    for (;;) {
        int a=attractor_id(x);
        if (a) {
            printf("trace ended at known attractor before strict descent.\n");
            break;
        }

        u128 y; uint32_t v;
        if (!map_step(x,&y,&v)) {
            printf("trace ended by arithmetic overflow/invalid state.\n");
            break;
        }

        ++j;
        u128_to_str(x,xs,sizeof(xs));
        u128_to_str(y,ys,sizeof(ys));
        printf("%" PRIu64 "  %s  %" PRIu32 "  %s",j,xs,v,ys);
        if (y < (u128)start) {
            printf("  <-- FIRST LOWER\n");
            break;
        }
        printf("\n");
        x=y;
    }
}

int main(int argc,char **argv) {
    if(argc!=6) {
        fprintf(stderr,"Usage: %s START END CHUNK THREADS RESULTS_DIR\n",argv[0]);
        return 1;
    }
    uint64_t start=strtoull(argv[1],NULL,10), end=strtoull(argv[2],NULL,10);
    uint64_t chunk=strtoull(argv[3],NULL,10);
    int threads=atoi(argv[4]); const char *dir=argv[5];
    if(start<1 || end<start || chunk<1 || threads<1 || threads>256) {
        fprintf(stderr,"Invalid arguments.\n"); return 1;
    }
    if(!mkdir_if_needed(dir)) return 1;

    uint64_t span=end-start+1;
    uint64_t chunks=span/chunk + (span%chunk != 0);
    Stats session; memset(&session,0,sizeof(session));

    printf("TERNARY (4k-1(2))/3 CHUNKED 128-BIT SCAN - PERFORMANCE V5.2 AUDIT-HARDENED + FIRST-LOWER + STRICT CHECKPOINTS\n");
    printf("range:   [%" PRIu64 ", %" PRIu64 "]\nchunk:   %" PRIu64 " raw integers\nthreads: %d\nresults: %s\n",
           start,end,chunk,threads,dir);

    for(uint64_t idx=1; idx<=chunks; ++idx) {
        uint64_t lo=start+(idx-1)*chunk;
        uint64_t hi=(end-lo+1<chunk)?end:lo+chunk-1;
        Stats cs; double sec=0.0;

        int load_status=load_done(dir,idx,lo,hi,&cs,&sec);
        if(load_status < 0) {
            fprintf(stderr,"Checkpoint validation failed for chunk %" PRIu64 " (expected range [%" PRIu64 ", %" PRIu64 "]). Refusing stale/corrupt checkpoint.\n",idx,lo,hi);
            return 1;
        }
        if(load_status > 0) {
            merge(&session,&cs);
            printf("\n[resume] chunk %" PRIu64 " already complete; loaded checkpoint.\n",idx);
            show_chunk(idx,chunks,lo,hi,sec,&cs,&session);
            continue;
        }

        ChunkCtx ctx; ctx.lo=lo; ctx.hi=hi; atomic_init(&ctx.next_raw,lo);
        pthread_t *tid=malloc((size_t)threads*sizeof(*tid));
        Stats *locals=calloc((size_t)threads,sizeof(*locals));
        WorkerArg *args=malloc((size_t)threads*sizeof(*args));
        if(!tid || !locals || !args) { fprintf(stderr,"Allocation failed.\n"); return 1; }

        struct timespec t0,t1; clock_gettime(CLOCK_MONOTONIC,&t0);
        for(int i=0;i<threads;++i) {
            args[i].ctx=&ctx; args[i].s=&locals[i];
            if(pthread_create(&tid[i],NULL,worker,&args[i])!=0) { fprintf(stderr,"pthread_create failed.\n"); return 1; }
        }
        for(int i=0;i<threads;++i) pthread_join(tid[i],NULL);
        clock_gettime(CLOCK_MONOTONIC,&t1);
        sec=(double)(t1.tv_sec-t0.tv_sec)+(double)(t1.tv_nsec-t0.tv_nsec)/1e9;

        memset(&cs,0,sizeof(cs));
        for(int i=0;i<threads;++i) merge(&cs,&locals[i]);
        free(tid); free(locals); free(args);

        if(!save_done(dir,idx,lo,hi,sec,&cs)) {
            fprintf(stderr,"Could not save checkpoint for chunk %" PRIu64 ".\n",idx);
            return 1;
        }
        merge(&session,&cs);
        show_chunk(idx,chunks,lo,hi,sec,&cs,&session);
    }

    char st[64],tv[64],pk[64];
    u128_to_str(session.total_steps,st,sizeof(st)); u128_to_str(session.total_v3,tv,sizeof(tv));
    u128_to_str(session.max_peak,pk,sizeof(pk));
    printf("\n============================================================\nFINAL NEW-RANGE TOTALS\n");
    printf("starts=%" PRIu64 "  1=%" PRIu64 "  2=%" PRIu64 "  cycle4=%" PRIu64 "  new=%" PRIu64 "  ovf=%" PRIu64 "\n",
           session.tested,session.to1,session.to2,session.to4,session.unknown,session.overflow);
    printf("total_steps=%s  total_v3=%s\n",st,tv);
    printf("first_lower_found=%" PRIu64 "  no_lower=%" PRIu64 "  known_no_lower=%" PRIu64 "  unresolved_no_lower=%" PRIu64 "\n",
           session.lower_found,session.no_lower,session.known_no_lower,session.unresolved_no_lower);
    printf("max_first_lower: n=%" PRIu64 " steps=%" PRIu64 "\n",
           session.max_first_lower_start,session.max_first_lower_steps);
    printf("max_steps: n=%" PRIu64 " steps=%" PRIu64 "\n",session.max_steps_start,session.max_steps);
    printf("max_v3:    n=%" PRIu64 " v3=%" PRIu64 "\n",session.max_v3_start,session.max_v3);
    printf("max_peak:  n=%" PRIu64 " peak=%s\n",session.max_peak_start,pk);
    printf("============================================================\n");

    printf("\nNO-LOWER EXCEPTIONS");
    if (session.no_lower > session.no_lower_logged)
        printf(" (first %" PRIu64 " of %" PRIu64 " logged)",session.no_lower_logged,session.no_lower);
    printf("\n");
    if (!session.no_lower_logged) printf("none\n");
    else {
        for (uint64_t i=0;i<session.no_lower_logged;++i)
            printf("%s%" PRIu64, (i?", ":""), session.no_lower_starts[i]);
        printf("\n");
    }

    /*
     * Replay only the hardest first-lower record holder. This gives the exact
     * valuation sequence needed for later 3-adic/residue-class analysis while
     * keeping the production scan fast and checkpoint files compact.
     */
    print_first_lower_trace(session.max_first_lower_start);
    return 0;
}
