#!/usr/bin/env python3
from fractions import Fraction
from decimal import Decimal, getcontext

MAX_M = 500
getcontext().prec = 100
alpha = Decimal(4).ln() / Decimal(3).ln()

p = {0: Fraction(1,1)}
wanted = {6,10,20,25,30,40,50,100,200,500}
for t in range(1, MAX_M+1):
    cap = int((alpha*Decimal(t)).to_integral_value(rounding="ROUND_CEILING")) - 1
    new = {}
    for s,mass in p.items():
        for k in range(1, cap-s+1):
            u=s+k
            new[u] = new.get(u, Fraction(0,1)) + mass*Fraction(2,3**k)
    p=new
    if t in wanted:
        total=sum(p.values(), Fraction(0,1))
        print(t, total.numerator, total.denominator)
