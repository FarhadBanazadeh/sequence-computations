# V3 Mathematical Core --- Audit D.1 Corrected

## Exhaustive Computation, First-Descent Verification, and V5.2 Audit-Hardened Revalidation through (10\^{11})

**Project:** Ternary ((4k-1(2))/3) Collatz-Type Map\
**Status:** **AUDIT D.1 --- COMPUTATIONALLY VERIFIED**, with explicit
re-execution scope\
**Date:** 23 September 2026

**Correction note.** The final numerical cross-check found one
transcription error in the annotation of the last transition of the
355-step record. The state \[ 491,591,720,993 \] satisfies \[
491,591,720,993`\equiv2`{=tex}`\pmod3`{=tex}, \] so the final numerator
is (4x-2), not (4x-1). The valuation (a=5), the next state
(8,092,044,790), the accumulated valuation (A\_{355}=450), and the
first-descent time (355) were already correct. No aggregate
computational result changes.

------------------------------------------------------------------------

## 1. Computational scope

The full archived finite domain is \[
1`\le `{=tex}n`\le10`{=tex}\^{11},`\qquad 3`{=tex}`\nmid `{=tex}n, \]
containing exactly \[ 66,666,666,667 \] admissible starts.

The audit distinguishes:

1.  exhaustive archived results from the original scans;
2.  independent checkpoint aggregation and structural/source audit;
3.  fresh V5.2 re-execution on selected validation ranges.

The complete (10\^{11}) domain was **not** freshly recomputed from zero
with V5.2 during this audit.

------------------------------------------------------------------------

## 2. Archived convergence totals

For (10^9\<n`\le10`{=tex}^{11}): \[
```{=tex}
\begin{aligned}
\text{tested}&=66\,000\,000\,000,\\
\text{to }\{1\}&=6\,536\,905\,587,\\
\text{to }\{2\}&=42\,779\,024\,148,\\
\text{to four-cycle}&=16\,684\,070\,265,\\
\text{unknown cycles}&=0,\\
\text{overflows}&=0.
\end{aligned}
```
\]

Combined with the base interval (1`\le `{=tex}n`\le10`{=tex}\^9): \[
```{=tex}
\begin{aligned}
\text{to }\{1\}&=6\,602\,925\,203,\\
\text{to }\{2\}&=43\,211\,124\,603,\\
\text{to four-cycle}&=16\,852\,616\,861.
\end{aligned}
```
\] Their sum is exactly \[ 66,666,666,667. \]

The extension records are: \[ `\text{max reduced transient}`{=tex}=574
`\quad`{=tex}`\text{at }`{=tex}n=97,312,923,676, \] \[
`\text{max accumulated }`{=tex}`\nu`{=tex}\_3=744
`\quad`{=tex}`\text{at the same start}`{=tex}, \] and \[
`\text{max reduced peak}`{=tex} = 580,315,803,007,928,858,285 \] from \[
n=52,991,345,843. \]

------------------------------------------------------------------------

## 3. First-descent verification

For the extension interval (10^9\<n`\le10`{=tex}^{11}), \[
`\text{first\_lower\_found}`{=tex}=66,000,000,000, `\qquad`{=tex}
`\text{no\_lower}`{=tex}=0. \]

For the base interval, the only 12 scanner-semantic no-lower cases are
\[ 1,2,8,10,13,17,22,28,29,37,38,50. \] They enter or lie on the known
terminal cycles before becoming strictly smaller than their starting
value.

Therefore the strongest finite first-descent statement is \[ `\boxed{
\forall n\in\mathbb Z_{>0},\quad
3\nmid n,\quad
50<n\le10^{11}
\Longrightarrow
\exists j\ge1:T^j(n)<n.
}`{=tex} \]

The largest observed first-descent time is \[ `\boxed{
\tau(76\,089\,719\,024)=355.
}`{=tex} \]

------------------------------------------------------------------------

## 4. Corrected hardest first-descent trajectory

The final five transitions of the independently regenerated record
trajectory are \[ 1,399,884,236,737 `\xrightarrow{a=2}`{=tex}
622,170,771,883, \] \[ 622,170,771,883 `\xrightarrow{a=2}`{=tex}
276,520,343,059, \] \[ 276,520,343,059 `\xrightarrow{a=1}`{=tex}
368,693,790,745, \] \[ 368,693,790,745 `\xrightarrow{a=1}`{=tex}
491,591,720,993, \] and \[ 491,591,720,993 `\xrightarrow{a=5}`{=tex}
8,092,044,790. \]

For the final transition, \[
491,591,720,993`\equiv2`{=tex}`\pmod3`{=tex}, \] hence \[ r=2. \]
Therefore \[ 4x-r = 4(491,591,720,993)-2 = 1,966,366,883,970. \]
Exactly, \[ `\nu`{=tex}\_3(1,966,366,883,970)=5, \] and \[
`\frac{1\,966\,366\,883\,970}{3^5}`{=tex} = 8,092,044,790. \]

Thus \[ 8,092,044,790 \< 76,089,719,024, \] while the first 354 iterates
remain at least as large as the starting value.

The earlier annotation (r=1) for this final transition is superseded by
the corrected value \[ `\boxed{r=2}`{=tex}. \]

------------------------------------------------------------------------

## 5. Valuation audit of the 355-step record

Across the 355 transitions: \[
```{=tex}
\begin{array}{c|ccccc}
a&1&2&3&4&5\\
\hline
\#&283&54&14&3&1.
\end{array}
```
\]

Hence \[ A\_{354}=445,`\qquad `{=tex}A\_{355}=450. \]

With \[ `\alpha`{=tex}=`\log`{=tex}\_3 4, \] \[
445\<354`\alpha`{=tex}`\approx446.6982655`{=tex}, \] whereas \[
450\>355`\alpha`{=tex}`\approx447.9601250`{=tex}. \]

Therefore the sufficient Audit-B descent barrier is first crossed at the
final step of this record. The corrected residue annotation does not
change the valuation count or this conclusion.

------------------------------------------------------------------------

## 6. V5.1 structural audit and V5.2 hardening

The V5.1 orbit arithmetic, first-lower semantics, known-cycle detection,
unknown-cycle detection, work allocation, and audited finite overflow
handling passed structural review.

The reproducibility weaknesses found were:

-   insufficient checkpoint identity validation;
-   parse success not uniformly enforced;
-   incomplete required-field enforcement;
-   broad `no_lower` semantics that could mix resolved and unresolved
    terminations in generic error paths;
-   a finite explicit exception-log cap.

V5.2 hardened these layers without changing the orbit map:

-   strict checkpoint format/version;
-   expected index/interval validation;
-   strict numeric parsing;
-   required-field masks;
-   aggregate consistency checks;
-   separate known and unresolved no-lower categories;
-   rejection of malformed or stale checkpoints.

------------------------------------------------------------------------

## 7. Fresh V5.2 validation

Through (10\^6), V5.2 reproduced: \[ 666,667 \] admissible starts, with
\[ 66,382`\to`{=tex}{1},`\qquad
431`{=tex},888`\to`{=tex}{2},`\qquad
168`{=tex},397`\to `{=tex}C_4, \] and \[
`\text{unknown}`{=tex}=0,`\qquad`{=tex}`\text{overflow}`{=tex}=0. \] It
gave \[ `\text{first-lower}`{=tex}=666,655,`\qquad`{=tex}
`\text{known\_no\_lower}`{=tex}=12,`\qquad`{=tex}
`\text{unresolved\_no\_lower}`{=tex}=0. \]

Through (10\^7), V5.1 and V5.2 agreed on: \[ 6,666,667 \] starts, \[
659,904`\to`{=tex}{1},`\quad
4`{=tex},318,371`\to`{=tex}{2},`\quad
1`{=tex},688,392`\to `{=tex}C_4, \] with \[
`\text{unknown}`{=tex}=`\text{overflow}`{=tex}=0, \] and \[
`\text{first-lower}`{=tex}=6,666,655,`\qquad`{=tex}
`\text{no-lower}`{=tex}=12. \]

A fresh V5.2 re-execution of \[
76,000,000,001`\le `{=tex}n`\le76`{=tex},100,000,000 \] covered
(66,666,667) admissible starts and reproduced the historical checkpoint
statistics, including the record \[
n=76,089,719,024,`\qquad`{=tex}`\tau`{=tex}(n)=355. \]

------------------------------------------------------------------------

## 8. Full checkpoint audit

The available archive contains 990 extension checkpoints and 10 base
checkpoints.

All \[ `\boxed{1000/1000}`{=tex} \] passed the applied structural
checks, and independent aggregation recovered the reported totals.

This is a structural and aggregate validation of the available archive,
not a cryptographic proof of the original historical bytes.

------------------------------------------------------------------------

## 9. Relationship to the mathematical audits

Audit A supplies the exact 3-adic inverse-branch and iid valuation
theory.

Audit B supplies \[ T\^j(n)=`\frac{4^jn-C_j}{3^{A_j}}`{=tex} \] and the
sufficient descent criterion \[ A_j`\ge `{=tex}j`\log`{=tex}\_3 4. \]

Audit C.3 supplies the publication-certified Haar-to-integer density
transfer, exact-rational DP values, and the density-one first-descent
theorem \[
d_S{n`\in `{=tex}S:`\exists `{=tex}j`\ge1`{=tex}, T\^j(n)\<n}=1. \]

Audit D.1 supplies the finite computational complement through
(10\^{11}).

These statements are complementary. The density-one theorem is not
universal first descent, and the finite scan is not an all-integers
convergence proof.

------------------------------------------------------------------------

## 10. Nonclaims

Audit D.1 does not prove:

-   convergence for all admissible positive integers;
-   universal first descent beyond (10\^{11});
-   absence of other positive cycles globally;
-   absence of unbounded integer trajectories;
-   a complete fresh V5.2 rerun of all (66,666,666,667) admissible
    starts.

------------------------------------------------------------------------

## 11. Final conclusion

No contradiction was found among the archived computation, aggregate
totals, checkpoint audit, independently regenerated hardest trajectory,
and fresh V5.2 validation runs.

The only correction introduced by the final numerical cross-check is the
residue annotation in the last transition of the 355-step record: \[
`\boxed{
491\,591\,720\,993\equiv2\pmod3,
\qquad r=2.
}`{=tex} \] Accordingly, \[ 4x-r=4x-2, \] and \[
T(491,591,720,993)=8,092,044,790. \]

All previously reported record values, valuation totals, first-descent
time, and finite-domain conclusions remain unchanged.

**AUDIT D.1 STATUS: COMPUTATIONALLY VERIFIED WITH CORRECTED TRACE
ANNOTATION AND EXPLICIT RE-EXECUTION SCOPE.**
