# V3 Mathematical Core --- Exact-Rational DP Audit

## Independent certification of the finite-horizon survivor probabilities

**Status:** **EXACT-RATIONAL DP --- VERIFIED**\
**Date:** 23 September 2026

## 1. Object recomputed

For the iid valuation law

\[ `\Pr`{=tex}(a=k)=`\frac{2}{3^k}`{=tex},`\qquad `{=tex}k`\ge1`{=tex},
\]

the finite-horizon survivor probability is

\[ `\mu`{=tex}(`\mathcal `{=tex}S_m) = `\Pr`{=tex}!`\left`{=tex}( A_t\<
t`\log`{=tex}*3 4 `\text{for every }`{=tex}1`\le `{=tex}t`\le `{=tex}m
`\right`{=tex}), `\qquad`{=tex} A_t=`\sum`{=tex}*{i=0}\^{t-1}a_i. \]

The computation below was performed independently with Python's
arbitrary-precision `Fraction` arithmetic. No floating-point probability
arithmetic was used.

Because (`\alpha`{=tex}=`\log`{=tex}\_3 4) is irrational, the integer
survivor condition at time (t) is exactly

\[ A_t`\le `{=tex}`\lceil `{=tex}`\alpha `{=tex}t`\rceil-1`{=tex}. \]

The integer thresholds were generated with 100-digit Decimal logarithms
and cross-checked independently against ordinary double-precision values
through depth 500; no threshold disagreement occurred.

## 2. Exact recurrence

Starting from

\[ p_0(0)=1, \]

the exact recurrence is

\[ p\_{t+1}(s+k) `\mathrel{+}`{=tex}= p_t(s)`\frac{2}{3^k}`{=tex}, \]

for every (k`\ge1`{=tex}) satisfying

\[ s+k`\le `{=tex}`\lceil`{=tex}`\alpha`{=tex}(t+1)`\rceil-1`{=tex}. \]

Every state probability is therefore a rational number and

\[ `\mu`{=tex}(`\mathcal `{=tex}S_t)=`\sum`{=tex}\_s p_t(s) \]

is computed exactly as a rational number.

## 3. Certified values

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                        m                                           exact rational value                                                                          decimal value
  ----------------------- -------------------------------------------------------------- --------------------------------------------------------------------------------------
                        6                                                      `128/729`     0.17558299039780521262002743484224965706447187928669410150891632373113854595336077

                       10                                                 `16384/177147`    0.092488159551107272491207866912789942815853500200398539066425059413933061242922545

                       20                                     `23521656832/847288609443`    0.027761091757698628934759475070319932206061642016852244246959368479597959239810934

                       25                                 `1220173365248/68630377364883`    0.017778910915217289984036800187688029706085231861024198407855276860078198513525384

                       30                          `4953662807867392/450283905890997363`    0.011001198894873563812655352237188791211244018365755275411384024719067171177225032

                       40              `3572683711808203128832/717897987691852588770249`   0.0049765896729908739531344819554572316631244878512840873624354812296154290810632628

                       50   `301646097509840481608007680/127173474825648610542883299603`   0.0023719262049211843202818974801539388394722515170811554287004876531638043337443633
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 4. Comparison with the previously reported Audit-C values

The independently recomputed exact-rational values agree with the
previously reported decimal values to the displayed precision. The small
differences below are only the consequence of truncation/rounding in the
earlier printed decimal strings, not differences in the underlying DP.

  ------------------------------------------------------------------------------------------------------------
                                    m                     exact-rational decimal minus earlier printed decimal
  ----------------------------------- ------------------------------------------------------------------------
                                    6     -3.7997256515775034293552812071330589849108367626886145404663923E-19

                                   10   3.3491207866912789942815853500200398539066425059413933061242922545E-17

                                   20     -1.5240524929680067793938357983147755753040631520402040760189066E-20

                                   25     -1.5963199812311970293914768138975801592144723139921801486474616E-20

                                   30      -7.344647762811208788755981634244724588615975280932828822774968E-21

                                   40     -5.8655180445427683368755121487159126375645187703845709189367372E-21

                                   50     -3.7181025198460611605277484829188445712995123468361956662556367E-21
  ------------------------------------------------------------------------------------------------------------

In particular,

\[ `\mu`{=tex}(`\mathcal `{=tex}S\_{50}) =

`301646097509840481608007680/127173474825648610542883299603`

\]

and numerically

\[ `\boxed{
\mu(\mathcal S_{50})
\approx

0.0023719262049211843202818974801539388394722515170811554287004876531638043337443633

}`{=tex}. \]

Hence Audit C.2 gives the certified finite-horizon density

\[ d_S(D\_{50}) = 1-`\mu`{=tex}(`\mathcal `{=tex}S\_{50})
`\approx`{=tex}

0.99762807379507881567971810251984606116052774848291884457129951234683619566625564

, \]

or approximately (99.76280737950788%).

## 5. Deeper exact-rational exploratory check

The same exact recurrence was continued to depths 100, 200, and 500.
These values are useful as an independent numerical check, but they do
not prove any new asymptotic theorem.

  ----------------------------------------------------------------------------------------------------------------------------
                                    m                                                                exact-rational DP decimal
  ----------------------------------- ----------------------------------------------------------------------------------------
                                  100   0.000085704175568195754117864603806055558289614295630505463640063326776100322638687520

                                  200     2.6209977651649499530275599089647101853509115418097202946861546200923611024961940E-7

                                  500    3.0437604792015828564049946595910410179963035657093673124942287279542111858347389E-14
  ----------------------------------------------------------------------------------------------------------------------------

These deeper values confirm the earlier qualitative observation of rapid
decay. They must not be promoted to the conjectural asymptotic

\[ `\mu`{=tex}(`\mathcal `{=tex}S_m)`\sim `{=tex}C
m^{-3/2}`\rho`{=tex}^m \]

without a separate analytic proof.

## 6. Audit conclusion

The finite-horizon DP values used in Audit C.2 have now been
independently recomputed using exact rational arithmetic. The values
through depth 50 agree with the previously reported table to its printed
precision.

Thus the numerical statement

\[ d_S(D\_{50})=1-`\mu`{=tex}(`\mathcal `{=tex}S\_{50}) \]

is no longer dependent on floating-point probability accumulation.

This computation certifies the DP numerics only. The equality between
this probability and the relative natural density of actual
first-descent integers is supplied by the mathematical proof in Audit
C.2, not by the computation.

**EXACT-RATIONAL DP STATUS: VERIFIED.**
