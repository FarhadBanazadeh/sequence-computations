# V3 Numerical Cross-Check Audit

**Status:** **PASS WITH ONE CORRECTION TO THE RECORDED TRACE
ANNOTATION**\
**Date:** 23 September 2026

## 1. Constants

-   alpha =
    1.261859507142914874199054228685521708599171280263760855741309887677370402761829610122345377098903491
-   beta =
    0.261859507142914874199054228685521708599171280263760855741309887677370402761829610122345377098903491
-   q\* =
    0.6225562489182657278193915840782752368602783884612784093163710181883526583084621562165792876228676366
-   rho =
    0.9523926526058126570369450626434929459883915085657269290231626279064447899281833492327915262950795541

Required inequalities were confirmed: (1\<`\alpha`{=tex}\<3/2),
(`\beta`{=tex}\>0), (0\<q\^\*\<1), and (`\rho`{=tex}\<1).

## 2. Exact-rational DP

The recurrence was independently recomputed with exact rational
arithmetic through depth 500. The publication values through depth 50
agree with the earlier Audit-C table up to its printed rounding.

At depth 50: \[ `\mu`{=tex}(`\mathcal `{=tex}S\_{50}) =
`\frac{301646097509840481608007680}{127173474825648610542883299603}`{=tex}
=
0.002371926204921184320281897480153938839472251517081155428700487653163804333744363277889714841979564349.
\]

Therefore \[
d_S(D\_{50})=0.9976280737950788156797181025198460611605277484829188445712995123468361956662556367221102851580204357.
\]

## 3. Hardest first-descent barrier

For (n=76,089,719,024): \[
A\_{354}=445\<354`\alpha=446.6982655285918654664651969546746848441066332133713429324237002377891225776876819833102634930118358`{=tex},
\] while \[
A\_{355}=450\>355`\alpha=447.9601250357347803406642511833602065527058044936351037881650101254664929804495115934326088701107393`{=tex}.
\] Thus the sufficient barrier is crossed at step 355.

## 4. Important trace-annotation correction

A direct arithmetic check found one transcription error in the
previously recorded final trace annotation.

The state is \[ x=491,591,720,993. \] Its residue is \[
x`\bmod3`{=tex}=2, \] not (1). Therefore the numerator is \[
4x-2=1966366883970. \] It has \[ `\nu`{=tex}\_3(4x-2)=5 \] and reduces
exactly to \[ `\frac{4x-2}{3^5}`{=tex}=8092044790. \]

Thus the previously recorded numerical next state (8,092,044,790), the
valuation (a=5), and the first-descent conclusion are all correct; only
the residue/numerator annotation (r=1) was wrong and must be corrected
to (r=2).

## 5. Aggregate (10\^{11}) arithmetic

The combined counts are arithmetically consistent: - admissible starts:
66,666,666,667 - to 1: 6,602,925,203 - to 2: 43,211,124,603 - to the
4-cycle: 16,852,616,861

and \[ 6,602,925,203+43,211,124,603+16,852,616,861 = 66,666,666,667. \]

The old (1..10\^9) totals plus the (10^9\<n`\le10`{=tex}^{11}) extension
totals reproduce these combined values exactly.

## 6. Scope

This is an arithmetic and numerical cross-check, not a fresh full V5.2
recomputation of the entire domain through (10\^{11}). Audit D's scope
distinction remains unchanged.

**NUMERICAL CROSS-CHECK STATUS: PASS, with the single residue annotation
correction above.**
