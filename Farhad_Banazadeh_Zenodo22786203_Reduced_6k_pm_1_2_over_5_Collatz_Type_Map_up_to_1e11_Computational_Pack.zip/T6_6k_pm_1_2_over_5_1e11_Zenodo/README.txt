The Reduced 6k +/- {1,2}/5 Collatz-Type Domain with Three Observed Attractors up to 10^11
Farhad Banazadeh
16 September 2026

PURPOSE
This is the curated computational supplement for the article. It contains only the v2
production source and the final 10^11 production outputs used in the paper. The obsolete
pre-v2 source, old executable binaries, and old validation outputs are intentionally omitted.

REDUCED DOMAIN
Starting values: positive integers n with 5 not dividing n.

MAP
For n not divisible by 5:
  n mod 5 = 1 : numerator = 6n - 1
  n mod 5 = 2 : numerator = 6n - 2
  n mod 5 = 3 : numerator = 6n + 2
  n mod 5 = 4 : numerator = 6n + 1
Then divide the numerator by every factor of 5, i.e. by 5^v_5(numerator).

OBSERVED ATTRACTORS
  {1}
  {2}
  {22, 26, 31, 37, 44, 53, 64, 77, 92}

FULL PRODUCTION RESULT
Raw upper bound: 100,000,000,000
Reduced starting values scanned: 80,000,000,000
To {1}:       41,199,583,259
To {2}:       11,613,268,146
To 9-cycle:   27,187,148,595
New cycles:   0
Overflow128:  0
Step-limit:   0

Maximum stopping time:
  n = 63,909,268,656
  steps = 755
  path peak = 303,105,476,921,832,704
  total removed factors of 5 = 856

Maximum reduced peak:
  start = 73,433,001,822
  peak = 18,774,256,269,070,896,812,821
  peak step = 250
  stopping time = 445

FILES
scan_6n_over5_128_v2.c
  Final v2 C scanner used as the reference implementation.

scan_1e11.chunks.tsv
  Complete 1000-row production chunk table. Each raw chunk spans 100,000,000 integers
  and evaluates 80,000,000 reduced starting values.

scan_1e11.records.tsv
  Per-chunk maximum stopping-time and maximum-peak entries.

scan_1e11.cycles.tsv
  Additional-cycle log. It contains only the header because no additional cycle was detected.

scan_1e11.summary.txt
  Final production summary.

Farhad_Banazadeh_Reduced_6k_pm_1_2_over_5_up_to_1e11.tex
  LaTeX source of the accompanying paper.

AUDIT_NOTES.txt
  Internal consistency and independent trajectory checks performed while curating this archive.

SHA256SUMS.txt
  SHA-256 hashes for all publication files in this directory except SHA256SUMS.txt itself.

BUILD
A compatible Clang/POSIX build command is:
  clang -O3 -march=native -pthread -std=c11 -Wall -Wextra \
    scan_6n_over5_128_v2.c -o scan_6n_over5_128_v2

The production data use a raw chunk size of 100,000,000 and an upper bound of 10^11.
The v2 program accepts -m MAX, -t THREADS, -c CHUNK, -C CACHE_LIMIT, and -o PREFIX.
A representative invocation is:
  ./scan_6n_over5_128_v2 -m 100000000000 -t 4 -c 100000000 \
    -C CACHE_LIMIT -o scan_1e11
where CACHE_LIMIT is a chosen memoization-cache size supported by the machine's memory.
The cache changes performance, not the mathematical map.

IMPORTANT INTERPRETATION
The archive establishes an exhaustive finite computation for the stated range under the
archived implementation. It does not constitute a proof that the three observed attractors
are the only attractors for all positive integers or that every positive orbit converges.
