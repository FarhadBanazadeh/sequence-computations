// scan_6n_over5_128_v2.c
// Optimized scanner for:
// r=1: (6n-1)/5, r=2: (6n-2)/5, r=3: (6n+2)/5, r=4: (6n+1)/5,
// followed by removing all extra factors of 5.
//
// v2 changes:
// - fixes false "new cycle" classification of 1 and 2
// - fast uint64_t arithmetic for the normal case, automatic unsigned __int128 fallback
// - shared memoization cache for small states
// - Brent cycle detector instead of Floyd (less trajectory work)
// - 4-thread chunk scan, checkpoint/resume, terminal progress
// - records stopping-time, peak, peak step, /5 count, outcomes, anomalies/new cycles
//
// Build:
// clang -O3 -march=native -pthread -std=c11 -Wall -Wextra scan_6n_over5_128_v2.c -o scan_6n_over5_128_v2
//
// Benchmark:
// ./scan_6n_over5_128_v2 -m 10000000 -t 4 -c 1000000 -C 20000000 -o scan_v2_test
//
// Production example:
// ./scan_6n_over5_128_v2 -m 10000000000 -t 4 -c 10000000 -C 50000000 -o scan_1e10_v2

#define _DARWIN_C_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <unistd.h>
#include <limits.h>

typedef unsigned __int128 u128;
static const u128 U128_MAXV=(u128)(~(u128)0);

enum { O_UNKNOWN=0, O_ONE=1, O_TWO=2, O_C9=3, O_NEWCYCLE=4, O_OVERFLOW=5, O_LIMIT=6 };
#define KNOWN_N 9
static const uint64_t kc[KNOWN_N]={22,26,31,37,44,53,64,77,92};
#define HARD_STEP_LIMIT 10000000ULL

typedef struct {
    _Atomic uint8_t ready;
    uint8_t outcome;
    uint16_t pad;
    uint32_t steps;
    uint32_t div5;
    uint32_t peak_step;
    uint64_t peak;
} CacheEntry;

static CacheEntry *cache=NULL;
static uint64_t cache_limit=0;
static volatile sig_atomic_t stop_requested=0;

typedef struct {
    uint64_t start, steps, div5, peak_step;
    u128 peak, cycle_min;
    uint64_t cycle_len;
    uint8_t outcome;
} Eval;

typedef struct {
    uint64_t starts,one,two,c9,newcyc,overflow,limit;
    uint64_t sum_steps,sum_div5;
    uint64_t max_steps,max_steps_n;
    u128 max_steps_peak;
    u128 max_peak;
    uint64_t max_peak_n,max_peak_step,max_peak_steps;
    uint64_t max_div5,max_div5_n;
} Stats;

typedef struct {
    uint64_t lo,hi;
    Stats st;
    FILE *cycles;
    pthread_mutex_t *io_mu;
} WArg;

static void sig_handler(int x){(void)x;stop_requested=1;}
static double nowsec(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}

static void s128(u128 x,char *b,size_t z){
    if(!z)return; if(!x){if(z>1){b[0]='0';b[1]=0;}return;}
    char q[64];size_t n=0;while(x){q[n++]=(char)('0'+x%10);x/=10;}
    size_t j=0;while(n&&j+1<z)b[j++]=q[--n];b[j]=0;
}
static inline int known(uint64_t x){
    for(int i=0;i<KNOWN_N;i++)if(x==kc[i])return 1;
    return 0;
}

// Fast 64-bit reduced step. If 6*n+2 may overflow, return false and caller switches to 128-bit.
static inline bool step64(uint64_t n,uint64_t *y,uint32_t *d){
    unsigned r=(unsigned)(n%5);
    if(r==0){
        uint32_t k=0;do{n/=5;k++;}while(n%5==0);*y=n;*d=k;return true;
    }
    if(n>(UINT64_MAX-2ULL)/6ULL)return false;
    uint64_t x=n*6ULL;
    if(r==1)x-=1; else if(r==2)x-=2; else if(r==3)x+=2; else x+=1;
    uint32_t k=1;x/=5;
    while(x%5==0){x/=5;k++;}
    *y=x;*d=k;return true;
}
static inline bool step128(u128 n,u128 *y,uint32_t *d){
    unsigned r=(unsigned)(n%5);
    if(r==0){uint32_t k=0;do{n/=5;k++;}while(n%5==0);*y=n;*d=k;return true;}
    if(n>(U128_MAXV-2)/6)return false;
    u128 x=n*6;
    if(r==1)x-=1; else if(r==2)x-=2; else if(r==3)x+=2; else x+=1;
    uint32_t k=1;x/=5;
    while(x%5==0){x/=5;k++;}
    *y=x;*d=k;return true;
}

static inline uint8_t direct_outcome64(uint64_t x){
    if(x==1)return O_ONE;if(x==2)return O_TWO;if(known(x))return O_C9;return O_UNKNOWN;
}

// Evaluate with cache. Brent detector only advances one extra state per main step.
// Crucially: known attractors are checked before declaring a repeated state a new cycle.
static Eval eval_start(uint64_t start){
    Eval e={0};e.start=start;e.peak=start;
    uint64_t x=start;
    uint64_t power=1,lam=0,tortoise=start;
    bool brent=true;

    // Store the traversed prefix only while it is reasonably small; this lets us back-fill cache.
    enum { PATHCAP=4096 };
    uint64_t path_state[PATHCAP];
    uint32_t path_div[PATHCAP];
    uint32_t plen=0;

    for(uint64_t k=0;k<HARD_STEP_LIMIT;k++){
        uint8_t o=direct_outcome64(x);
        if(o){
            e.outcome=o;e.steps=k;
            goto done64;
        }

        if(x<cache_limit){
            CacheEntry *ce=&cache[x];
            if(atomic_load_explicit(&ce->ready,memory_order_acquire)){
                e.outcome=ce->outcome;
                e.steps=k+(uint64_t)ce->steps;
                e.div5+=(uint64_t)ce->div5;
                u128 cp=ce->peak;
                if(cp>e.peak){e.peak=cp;e.peak_step=k+(uint64_t)ce->peak_step;}
                goto done64;
            }
        }

        uint64_t nx;uint32_t d;
        if(!step64(x,&nx,&d)){
            // Exact 128-bit continuation. No cache/cycle shortcut from here.
            u128 z=x;
            for(uint64_t j=k;j<HARD_STEP_LIMIT;j++){
                if(z==1){e.outcome=O_ONE;e.steps=j;return e;}
                if(z==2){e.outcome=O_TWO;e.steps=j;return e;}
                if(z<=UINT64_MAX && known((uint64_t)z)){e.outcome=O_C9;e.steps=j;return e;}
                u128 nz;uint32_t dd;
                if(!step128(z,&nz,&dd)){e.outcome=O_OVERFLOW;e.steps=j;return e;}
                e.div5+=dd;z=nz;
                if(z>e.peak){e.peak=z;e.peak_step=j+1;}
            }
            e.outcome=O_LIMIT;e.steps=HARD_STEP_LIMIT;return e;
        }

        if(plen<PATHCAP){path_state[plen]=x;path_div[plen]=d;plen++;}
        e.div5+=d;x=nx;
        if((u128)x>e.peak){e.peak=x;e.peak_step=k+1;}

        if(brent){
            // x is the next hare state; test known attractors first on next loop.
            lam++;
            if(x==tortoise){
                uint8_t ko=direct_outcome64(x);
                if(ko){ e.outcome=ko;e.steps=k+1;goto done64; }

                // New cycle. Compute length/minimum from meeting state.
                uint64_t y=x,mn=x,L=0;uint32_t dd;
                do{
                    uint64_t ny;
                    if(!step64(y,&ny,&dd)){brent=false;break;}
                    y=ny;L++;if(y<mn)mn=y;
                }while(y!=x && L<HARD_STEP_LIMIT);
                if(brent){
                    // Find mu from start.
                    uint64_t a=start,b=start;
                    for(uint64_t i=0;i<L;i++){uint64_t nb;if(!step64(b,&nb,&dd)){brent=false;break;}b=nb;}
                    uint64_t mu=0;
                    while(brent && a!=b && mu<HARD_STEP_LIMIT){
                        uint64_t na,nb;if(!step64(a,&na,&dd)||!step64(b,&nb,&dd)){brent=false;break;}
                        a=na;b=nb;mu++;
                    }
                    if(brent){
                        // If cycle is actually one of known attractors, classify correctly.
                        uint8_t co=direct_outcome64(a);
                        if(co){e.outcome=co;e.steps=mu;goto done64;}
                        e.outcome=O_NEWCYCLE;e.steps=mu;e.cycle_min=mn;e.cycle_len=L;return e;
                    }
                }
            }
            if(lam==power){tortoise=x;power<<=1;lam=0;if(power==0)brent=false;}
        }
    }
    e.outcome=O_LIMIT;e.steps=HARD_STEP_LIMIT;return e;

done64:
    // Back-fill cache only when the complete suffix peak fits 64-bit and path prefix is complete.
    // We reconstruct suffix metrics backwards from the terminal/cached result.
    if(e.peak<=UINT64_MAX && plen<PATHCAP && e.outcome>=O_ONE && e.outcome<=O_C9){
        uint64_t suffix_steps=0,suffix_div=0,suffix_peak=x;
        uint32_t suffix_peak_step=0;

        // If x itself has a cache entry, seed suffix from it.
        if(x<cache_limit){
            CacheEntry *ce=&cache[x];
            if(atomic_load_explicit(&ce->ready,memory_order_acquire)){
                suffix_steps=ce->steps;suffix_div=ce->div5;suffix_peak=ce->peak;suffix_peak_step=ce->peak_step;
            }
        }
        for(int i=(int)plen-1;i>=0;i--){
            uint64_t st=path_state[i],ny;uint32_t dd;
            if(!step64(st,&ny,&dd))break;
            uint64_t old_steps=suffix_steps;
            suffix_steps++;
            suffix_div+=path_div[i];
            uint64_t candidate_peak=suffix_peak;
            uint32_t candidate_step=(uint32_t)(1+suffix_peak_step);
            if(st>=candidate_peak){candidate_peak=st;candidate_step=0;}
            suffix_peak=candidate_peak;suffix_peak_step=candidate_step;
            if(st<cache_limit && suffix_steps<=UINT32_MAX && suffix_div<=UINT32_MAX){
                CacheEntry *ce=&cache[st];
                if(!atomic_load_explicit(&ce->ready,memory_order_relaxed)){
                    ce->outcome=e.outcome;ce->steps=(uint32_t)suffix_steps;ce->div5=(uint32_t)suffix_div;
                    ce->peak=suffix_peak;ce->peak_step=suffix_peak_step;
                    atomic_store_explicit(&ce->ready,1,memory_order_release);
                }
            }
            (void)old_steps;
        }
    }
    return e;
}

static void add(Stats*s,const Eval*e){
    s->starts++;if(e->outcome==O_ONE)s->one++;else if(e->outcome==O_TWO)s->two++;
    else if(e->outcome==O_C9)s->c9++;else if(e->outcome==O_NEWCYCLE)s->newcyc++;
    else if(e->outcome==O_OVERFLOW)s->overflow++;else s->limit++;
    s->sum_steps+=e->steps;s->sum_div5+=e->div5;
    if(e->steps>s->max_steps){s->max_steps=e->steps;s->max_steps_n=e->start;s->max_steps_peak=e->peak;}
    if(e->peak>s->max_peak){s->max_peak=e->peak;s->max_peak_n=e->start;s->max_peak_step=e->peak_step;s->max_peak_steps=e->steps;}
    if(e->div5>s->max_div5){s->max_div5=e->div5;s->max_div5_n=e->start;}
}
static void merge(Stats*a,const Stats*b){
#define A(x) a->x+=b->x
    A(starts);A(one);A(two);A(c9);A(newcyc);A(overflow);A(limit);A(sum_steps);A(sum_div5);
#undef A
    if(b->max_steps>a->max_steps){a->max_steps=b->max_steps;a->max_steps_n=b->max_steps_n;a->max_steps_peak=b->max_steps_peak;}
    if(b->max_peak>a->max_peak){a->max_peak=b->max_peak;a->max_peak_n=b->max_peak_n;a->max_peak_step=b->max_peak_step;a->max_peak_steps=b->max_peak_steps;}
    if(b->max_div5>a->max_div5){a->max_div5=b->max_div5;a->max_div5_n=b->max_div5_n;}
}
static void *worker(void *p){
    WArg*w=p;
    for(uint64_t n=w->lo;n<=w->hi&&!stop_requested;n++){
        if(n%5==0)continue;
        Eval e=eval_start(n);add(&w->st,&e);
        if(e.outcome==O_NEWCYCLE){
            char cm[64];s128(e.cycle_min,cm,sizeof cm);
            pthread_mutex_lock(w->io_mu);
            fprintf(w->cycles,"%"PRIu64"\t%s\t%"PRIu64"\t%"PRIu64"\n",n,cm,e.cycle_len,e.steps);
            fflush(w->cycles);
            pthread_mutex_unlock(w->io_mu);
        }
        if(n==UINT64_MAX)break;
    }return NULL;
}
static void printstats(FILE*f,const Stats*s){
    char a[64],b[64];s128(s->max_steps_peak,a,sizeof a);s128(s->max_peak,b,sizeof b);
    fprintf(f,"starts:         %"PRIu64"\n"
              "to 1:           %"PRIu64"\n"
              "to 2:           %"PRIu64"\n"
              "to cycle9:      %"PRIu64"\n"
              "new cycles:     %"PRIu64"\n"
              "overflow128:    %"PRIu64"\n"
              "step-limit:     %"PRIu64"\n"
              "max stopping:   n=%"PRIu64" steps=%"PRIu64" path_peak=%s\n"
              "max peak:       n=%"PRIu64" peak=%s peak_step=%"PRIu64" stopping=%"PRIu64"\n"
              "max /5 count:   n=%"PRIu64" divisions=%"PRIu64"\n",
              s->starts,s->one,s->two,s->c9,s->newcyc,s->overflow,s->limit,
              s->max_steps_n,s->max_steps,a,s->max_peak_n,b,s->max_peak_step,s->max_peak_steps,
              s->max_div5_n,s->max_div5);
}
static bool donechunk(const char*fn,uint64_t c){
    FILE*f=fopen(fn,"r");if(!f)return false;char z[1024];uint64_t q;
    while(fgets(z,sizeof z,f))if(sscanf(z,"%"SCNu64"\t",&q)==1&&q==c){fclose(f);return true;}
    fclose(f);return false;
}

int main(int ac,char**av){
    uint64_t maxn=10000000,chunk=1000000;int nt=4;const char*pre="scan_v2";cache_limit=20000000;
    for(int i=1;i<ac;i++){
        if(!strcmp(av[i],"-m")&&i+1<ac)maxn=strtoull(av[++i],0,10);
        else if(!strcmp(av[i],"-c")&&i+1<ac)chunk=strtoull(av[++i],0,10);
        else if(!strcmp(av[i],"-t")&&i+1<ac)nt=atoi(av[++i]);
        else if(!strcmp(av[i],"-C")&&i+1<ac)cache_limit=strtoull(av[++i],0,10);
        else if(!strcmp(av[i],"-o")&&i+1<ac)pre=av[++i];
        else{fprintf(stderr,"usage: %s -m MAX -t THREADS -c CHUNK -C CACHE_LIMIT -o PREFIX\n",av[0]);return 2;}
    }
    if(cache_limit){
        if(cache_limit>SIZE_MAX/sizeof(CacheEntry)){fprintf(stderr,"cache too large\n");return 2;}
        cache=calloc((size_t)cache_limit,sizeof(CacheEntry));
        if(!cache){fprintf(stderr,"cache allocation failed; try smaller -C\n");return 1;}
    }
    signal(SIGINT,sig_handler);signal(SIGTERM,sig_handler);

    char cf[PATH_MAX],rf[PATH_MAX],yf[PATH_MAX],sf[PATH_MAX];
    snprintf(cf,sizeof cf,"%s.chunks.tsv",pre);snprintf(rf,sizeof rf,"%s.records.tsv",pre);
    snprintf(yf,sizeof yf,"%s.cycles.tsv",pre);snprintf(sf,sizeof sf,"%s.summary.txt",pre);
    FILE*fc=fopen(cf,"a+"),*fr=fopen(rf,"a+"),*fy=fopen(yf,"a+");
    if(!fc||!fr||!fy){perror("output");return 1;}
    setvbuf(fc,NULL,_IOLBF,0);setvbuf(fr,NULL,_IOLBF,0);setvbuf(fy,NULL,_IOLBF,0);
    fseek(fc,0,SEEK_END);if(ftell(fc)==0)fprintf(fc,"chunk\tlo\thi\tstarts\tseconds\trate\tone\ttwo\tcycle9\tnewcycles\toverflow\tlimit\tmaxsteps\tmaxsteps_n\tmaxpeak\tmaxpeak_n\n");
    fseek(fr,0,SEEK_END);if(ftell(fr)==0)fprintf(fr,"chunk\ttype\tn\tvalue\taux\n");
    fseek(fy,0,SEEK_END);if(ftell(fy)==0)fprintf(fy,"start\tcycle_min\tcycle_len\tstopping\n");

    uint64_t nc=(maxn+chunk-1)/chunk;Stats grand={0};double all0=nowsec();pthread_mutex_t mu=PTHREAD_MUTEX_INITIALIZER;
    printf("Optimized 6n +/- {1,2} / 5 scanner v2\n");
    printf("max n:          %"PRIu64"\nthreads:        %d\nraw chunk:      %"PRIu64"\ncache states:   %"PRIu64"\ncache memory:   %.1f MiB\nchunks:         %"PRIu64"\n",
           maxn,nt,chunk,cache_limit,(double)cache_limit*sizeof(CacheEntry)/1048576.0,nc);

    for(uint64_t ci=0;ci<nc&&!stop_requested;ci++){
        if(donechunk(cf,ci)){printf("chunk %"PRIu64"/%"PRIu64" already complete; skipped\n",ci+1,nc);continue;}
        uint64_t lo=ci*chunk+1,hi=(ci+1)*chunk;if(hi>maxn||hi<lo)hi=maxn,chunk=hi-lo+1;
        uint64_t span=hi-lo+1;
        pthread_t *th=calloc(nt,sizeof *th);WArg*wa=calloc(nt,sizeof*wa);double t0=nowsec();
        for(int k=0;k<nt;k++){
            wa[k].lo=lo+span*(uint64_t)k/(uint64_t)nt;
            wa[k].hi=lo+span*(uint64_t)(k+1)/(uint64_t)nt-1;
            wa[k].cycles=fy;wa[k].io_mu=&mu;pthread_create(&th[k],0,worker,&wa[k]);
        }
        Stats cs={0};for(int k=0;k<nt;k++){pthread_join(th[k],0);merge(&cs,&wa[k].st);}
        double sec=nowsec()-t0,rate=sec?cs.starts/sec:0;merge(&grand,&cs);
        char mp[64];s128(cs.max_peak,mp,sizeof mp);
        printf("\nchunk:          %"PRIu64" / %"PRIu64"   (%.2f%% complete)\n",ci+1,nc,100.0*(ci+1)/nc);
        printf("n-range:        [%"PRIu64", %"PRIu64"]\nchunk starts:   %"PRIu64"\nchunk seconds:  %.3f\nchunk rate:     %.0f starts/sec\n",
               lo,hi,cs.starts,sec,rate);
        printf("outcomes:       1=%"PRIu64"  2=%"PRIu64"  cycle9=%"PRIu64"  new=%"PRIu64"  ovf=%"PRIu64"  limit=%"PRIu64"\n",
               cs.one,cs.two,cs.c9,cs.newcyc,cs.overflow,cs.limit);
        printf("chunk max stop: n=%"PRIu64" steps=%"PRIu64"\nchunk max peak: n=%"PRIu64" peak=%s step=%"PRIu64"\n",
               cs.max_steps_n,cs.max_steps,cs.max_peak_n,mp,cs.max_peak_step);
        printf("session totals:\n");printstats(stdout,&grand);fflush(stdout);

        fprintf(fc,"%"PRIu64"\t%"PRIu64"\t%"PRIu64"\t%"PRIu64"\t%.6f\t%.3f\t%"PRIu64"\t%"PRIu64"\t%"PRIu64"\t%"PRIu64"\t%"PRIu64"\t%"PRIu64"\t%"PRIu64"\t%"PRIu64"\t%s\t%"PRIu64"\n",
                ci,lo,hi,cs.starts,sec,rate,cs.one,cs.two,cs.c9,cs.newcyc,cs.overflow,cs.limit,cs.max_steps,cs.max_steps_n,mp,cs.max_peak_n);
        fprintf(fr,"%"PRIu64"\tmax_stopping\t%"PRIu64"\t%"PRIu64"\t-\n",ci,cs.max_steps_n,cs.max_steps);
        fprintf(fr,"%"PRIu64"\tmax_peak\t%"PRIu64"\t%s\t%"PRIu64"\n",ci,cs.max_peak_n,mp,cs.max_peak_step);
        fflush(fc);fflush(fr);free(th);free(wa);
    }
    FILE*fs=fopen(sf,"w");if(fs){fprintf(fs,"elapsed_session=%.3f\n",nowsec()-all0);printstats(fs,&grand);fclose(fs);}
    if(stop_requested)fprintf(stderr,"\nInterrupted. Completed chunks are saved; rerun same command/prefix to resume.\n");
    fclose(fc);fclose(fr);fclose(fy);free(cache);return stop_requested?130:0;
}
