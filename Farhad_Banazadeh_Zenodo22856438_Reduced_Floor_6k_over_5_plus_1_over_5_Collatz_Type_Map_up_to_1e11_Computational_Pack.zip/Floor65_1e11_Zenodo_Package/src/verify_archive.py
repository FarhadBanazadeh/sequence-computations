#!/usr/bin/env python3
import csv, hashlib, json, os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results'
CHUNKS = ROOT / 'certificate_chunks'

summary = json.loads((RESULTS / 'summary.json').read_text())
manifest_rows = list(csv.DictReader((RESULTS / 'manifest.csv').open()))

if len(manifest_rows) != summary['chunks']:
    raise SystemExit(f"manifest rows {len(manifest_rows)} != summary chunks {summary['chunks']}")

expected_start = summary['start']
solved = 0
totals = {k:0 for k in ['total_macro_steps','total_elementary_steps','total_divisions_by_5','total_brake_events']}
max_tau = (-1, None)
max_elem = (-1, None)
max_v5 = (-1, None)
max_peak = (-1, None)

for i,row in enumerate(manifest_rows,1):
    p = CHUNKS / row['file']
    if not p.exists():
        raise SystemExit(f"missing chunk {p.name}")
    raw = p.read_bytes()
    h = hashlib.sha256(raw).hexdigest()
    if h != row['json_sha256']:
        raise SystemExit(f"JSON SHA-256 mismatch: {p.name}")
    d = json.loads(raw)
    if d['record_digest_sha256'] != row['result_digest_sha256']:
        raise SystemExit(f"result digest mismatch in manifest: {p.name}")
    if int(d['start']) != expected_start:
        raise SystemExit(f"coverage mismatch: expected {expected_start}, got {d['start']}")
    if int(d['count']) != int(d['solved']):
        raise SystemExit(f"unsolved chunk: {p.name}")
    expected_start = int(d['end']) + 1
    solved += int(d['solved'])
    for k in totals:
        totals[k] += int(d[k])
    if int(d['max_tau']) > max_tau[0]: max_tau=(int(d['max_tau']),int(d['argmax_tau']))
    if int(d['max_elementary_steps']) > max_elem[0]: max_elem=(int(d['max_elementary_steps']),int(d['argmax_elementary_steps']))
    if int(d['max_v5']) > max_v5[0]: max_v5=(int(d['max_v5']),int(d['argmax_v5']))
    pk=int(d['max_peak'])
    if pk > max_peak[0]: max_peak=(pk,int(d['argmax_peak']))

checks = [
    (solved == summary['N'], 'N'),
    (expected_start - 1 == summary['end'], 'coverage end'),
    (all(totals[k] == summary[k] for k in totals), 'aggregate totals'),
    (max_tau == (summary['max_tau'], summary['argmax_tau_first']), 'max tau'),
    (max_elem == (summary['max_elementary_steps'], summary['argmax_elementary_first']), 'max elementary'),
    (max_v5 == (summary['max_v5'], summary['argmax_v5_first']), 'max v5'),
    (max_peak == (int(summary['max_peak']), summary['argmax_peak_first']), 'max peak'),
]
for ok,label in checks:
    if not ok: raise SystemExit(f"summary check failed: {label}")

print(f"OK: {len(manifest_rows)} chunk JSON files verified")
print(f"OK: continuous coverage [{summary['start']},{summary['end']}] with N={summary['N']}")
print("OK: aggregate totals and principal maxima agree with summary.json")
print("Note: canonical per-input result digests are verified against the manifest; recomputing them requires rerunning firstlower_certificate.cpp.")
