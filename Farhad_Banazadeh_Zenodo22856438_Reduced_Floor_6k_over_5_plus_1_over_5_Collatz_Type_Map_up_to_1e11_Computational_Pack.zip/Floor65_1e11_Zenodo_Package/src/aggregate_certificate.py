#!/usr/bin/env python3
import argparse, csv, glob, hashlib, json, os
from fractions import Fraction

def add_hist(dst, src):
    if len(dst) < len(src): dst.extend([0]*(len(src)-len(dst)))
    for i,v in enumerate(src): dst[i] += int(v)

def update_records(out, local, key='value', ratio=False):
    for r in local:
        n=int(r['n'])
        if ratio:
            val=Fraction(int(r['peak']), n)
            if not out or val > out[-1][0]: out.append((val, n, int(r['peak'])))
        else:
            val=int(r[key])
            if not out or val > out[-1][0]: out.append((val,n))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('dir'); ap.add_argument('--out',default='zenodo_certificate'); args=ap.parse_args()
    files=glob.glob(os.path.join(args.dir,'cert_*.json'))
    chunks=[]
    for p in files:
        with open(p) as f: d=json.load(f)
        chunks.append((int(d['start']),p,d))
    chunks.sort()
    if not chunks: raise SystemExit('no cert_*.json files found')
    expected=chunks[0][0]; total=0; totals={k:0 for k in ['total_macro_steps','total_elementary_steps','total_divisions_by_5','total_brake_events']}
    hists={k:[] for k in ['tau_hist','elementary_hist','max_v5_per_input_hist','v5_per_growth_step_hist']}
    rt=[]; re=[]; rv=[]; rp=[]; rr=[]; manifest=[]
    for start,p,d in chunks:
        count=int(d['count']); end=int(d['end'])
        if start != expected: raise SystemExit(f'coverage gap/overlap: expected {expected}, got {start}')
        if int(d['solved']) != count: raise SystemExit(f'unsolved chunk: {p}')
        expected=end+1; total+=count
        for k in totals: totals[k]+=int(d[k])
        for k in hists: add_hist(hists[k],d[k])
        update_records(rt,d['local_tau_records']); update_records(re,d['local_elementary_records']); update_records(rv,d['local_max_v5_records']); update_records(rp,d['local_peak_records']); update_records(rr,d['local_peak_ratio_records'],ratio=True)
        raw=open(p,'rb').read(); manifest.append({'file':os.path.basename(p),'start':start,'count':count,'result_digest_sha256':d['record_digest_sha256'],'json_sha256':hashlib.sha256(raw).hexdigest()})
    os.makedirs(args.out,exist_ok=True)
    summary={
      'format':'FL65-ZENODO-CERTIFICATE-v1','start':chunks[0][0],'end':expected-1,'N':total,'chunks':len(chunks),**totals,
      'max_tau':rt[-1][0],'argmax_tau_first':rt[-1][1],
      'max_elementary_steps':re[-1][0],'argmax_elementary_first':re[-1][1],
      'max_v5':rv[-1][0] if rv else 0,'argmax_v5_first':rv[-1][1] if rv else chunks[0][0],
      'max_peak':str(rp[-1][0]),'argmax_peak_first':rp[-1][1],
      'max_peak_ratio_peak':str(rr[-1][2]),'max_peak_ratio_n':rr[-1][1],
      'avg_tau':totals['total_macro_steps']/total,'avg_elementary':totals['total_elementary_steps']/total,
      'brake_event_fraction':totals['total_brake_events']/totals['total_macro_steps'],
      'divisions_per_growth':totals['total_divisions_by_5']/totals['total_macro_steps']
    }
    with open(os.path.join(args.out,'summary.json'),'w') as f: json.dump(summary,f,indent=2)
    for name,h in hists.items():
        with open(os.path.join(args.out,name+'.csv'),'w',newline='') as f:
            w=csv.writer(f); w.writerow(['value','count']); w.writerows(enumerate(h))
    def wr(name, rows, header):
        with open(os.path.join(args.out,name),'w',newline='') as f: w=csv.writer(f); w.writerow(header); w.writerows(rows)
    wr('tau_records.csv',[(n,v) for v,n in rt],['n','tau'])
    wr('elementary_records.csv',[(n,v) for v,n in re],['n','elementary_steps'])
    wr('max_v5_records.csv',[(n,v) for v,n in rv],['n','max_v5'])
    wr('peak_records.csv',[(n,str(v)) for v,n in rp],['n','peak'])
    wr('peak_ratio_records.csv',[(n,str(p),f'{float(fr):.17g}') for fr,n,p in rr],['n','peak','peak_over_n_approx'])
    with open(os.path.join(args.out,'manifest.csv'),'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['file','start','count','result_digest_sha256','json_sha256']); w.writeheader(); w.writerows(manifest)
    print(json.dumps(summary,indent=2))
    print('wrote',args.out)
if __name__=='__main__': main()
