#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <sys/stat.h>
#include <sys/types.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

using u128 = unsigned __int128;

// ---------- tiny SHA-256 (self-contained; no OpenSSL dependency) ----------
class SHA256 {
    uint32_t h_[8];
    uint8_t buf_[64];
    uint64_t bitlen_;
    size_t buflen_;
    static inline uint32_t rotr(uint32_t x, uint32_t n) { return (x >> n) | (x << (32 - n)); }
    static inline uint32_t ch(uint32_t x,uint32_t y,uint32_t z){ return (x&y) ^ (~x&z); }
    static inline uint32_t maj(uint32_t x,uint32_t y,uint32_t z){ return (x&y) ^ (x&z) ^ (y&z); }
    static inline uint32_t e0(uint32_t x){ return rotr(x,2)^rotr(x,13)^rotr(x,22); }
    static inline uint32_t e1(uint32_t x){ return rotr(x,6)^rotr(x,11)^rotr(x,25); }
    static inline uint32_t s0(uint32_t x){ return rotr(x,7)^rotr(x,18)^(x>>3); }
    static inline uint32_t s1(uint32_t x){ return rotr(x,17)^rotr(x,19)^(x>>10); }
    void transform(const uint8_t block[64]) {
        static const uint32_t K[64] = {
          0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
          0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
          0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
          0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
          0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
          0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
          0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
          0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
        uint32_t w[64];
        for(int i=0;i<16;++i) w[i]=(uint32_t(block[4*i])<<24)|(uint32_t(block[4*i+1])<<16)|(uint32_t(block[4*i+2])<<8)|uint32_t(block[4*i+3]);
        for(int i=16;i<64;++i) w[i]=s1(w[i-2])+w[i-7]+s0(w[i-15])+w[i-16];
        uint32_t a=h_[0],b=h_[1],c=h_[2],d=h_[3],e=h_[4],f=h_[5],g=h_[6],hh=h_[7];
        for(int i=0;i<64;++i){ uint32_t t1=hh+e1(e)+ch(e,f,g)+K[i]+w[i]; uint32_t t2=e0(a)+maj(a,b,c); hh=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2; }
        h_[0]+=a;h_[1]+=b;h_[2]+=c;h_[3]+=d;h_[4]+=e;h_[5]+=f;h_[6]+=g;h_[7]+=hh;
    }
public:
    SHA256(){ reset(); }
    void reset(){ h_[0]=0x6a09e667;h_[1]=0xbb67ae85;h_[2]=0x3c6ef372;h_[3]=0xa54ff53a;h_[4]=0x510e527f;h_[5]=0x9b05688c;h_[6]=0x1f83d9ab;h_[7]=0x5be0cd19;bitlen_=0;buflen_=0; }
    void update(const void* data_, size_t len){ const uint8_t* data=(const uint8_t*)data_; for(size_t i=0;i<len;++i){ buf_[buflen_++]=data[i]; if(buflen_==64){ transform(buf_); bitlen_+=512; buflen_=0; } } }
    std::string final_hex(){
        uint64_t total_bits=bitlen_+buflen_*8; buf_[buflen_++]=0x80;
        if(buflen_>56){ while(buflen_<64) buf_[buflen_++]=0; transform(buf_); buflen_=0; }
        while(buflen_<56) buf_[buflen_++]=0;
        for(int i=7;i>=0;--i) buf_[buflen_++]=(uint8_t)(total_bits>>(8*i));
        transform(buf_);
        std::ostringstream os; os<<std::hex<<std::setfill('0');
        for(int i=0;i<8;++i) os<<std::setw(8)<<h_[i]; return os.str();
    }
};

static void hash_u32le(SHA256& s, uint32_t x){ uint8_t b[4]; for(int i=0;i<4;++i)b[i]=(uint8_t)(x>>(8*i)); s.update(b,4); }
static void hash_u64le(SHA256& s, uint64_t x){ uint8_t b[8]; for(int i=0;i<8;++i)b[i]=(uint8_t)(x>>(8*i)); s.update(b,8); }
static void hash_u128le(SHA256& s, u128 x){ hash_u64le(s,(uint64_t)x); hash_u64le(s,(uint64_t)(x>>64)); }

static std::string u128_to_string(u128 x){ if(!x)return "0"; std::string s; while(x){ s.push_back(char('0'+x%10)); x/=10; } std::reverse(s.begin(),s.end()); return s; }
static std::string join_path(const std::string& d,const std::string& n){ if(d.empty()||d==".")return n; return d.back()=='/'?d+n:d+"/"+n; }
static bool path_exists(const std::string& p){ struct stat st; return ::stat(p.c_str(),&st)==0; }
static void create_directories_compat(const std::string& path){
    if(path.empty()||path==".")return; std::string cur; if(path[0]=='/')cur="/"; size_t i=(path[0]=='/')?1:0;
    while(i<=path.size()){ size_t j=path.find('/',i); std::string part=path.substr(i,j==std::string::npos?std::string::npos:j-i); if(!part.empty()){ if(!cur.empty()&&cur.back()!='/')cur+='/'; cur+=part; if(::mkdir(cur.c_str(),0755)!=0&&errno!=EEXIST)throw std::runtime_error("cannot create directory: "+cur);} if(j==std::string::npos)break; i=j+1; }
}
static void rename_compat(const std::string& a,const std::string& b){ if(std::rename(a.c_str(),b.c_str())!=0)throw std::runtime_error("rename failed: "+a+" -> "+b); }

template<class T> static void hist_inc(std::vector<uint64_t>& h,T idx){ size_t i=(size_t)idx; if(i>=h.size()) h.resize(i+1,0); ++h[i]; }

struct Config{ uint64_t begin=1,end=1000000,chunk=25000000; unsigned threads=4; std::string outdir="certificate_chunks"; bool overwrite=false; };
struct Result{ uint32_t macro=0,elementary=0,max_v5=0; uint64_t lower=0,divisions=0,brake_events=0; u128 peak=0; };
struct RecU32{ uint64_t n; uint32_t value; };
struct RecU128{ uint64_t n; u128 value; };
struct RecRatio{ uint64_t n; u128 peak; };

struct ChunkStats{
    uint64_t start=0,count=0,solved=0;
    uint64_t total_macro=0,total_elementary=0,total_divisions=0,total_brake_events=0;
    uint32_t max_tau=0,max_elementary=0,max_v5=0; uint64_t argmax_tau=0,argmax_elementary=0,argmax_v5=0;
    u128 max_peak=0; uint64_t argmax_peak=0; u128 max_ratio_peak=0; uint64_t max_ratio_n=1;
    std::vector<uint64_t> tau_hist,elementary_hist,maxv5_hist,v5_event_hist;
    std::vector<RecU32> tau_records,elementary_records,maxv5_records;
    std::vector<RecU128> peak_records; std::vector<RecRatio> ratio_records;
};

static int compare_ratio(u128 a,uint64_t b,u128 c,uint64_t d){
    u128 qa=a/b,qc=c/d; if(qa<qc)return -1; if(qa>qc)return 1;
    uint64_t ra=(uint64_t)(a%b), rc=(uint64_t)(c%d);
    u128 left=(u128)ra*d, right=(u128)rc*b; return left<right?-1:left>right?1:0;
}

static inline Result first_lower(uint64_t n, std::vector<uint64_t>& v5_event_hist){
    if(n<=1) return {0,0,0,1,0,0,1};
    const u128 start=(u128)n; u128 x=start,peak=start; uint32_t macro=0,elementary=0,maxv5=0; uint64_t divisions=0,brakes=0;
    const u128 UMAX=~((u128)0);
    while(true){
        if(x>(UMAX-5)/6){ std::cerr<<"FATAL: 128-bit overflow guard n="<<n<<" x="<<u128_to_string(x)<<"\n"; std::abort(); }
        u128 y=(6*x)/5+1; ++macro; ++elementary; uint32_t v5=0;
        while(y%5==0){ y/=5; ++v5; ++divisions; ++elementary; }
        hist_inc(v5_event_hist,v5);
        if(v5){ ++brakes; if(v5>maxv5)maxv5=v5; }
        x=y; if(x>peak)peak=x;
        if(x<start){ if(x>std::numeric_limits<uint64_t>::max()){ std::cerr<<"FATAL lower64 n="<<n<<"\n";std::abort(); } return {macro,elementary,maxv5,(uint64_t)x,divisions,brakes,peak}; }
    }
}

static std::string stem_for(uint64_t start,uint64_t count){ std::ostringstream os; os<<"cert_"<<std::setw(12)<<std::setfill('0')<<start<<"_"<<std::setw(9)<<count; return os.str(); }

static void json_hist(std::ofstream& f,const char* name,const std::vector<uint64_t>& h,bool comma=true){
    f<<"  \""<<name<<"\": ["; for(size_t i=0;i<h.size();++i){ if(i)f<<","; f<<h[i]; } f<<"]"<<(comma?",":"")<<"\n";
}
static void json_rec_u32(std::ofstream& f,const char* name,const std::vector<RecU32>& v){ f<<"  \""<<name<<"\": ["; for(size_t i=0;i<v.size();++i){ if(i)f<<","; f<<"{\"n\":"<<v[i].n<<",\"value\":"<<v[i].value<<"}"; } f<<"],\n"; }
static void json_rec_u128(std::ofstream& f,const char* name,const std::vector<RecU128>& v){ f<<"  \""<<name<<"\": ["; for(size_t i=0;i<v.size();++i){ if(i)f<<","; f<<"{\"n\":"<<v[i].n<<",\"value\":\""<<u128_to_string(v[i].value)<<"\"}"; } f<<"],\n"; }
static void json_rec_ratio(std::ofstream& f,const char* name,const std::vector<RecRatio>& v){ f<<"  \""<<name<<"\": ["; for(size_t i=0;i<v.size();++i){ if(i)f<<","; f<<"{\"n\":"<<v[i].n<<",\"peak\":\""<<u128_to_string(v[i].peak)<<"\"}"; } f<<"]\n"; }

static void write_json(const std::string& path,const ChunkStats& s,double seconds,const std::string& digest){
    std::ofstream f(path,std::ios::binary);
    f<<"{\n"
     <<"  \"format\": \"FL65-CERT-v1\",\n"
     <<"  \"mapping\": \"y=floor(6*x/5)+1; then divide y by 5 repeatedly while divisible\",\n"
     <<"  \"first_lower_tau\": \"min j>=1 with T^j(n)<n; n=1 encoded tau=0\",\n"
     <<"  \"start\": "<<s.start<<",\n  \"count\": "<<s.count<<",\n  \"end\": "<<(s.start+s.count-1)<<",\n"
     <<"  \"solved\": "<<s.solved<<",\n"
     <<"  \"record_digest_sha256\": \""<<digest<<"\",\n"
     <<"  \"digest_canonical_record\": \"LE: n:u64,tau:u32,elementary:u32,lower:u64,max_v5:u32,divisions:u64,brake_events:u64,peak:u128; prefixed by ASCII FL65CERTv1 and start:u64,count:u64\",\n"
     <<"  \"max_tau\": "<<s.max_tau<<",\n  \"argmax_tau\": "<<s.argmax_tau<<",\n"
     <<"  \"max_elementary_steps\": "<<s.max_elementary<<",\n  \"argmax_elementary_steps\": "<<s.argmax_elementary<<",\n"
     <<"  \"max_v5\": "<<s.max_v5<<",\n  \"argmax_v5\": "<<s.argmax_v5<<",\n"
     <<"  \"max_peak\": \""<<u128_to_string(s.max_peak)<<"\",\n  \"argmax_peak\": "<<s.argmax_peak<<",\n"
     <<"  \"max_peak_ratio_peak\": \""<<u128_to_string(s.max_ratio_peak)<<"\",\n  \"max_peak_ratio_n\": "<<s.max_ratio_n<<",\n"
     <<"  \"total_macro_steps\": "<<s.total_macro<<",\n  \"total_elementary_steps\": "<<s.total_elementary<<",\n"
     <<"  \"total_divisions_by_5\": "<<s.total_divisions<<",\n  \"total_brake_events\": "<<s.total_brake_events<<",\n"
     <<"  \"seconds\": "<<std::fixed<<std::setprecision(6)<<seconds<<",\n";
    json_hist(f,"tau_hist",s.tau_hist); json_hist(f,"elementary_hist",s.elementary_hist); json_hist(f,"max_v5_per_input_hist",s.maxv5_hist); json_hist(f,"v5_per_growth_step_hist",s.v5_event_hist);
    json_rec_u32(f,"local_tau_records",s.tau_records); json_rec_u32(f,"local_elementary_records",s.elementary_records); json_rec_u32(f,"local_max_v5_records",s.maxv5_records); json_rec_u128(f,"local_peak_records",s.peak_records); json_rec_ratio(f,"local_peak_ratio_records",s.ratio_records);
    f<<"}\n";
}

static void process_chunk(const Config& cfg,uint64_t start,uint64_t count,std::mutex& print_mu){
    const std::string stem=stem_for(start,count), out=join_path(cfg.outdir,stem+".json"), done=join_path(cfg.outdir,stem+".done");
    if(!cfg.overwrite&&path_exists(done)){ std::lock_guard<std::mutex> lk(print_mu); std::cout<<"skip "<<stem<<" (done)\n"; return; }
    ChunkStats st; st.start=start; st.count=count; st.max_ratio_n=start?start:1;
    SHA256 sha; const char magic[]="FL65CERTv1"; sha.update(magic,sizeof(magic)-1); hash_u64le(sha,start); hash_u64le(sha,count);
    auto t0=std::chrono::steady_clock::now();
    for(uint64_t i=0;i<count;++i){
        uint64_t n=start+i; Result r=first_lower(n,st.v5_event_hist); ++st.solved;
        st.total_macro+=r.macro; st.total_elementary+=r.elementary; st.total_divisions+=r.divisions; st.total_brake_events+=r.brake_events;
        hist_inc(st.tau_hist,r.macro); hist_inc(st.elementary_hist,r.elementary); hist_inc(st.maxv5_hist,r.max_v5);
        if(r.macro>st.max_tau){ st.max_tau=r.macro; st.argmax_tau=n; st.tau_records.push_back({n,r.macro}); }
        if(r.elementary>st.max_elementary){ st.max_elementary=r.elementary; st.argmax_elementary=n; st.elementary_records.push_back({n,r.elementary}); }
        if(r.max_v5>st.max_v5){ st.max_v5=r.max_v5; st.argmax_v5=n; st.maxv5_records.push_back({n,r.max_v5}); }
        if(r.peak>st.max_peak){ st.max_peak=r.peak; st.argmax_peak=n; st.peak_records.push_back({n,r.peak}); }
        if(st.max_ratio_peak==0 || compare_ratio(r.peak,n,st.max_ratio_peak,st.max_ratio_n)>0){ st.max_ratio_peak=r.peak; st.max_ratio_n=n; st.ratio_records.push_back({n,r.peak}); }
        hash_u64le(sha,n); hash_u32le(sha,r.macro); hash_u32le(sha,r.elementary); hash_u64le(sha,r.lower); hash_u32le(sha,r.max_v5); hash_u64le(sha,r.divisions); hash_u64le(sha,r.brake_events); hash_u128le(sha,r.peak);
    }
    double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count(); std::string digest=sha.final_hex();
    std::string tmp=out+".tmp"; write_json(tmp,st,seconds,digest); rename_compat(tmp,out); {std::ofstream(done)<<digest<<"\n";}
    std::lock_guard<std::mutex> lk(print_mu);
    std::cout<<stem<<" max_tau="<<st.max_tau<<" @"<<st.argmax_tau<<" max_elem="<<st.max_elementary<<" @"<<st.argmax_elementary<<" max_v5="<<st.max_v5<<" @"<<st.argmax_v5<<" max_peak="<<u128_to_string(st.max_peak)<<" @"<<st.argmax_peak<<" sha256="<<digest.substr(0,16)<<"... "<<std::fixed<<std::setprecision(2)<<(count/std::max(seconds,1e-9))/1e6<<" M n/s\n";
}

static uint64_t parse_u64(const char* s){ char* e=nullptr; unsigned long long v=std::strtoull(s,&e,10); if(!e||*e)throw std::runtime_error(std::string("bad integer: ")+s); return (uint64_t)v; }
static void usage(const char* a){ std::cerr<<"Usage: "<<a<<" [--begin N] [--end N] [--chunk N] [--threads N] [--out DIR] [--overwrite]\n"; }
int main(int argc,char** argv){
    Config cfg; try{ for(int i=1;i<argc;++i){ std::string a=argv[i]; auto need=[&](const char* n){ if(i+1>=argc)throw std::runtime_error(std::string("missing value for ")+n); return argv[++i];}; if(a=="--begin")cfg.begin=parse_u64(need("--begin")); else if(a=="--end")cfg.end=parse_u64(need("--end")); else if(a=="--chunk")cfg.chunk=parse_u64(need("--chunk")); else if(a=="--threads")cfg.threads=(unsigned)parse_u64(need("--threads")); else if(a=="--out")cfg.outdir=need("--out"); else if(a=="--overwrite")cfg.overwrite=true; else if(a=="-h"||a=="--help"){usage(argv[0]);return 0;} else throw std::runtime_error("unknown option: "+a); }
        if(cfg.begin<1||cfg.end<cfg.begin||cfg.chunk==0||cfg.threads==0)throw std::runtime_error("invalid arguments");
    }catch(const std::exception& e){ std::cerr<<"error: "<<e.what()<<"\n"; usage(argv[0]); return 2; }
    create_directories_compat(cfg.outdir); uint64_t nchunks=(cfg.end-cfg.begin+cfg.chunk)/cfg.chunk; std::atomic<uint64_t> next{0}; std::mutex print_mu;
    std::cout<<"CERTIFICATE MODE range=["<<cfg.begin<<","<<cfg.end<<"] chunks="<<nchunks<<" chunk_size="<<cfg.chunk<<" threads="<<cfg.threads<<" raw_tau_files=no\n";
    auto worker=[&](){ while(true){ uint64_t ci=next.fetch_add(1); if(ci>=nchunks)break; uint64_t start=cfg.begin+ci*cfg.chunk; uint64_t rem=cfg.end-start+1; process_chunk(cfg,start,std::min(cfg.chunk,rem),print_mu); } };
    std::vector<std::thread> pool; for(unsigned t=0;t<cfg.threads;++t)pool.emplace_back(worker); for(auto& t:pool)t.join(); return 0;
}
