# Reduced (floor(6k/5)+1)/5 Collatz-Type Domain: compact reproducibility archive through 10^11

Author: Farhad Banazadeh  
Date: 20 September 2026

This archive accompanies the article **“The Reduced (floor(6k/5)+1)/5 Collatz-Type Domain with One Observed Attractor up to 10^11: Complete 5-Adic Reduction, Residue Algebra, Critical Multiplicative Statistics, Cycle Constraints, and Exhaustive First-Descent Verification.”**

## Map

For each positive integer n,

    G(n) = floor(6*n/5) + 1
    T(n) = G(n) / 5^v5(G(n))

where every factor of 5 is removed after the growth step.

## Completed finite computation

The production scan covered every integer from 1 through 100,000,000,000 in 4,000 contiguous chunks of 25,000,000 starts.

Principal final results:

- maximum first-descent stopping time: 422 at n = 55,335,461,598
- maximum elementary count before first descent: 470 at the same start
- maximum explicit 5-adic valuation: 16 at n = 88,717,666,380
- largest pre-descent state: 8,669,800,813,122,806,007,604 from n = 37,266,730,278
- mean first-descent time: 6.18073627485
- pooled brake-event fraction: 0.1999996001463434
- pooled explicit divisions per growth step: 0.24999981555069667

Every n >= 2 in the verified range reached a value smaller than itself. By strong induction, every n <= 10^11 therefore eventually enters the exact cycle 1 -> 2 -> 3 -> 4 -> 1.

## Archive contents

- `article/` — LaTeX source of the paper.
- `src/firstlower_certificate.cpp` — production C++17 scanner using unsigned 128-bit arithmetic and an overflow guard.
- `src/aggregate_certificate.py` — deterministic aggregation of the 4,000 chunk certificates.
- `src/verify_archive.py` — verifies archive integrity, manifest hashes, continuous coverage, aggregate totals and principal maxima.
- `certificate_chunks/` — all 4,000 production `cert_*.json` chunk certificates. Redundant `.done` sentinel files are intentionally omitted.
- `results/` — final `summary.json`, `manifest.csv`, exact histograms, and historical record CSV files.
- `logs/certificate_1e11.log` — production terminal log.
- `SHA256SUMS.txt` — SHA-256 hashes for every archived file except itself.

Local executables, preliminary test runs, macOS metadata, old ZIP files, and redundant sentinel files are not included because they are not needed to reproduce or audit the final computation.

## Verify this archive

From the archive root:

    python3 src/verify_archive.py

This checks every included chunk JSON against `results/manifest.csv`, checks coverage with no gaps or overlaps, and independently recomputes principal aggregate totals and maxima from the chunk certificates.

## Reproduce the full scan

Compile:

    clang++ -O3 -std=c++17 -pthread src/firstlower_certificate.cpp -o firstlower_certificate

Run:

    ./firstlower_certificate \
      --begin 1 \
      --end 100000000000 \
      --chunk 25000000 \
      --threads 4 \
      --out certificate_1e11

Aggregate:

    python3 src/aggregate_certificate.py certificate_1e11 --out regenerated_results

The regenerated canonical result digests can then be compared with `results/manifest.csv`.

## Certificate format

Each chunk JSON includes a SHA-256 digest of a canonical per-input record stream. The record layout is:

    n:u64, tau:u32, elementary:u32, lower:u64,
    max_v5:u32, divisions:u64, brake_events:u64, peak:u128

encoded little-endian and prefixed by the ASCII tag `FL65CERTv1` plus the chunk start and count.

## Scope of the claim

The exhaustive statement is finite: it concerns starts n <= 10^11. The algebraic and probabilistic analysis in the paper does not constitute a proof of convergence for every positive integer, nor a proof that no other cycle exists with minimum state above the verified range.

Repository for the broader sequence-computation program: https://github.com/FarhadBanazadeh/sequence-computations
