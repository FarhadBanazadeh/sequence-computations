6^r-SCALED REDUCED 6k +/- {1,2}/5 FAMILY -- REPRODUCIBILITY PACK

This archive accompanies the paper:
"A 6^r-Scaled Family of the Reduced 6k +/- {1,2}/5 Collatz-Type Map with Three Observed Attractors: Exact Algebraic Conjugacy, Three-Attractor Transport, Orbit-Statistic Invariance, and Transfer of the 10^11 Finite Verification"

BASE RECORD (source of inherited finite data):
Farhad Banazadeh, "The Reduced 6k +/- {1,2}/5 Collatz-Type Domain with Three Observed Attractors up to 10^11", Zenodo record 22786203, DOI 10.5281/zenodo.22786203.
https://zenodo.org/records/22786203

IMPORTANT SCOPE:
No new 80-billion-start scan is claimed here. The 10^11 counts and records are inherited from the base record. The new result is algebraic conjugacy on D_r=6^r D, which transports each verified base trajectory y to x=6^r y.

FILES:
- Farhad_Banazadeh_6r_Scaled_Reduced_6k_pm_1_2_over_5_1e11.tex : paper source
- Farhad_Banazadeh_6r_Scaled_Reduced_6k_pm_1_2_over_5_1e11.pdf : compiled paper
- verify_6r_scaling.py : finite consistency checker for affine scaling, valuation invariance, conjugacy, iterates
- scaling_rules.json : machine-readable rule statement
- base_1e11_summary_inherited.txt : inherited production summary copied from the supplied base computational pack
- base_reference_source.tex : supplied base-paper LaTeX source, retained as provenance/reference material
- SHA256SUMS.txt : checksums

QUICK CHECK:
python3 verify_6r_scaling.py --r-max 6 --y-max 100000 --iter 30

The checker is not the proof. The proof is the exact factorization M_r(6^r y)=6^r M_0(y), together with gcd(6^r,5)=1 and 6^r == 1 (mod 5).
