#!/usr/bin/env python3
"""Finite consistency checker for the 6^r-scaled reduced 6k +/- {1,2}/5 family.
This verifies the algebraic identities on user-selected finite ranges; it is not the proof.
"""
import argparse

def v5(n):
    a=0
    while n%5==0:
        n//=5; a+=1
    return a

def c(n):
    q=n%5
    return {1:-1,2:-2,3:2,4:1}[q]

def T0(y):
    m=6*y+c(y)
    return m//(5**v5(m))

def Mr(x,r):
    s=6**r
    return 6*x+s*c(x)

def Tr(x,r):
    m=Mr(x,r)
    return m//(5**v5(m))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--r-max',type=int,default=6)
    ap.add_argument('--y-max',type=int,default=100000)
    ap.add_argument('--iter',type=int,default=30)
    a=ap.parse_args()
    checked=0
    for r in range(a.r_max+1):
        s=6**r
        for y in range(1,a.y_max+1):
            if y%5==0: continue
            x=s*y
            m0=6*y+c(y); mr=Mr(x,r)
            assert x%5==y%5
            assert mr==s*m0
            assert v5(mr)==v5(m0)
            assert Tr(x,r)==s*T0(y)
            yy,xx=y,x
            for _ in range(a.iter):
                assert xx==s*yy
                yy=T0(yy); xx=Tr(xx,r)
            checked+=1
    print(f'PASS: {checked} (r,y) starts checked; one-step and {a.iter}-iterate scaling identities hold.')

if __name__=='__main__': main()
