#!/usr/bin/env python3
"""Finite consistency verifier for the 5^r-scaled 5k+1(3)/4 family.
This verifies identities implied by the proof; it is not a convergence proof.
"""
import argparse

CYCLES = [(1,), (31,39,49), (37,47,59), (61,77,97)]

def v2(n):
    if n <= 0:
        raise ValueError("v2 expects a positive integer")
    return (n & -n).bit_length() - 1

def c(n):
    if n % 2 == 0:
        raise ValueError("state must be odd")
    return 3 if n % 4 == 1 else 1

def m0(y): return 5*y + c(y)
def t0(y):
    m = m0(y)
    return m >> v2(m)
def mr(x, r): return 5*x + (5**r)*c(x)
def tr(x, r):
    m = mr(x, r)
    return m >> v2(m)

def check(max_r, max_y, iters):
    checked = 0
    for r in range(max_r + 1):
        q = 5**r
        for y in range(1, max_y + 1, 2):
            x = q*y
            assert c(x) == c(y)
            assert mr(x,r) == q*m0(y)
            assert v2(mr(x,r)) == v2(m0(y))
            assert tr(x,r) == q*t0(y)
            yy, xx = y, x
            for _ in range(iters):
                yy = t0(yy)
                xx = tr(xx,r)
                assert xx == q*yy
            checked += 1
        for cyc in CYCLES:
            scaled = tuple(q*z for z in cyc)
            for i,z in enumerate(scaled):
                assert tr(z,r) == scaled[(i+1)%len(scaled)]
    return checked

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--max-r', type=int, default=6)
    ap.add_argument('--max-y', type=int, default=100001)
    ap.add_argument('--iters', type=int, default=25)
    a = ap.parse_args()
    n = check(a.max_r, a.max_y, a.iters)
    print(f"OK: checked {n} scaled starts for r=0..{a.max_r}, y<= {a.max_y}, {a.iters} iterates each")
