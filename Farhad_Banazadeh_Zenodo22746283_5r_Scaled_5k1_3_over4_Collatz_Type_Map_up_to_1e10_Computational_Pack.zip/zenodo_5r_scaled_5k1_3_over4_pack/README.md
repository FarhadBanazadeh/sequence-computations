# Zenodo Reproducibility Pack: 5^r-Scaled 5k+1(3)/4 Family

Author: Farhad Banazadeh  
Email: fn.bana@hotmail.com  
ORCID: 0009-0004-7023-0298  
Date: 14 September 2026

## Family
Let `c(x)=3` for `x ≡ 1 (mod 4)` and `c(x)=1` for `x ≡ 3 (mod 4)`.
For each integer `r >= 0`, the state space is

`S_r = {5^r y : y is a positive odd integer}`.

Define

`M_r(x) = 5x + 5^r c(x)` and `T_r(x) = M_r(x) / 2^v2(M_r(x))`.

The forced first division by 4 is therefore

- `(5x + 3*5^r)/4` when `x ≡ 1 (mod 4)`;
- `(5x + 5^r)/4` when `x ≡ 3 (mod 4)`;

followed by removal of every additional factor of 2.

## Exact result
For every positive odd `y` and every `r >= 0`,

`T_r(5^r y) = 5^r T_0(y)`.

Thus the scaled system is exactly conjugate to the base system. The fixed point and three displayed cycles scale to

- `{5^r}`
- `{31*5^r, 39*5^r, 49*5^r}`
- `{37*5^r, 47*5^r, 59*5^r}`
- `{61*5^r, 77*5^r, 97*5^r}`.

## Inherited finite result
The base paper exhaustively tested all 5,000,000,000 positive odd starts below `10^10`, with `unknown=0`. These base data are copied here as provenance. They are **not** new scans of the scaled family.

For each fixed `r`, exact conjugacy transfers those verified trajectories to

`F_r = {5^r y : 1 <= y < 10^10, y odd}`.

Basin counts, basin proportions, capture times, and valuation sequences are unchanged on corresponding sets. Absolute state values and peaks are multiplied by `5^r`.

## Contents
- `5r_scaled_5k1_3_over4_article.tex` / `.pdf`: paper source and compiled paper.
- `article/`: build copy of the paper.
- `code/verify_scaling.py`: finite consistency checker for the conjugacy identities and scaled cycles.
- `results/inherited_base_summary_1e10.json`: verbatim base production summary.
- `results/inherited_base_cutoff_summary.csv`: verbatim base cutoff table.
- `scaling_rules.json`: machine-readable statement of the family and theorem.
- `zenodo_metadata.json`: suggested Zenodo metadata.
- `CITATION.cff`: citation metadata.
- `SHA256SUMS.txt`: SHA-256 integrity hashes.

## Verify identities
```bash
python3 code/verify_scaling.py --max-r 6 --max-y 100001 --iters 25
```

The verifier is a consistency test, not the mathematical proof.

## Compile the paper
```bash
pdflatex 5r_scaled_5k1_3_over4_article.tex
pdflatex 5r_scaled_5k1_3_over4_article.tex
```

## Scientific scope
The paper proves exact conjugacy of every scaled domain `S_r` with the base system. It does not prove global convergence of the base map. Therefore global convergence of the scaled family remains equivalent to the unresolved base Four-Attractor Conjecture.
