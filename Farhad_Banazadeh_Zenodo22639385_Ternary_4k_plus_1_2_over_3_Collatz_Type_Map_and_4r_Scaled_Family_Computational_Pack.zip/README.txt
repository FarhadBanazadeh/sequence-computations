Supplementary files for:
A Ternary (4k + 1(2))/3 Collatz-Type Map and Its 4^r-Scaled Family

Contents:
1. A_Ternary_4k1_2_over_3_Scaled_Family.tex
   LaTeX source of the article.
2. A_Ternary_4k1_2_over_3_Scaled_Family.pdf
   Compiled article.
3. verify_conjugacy.py
   Small exact verifier for the one-step conjugacy, valuation identity, and
   scaled map identity on a finite test range.
4. SCALING_RULES.txt
   Machine-readable summary of the definitions and exact identities.
5. BASE_COMPUTATIONAL_SUMMARY.txt
   Clearly labelled numerical summary inherited from the preceding base paper.

Data separation:
The numerical experiments in the earlier theoretical/model article are not used
as evidence for this paper. The billion-scale values listed here belong to the
preceding base-system computation. The new paper proves exact algebraic transfer
from the base system to the 4^r-scaled family.

The global all-integers convergence statement remains a conjecture.
