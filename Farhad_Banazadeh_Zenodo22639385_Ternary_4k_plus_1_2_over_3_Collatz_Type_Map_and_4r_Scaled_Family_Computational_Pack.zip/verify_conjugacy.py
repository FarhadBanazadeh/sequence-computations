#!/usr/bin/env python3
"""Exact small-range verifier for the 4^r scaling conjugacy.
Checks M_r(4^r y)=4^r M_0(y), equal v_3 values, and
T_r(4^r y)=4^r T_0(y) for y not divisible by 3.
"""

def v3(n):
    v = 0
    while n % 3 == 0:
        n //= 3
        v += 1
    return v

def M0(y):
    return 4*y + (3 - (y % 3))

def Mr(x, r):
    return 4*x + (4**r)*(3 - (x % 3))

def T0(y):
    m = M0(y)
    return m // (3**v3(m))

def Tr(x, r):
    m = Mr(x, r)
    return m // (3**v3(m))

for r in range(8):
    scale = 4**r
    for y in range(1, 1001):
        if y % 3 == 0:
            continue
        assert Mr(scale*y, r) == scale*M0(y)
        assert v3(Mr(scale*y, r)) == v3(M0(y))
        assert Tr(scale*y, r) == scale*T0(y)
print("PASS: conjugacy identities verified for r=0..7 and 1<=y<=1000, 3∤y.")
