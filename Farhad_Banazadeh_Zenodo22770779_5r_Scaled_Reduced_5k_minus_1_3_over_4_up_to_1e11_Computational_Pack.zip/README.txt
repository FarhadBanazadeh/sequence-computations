5^r-scaled reduced 5k-1(3)/4 consistency pack

This pack supports the algebraic scaling paper. It does NOT contain a new 10^11 scan.
The finite 10^11 statistics are inherited from the base Zenodo record 22752810 by exact conjugacy.

Run:
  python3 verify_scaling.py --rmax 5 --ymax 10001 --iters 20

Definitions:
  q(y)=1 for y=1 mod 4, q(y)=3 for y=3 mod 4
  T0(y)=(5y-q(y))/2^v2(5y-q(y))
  Sr=5^r*N_odd
  Tr(x)=(5x-5^r q(x))/2^v2(5x-5^r q(x))
