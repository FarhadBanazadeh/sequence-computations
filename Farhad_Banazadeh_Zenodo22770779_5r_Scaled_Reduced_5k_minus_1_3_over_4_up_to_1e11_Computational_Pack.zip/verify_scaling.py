#!/usr/bin/env python3
import argparse

def v2(n):
    if n == 0: raise ValueError('v2(0) undefined')
    a=0
    while n%2==0: a+=1; n//=2
    return a

def q(y): return 1 if y%4==1 else 3

def M0(y): return 5*y-q(y)
def T0(y):
    n=M0(y); return n >> v2(n)
def Mr(x,r): return 5*x-(5**r)*q(x)
def Tr(x,r):
    n=Mr(x,r); return n >> v2(n)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--rmax',type=int,default=5)
    ap.add_argument('--ymax',type=int,default=10001)
    ap.add_argument('--iters',type=int,default=20)
    a=ap.parse_args()
    checks=0
    for r in range(a.rmax+1):
        s=5**r
        assert Tr(s,r)==s and Tr(3*s,r)==3*s
        for y in range(1,a.ymax,2):
            x=s*y
            assert q(x)==q(y)
            assert Mr(x,r)==s*M0(y)
            assert v2(Mr(x,r))==v2(M0(y))
            assert Tr(x,r)==s*T0(y)
            yy,xx=y,x
            for _ in range(a.iters):
                yy=T0(yy); xx=Tr(xx,r)
                assert xx==s*yy
            checks+=1
    print('PASS:',checks,'starting-state scaling checks')
if __name__=='__main__': main()
