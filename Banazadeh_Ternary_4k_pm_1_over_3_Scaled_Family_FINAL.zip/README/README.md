# Final Reproducibility Package

## Paper
A Ternary (4k±1)/3 Collatz-Type Map and Its (4n±4^r)/3 Scaled Family

Author: Farhad Banazadeh
Email: fn.bana@hotmail.com
ORCID: 0009-0004-7023-0298

## Contents
1. Final PDF
2. Final LaTeX source
3. Base-map computation code
4. General 4^r-scaled-family computation code
5. Direct finite identity-check code
6. Finite computational results (CSV and TXT)
7. This README and metadata

## General result
For D_r = 4^r N, the scaled map satisfies

    T_r(4^r k) = 4^r T(k)

and therefore

    T_r^j(4^r k) = 4^r T^j(k).

The parameter r is general with r >= 0 and is not bounded above.

## Computational scope
The included finite verification covers r = 0,...,12 and k = 1,...,10000.
These calculations provide computational evidence only. They are not a proof of
the global conjecture for every k and every r.

## Related research records
Prior computational article:
10.5281/zenodo.22195651

Related scaled-family record:
10.5281/zenodo.22195652

GitHub:
https://github.com/FarhadBanazadeh/sequence-computations

ORCID:
https://orcid.org/0009-0004-7023-0298
