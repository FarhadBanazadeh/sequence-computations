#!/usr/bin/env python3
"""
Base ternary (4k +/- 1)/3 map.
This script performs finite computational checks only.
It does not claim to prove the open conjecture.
"""

def T(n: int) -> int:
    r = n % 3
    if r == 0:
        return n // 3
    if r == 1:
        return (4*n - 1) // 3
    return (4*n + 1) // 3

def orbit(n: int, max_steps: int = 100000):
    seen = set()
    x = n
    for step in range(max_steps + 1):
        if x == 1:
            return True, step, x, seen
        if x in seen:
            return False, step, x, seen
        seen.add(x)
        x = T(x)
    return False, max_steps, x, seen

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--max-n", type=int, default=10000)
    p.add_argument("--max-steps", type=int, default=100000)
    args = p.parse_args()

    failures = []
    max_steps = 0
    max_peak = 0
    max_step_start = None
    max_peak_start = None

    for n in range(1, args.max_n + 1):
        ok, steps, last, seen = orbit(n, args.max_steps)
        peak = max(seen | {last})
        if not ok:
            failures.append((n, steps, last))
        if ok and steps > max_steps:
            max_steps, max_step_start = steps, n
        if peak > max_peak:
            max_peak, max_peak_start = peak, n

    print(f"Range: 1..{args.max_n}")
    print(f"Failures to reach 1 within step limit: {len(failures)}")
    print(f"Maximum steps: {max_steps} (start {max_step_start})")
    print(f"Maximum peak: {max_peak} (start {max_peak_start})")
    if failures:
        print("First failures:", failures[:20])
