#!/usr/bin/env python3
"""
Machine-checkable algebraic identities for the scaled family.

The script checks many random/finite integer instances of:
    T_r(4^r k) = 4^r T(k)
and verifies that the branch formula agrees with the definition.
"""

import random

def T(n):
    return n//3 if n%3==0 else ((4*n-1)//3 if n%3==1 else (4*n+1)//3)

def Tr_definition(n, r):
    q = 4**r
    if n % q:
        raise ValueError
    return q*T(n//q)

def Tr_branch(n, r):
    q = 4**r
    if n % q:
        raise ValueError
    if n % 3 == 0:
        return n//3
    k = n//q
    if k % 3 == 1:
        return (4*n-q)//3
    return (4*n+q)//3

for r in range(0, 13):
    for k in range(1, 10001):
        n = (4**r)*k
        assert Tr_definition(n,r) == (4**r)*T(k)
        assert Tr_branch(n,r) == Tr_definition(n,r)

print("PASS: all finite identity and branch-form checks passed.")
