#!/usr/bin/env python3
"""
Finite checks for the 4^r-scaled family.

For q = 4^r and n = q*k, define
    T_r(n) = q*T(k).
Equivalently:
    n/3                         if n == 0 mod 3
    (4n-q)/3                    if n/q == 1 mod 3
    (4n+q)/3                    if n/q == 2 mod 3

The identity T_r^j(q*k) = q*T^j(k) is tested directly.
"""

def T(n: int) -> int:
    r = n % 3
    if r == 0:
        return n // 3
    if r == 1:
        return (4*n - 1) // 3
    return (4*n + 1) // 3

def Tr(n: int, r: int) -> int:
    q = 4**r
    if n % q != 0:
        raise ValueError("n must belong to D_r = 4^r N")
    k = n // q
    return q * T(k)

def iterate(f, x, steps):
    out = [x]
    for _ in range(steps):
        x = f(x)
        out.append(x)
    return out

def check(r: int, max_k: int = 10000, max_steps: int = 100000):
    q = 4**r
    failures = []
    max_steps_seen = 0
    max_peak = 0

    for k in range(1, max_k + 1):
        base = iterate(T, k, max_steps)
        # Find first occurrence of 1 in base orbit.
        try:
            j = base.index(1)
        except ValueError:
            failures.append(k)
            continue

        scaled = iterate(lambda x: Tr(x, r), q*k, j)
        expected = [q*x for x in base[:j+1]]
        if scaled != expected or scaled[-1] != q:
            failures.append(k)
            continue

        max_steps_seen = max(max_steps_seen, j)
        max_peak = max(max_peak, max(scaled))

    return failures, max_steps_seen, max_peak

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--max-r", type=int, default=12)
    p.add_argument("--max-k", type=int, default=10000)
    args = p.parse_args()

    print("Finite verification of the scaled identity")
    print(f"k range: 1..{args.max_k}")
    print(f"r range: 0..{args.max_r}")
    print()
    for r in range(args.max_r + 1):
        failures, steps, peak = check(r, args.max_k)
        print(f"r={r:2d}, q=4^{r}={4**r}, failures={len(failures)}, "
              f"max_steps={steps}, max_scaled_peak={peak}")
