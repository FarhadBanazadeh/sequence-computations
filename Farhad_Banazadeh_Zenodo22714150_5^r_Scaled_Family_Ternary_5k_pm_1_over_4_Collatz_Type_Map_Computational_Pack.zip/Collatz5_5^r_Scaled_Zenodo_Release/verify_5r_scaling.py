#!/usr/bin/env python3
"""Finite consistency verifier for the 5^r-scaled reduced 5x±1 map."""
import argparse

def v2(n):
    if n == 0:
        raise ValueError("v2(0) undefined")
    a = 0
    while n % 2 == 0:
        n //= 2
        a += 1
    return a

def eps(x):
    if x % 4 == 1:
        return -1
    if x % 4 == 3:
        return +1
    raise ValueError("state must be odd")

def M0(y):
    return 5*y + eps(y)

def T0(y):
    n = M0(y)
    return n >> v2(n)

def Mr(x, r):
    return 5*x + (5**r)*eps(x)

def Tr(x, r):
    n = Mr(x, r)
    return n >> v2(n)

def check(rmax, ymax, iterates):
    checks = 0
    for r in range(rmax + 1):
        s = 5**r
        for y in range(1, ymax + 1, 2):
            x = s*y
            assert x % 4 == y % 4
            assert Mr(x,r) == s*M0(y)
            assert v2(Mr(x,r)) == v2(M0(y))
            assert Tr(x,r) == s*T0(y)
            yy, xx = y, x
            for _ in range(iterates):
                assert xx == s*yy
                yy = T0(yy)
                xx = Tr(xx,r)
            assert xx == s*yy
            checks += 1
    return checks

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--rmax", type=int, default=8)
    p.add_argument("--ymax", type=int, default=100000)
    p.add_argument("--iterates", type=int, default=100)
    a = p.parse_args()
    n = check(a.rmax, a.ymax, a.iterates)
    print(f"PASS: {n} scaled starts checked; r=0..{a.rmax}, odd y<= {a.ymax}, {a.iterates} iterates each.")
