# 5^r-Scaled Reduced 5x±1 Collatz-Type Map — Zenodo Reproducibility Archive

## Accompanying article

**A 5^r-Scaled Family of the Reduced Ternary (5k±1)/4 Collatz-Type Map:
Exact Algebraic Conjugacy, Cycle Preservation, Orbit-Statistic Invariance,
and Transfer of the 10^10 Finite Verification**

Author: Farhad Banazadeh  
ORCID: 0009-0004-7023-0298  
Date: 2026-09-11

## Definition

Base map on positive odd y:

- y ≡ 1 (mod 4): M0(y)=5y-1
- y ≡ 3 (mod 4): M0(y)=5y+1
- T0(y)=M0(y)/2^v2(M0(y))

For r >= 0, the scaled domain is Sr = 5^r * N_odd. For x in Sr:

- x ≡ 1 (mod 4): Mr(x)=5x-5^r
- x ≡ 3 (mod 4): Mr(x)=5x+5^r
- Tr(x)=Mr(x)/2^v2(Mr(x))

The forced first compression has the requested form (5x ± 5^r)/4; complete
two-adic reduction then removes any additional factors of 2.

## Main theorem

For every odd y and r >= 0:

    Mr(5^r y) = 5^r M0(y)
    v2(Mr(5^r y)) = v2(M0(y))
    Tr(5^r y) = 5^r T0(y)
    Tr^j(5^r y) = 5^r T0^j(y)

Thus the scaled systems are exactly conjugate to the base system on Sr.

## Consequences

- fixed point 1 -> 5^r
- 7 -> 9 -> 11 -> 7 scales to
  7*5^r -> 9*5^r -> 11*5^r -> 7*5^r
- cycle lengths are unchanged
- no new cycle exists inside Sr unless a base cycle exists
- complete v2 sequences are unchanged
- capture/transient times are unchanged
- first-descent stopping times are unchanged
- first-lower values scale by 5^r
- reduced and raw affine peaks scale by 5^r
- peak iteration indices and peak/start ratios are unchanged
- basin membership and inverse forests transfer bijectively

## Inherited finite verification

The base Zenodo record exhaustively tested 5,000,000,000 positive odd starts
below 10^10. The present work does NOT claim a new 5-billion-start scan for
each r. Exact conjugacy transfers those verified trajectories to:

    {5^r y : 1 <= y < 10^10, y odd}

The inherited base statistics are stored in inherited_base_summary.json.

## Verifier

Run:

    python3 verify_5r_scaling.py

Optional larger consistency check:

    python3 verify_5r_scaling.py --rmax 10 --ymax 1000000 --iterates 200

This verifier is a consistency check, not the proof. The proof is algebraic.

## Important scope statement

Exact conjugacy is proved on Sr = 5^r * N_odd. It is not asserted for arbitrary
odd x that are not divisible by 5^r.

The finite transfer theorem is not a proof of global convergence. Any unresolved
global issue of the base system is inherited unchanged by the scaled family.

## Archive contents

- article LaTeX source
- compiled article PDF
- verify_5r_scaling.py
- scaling_rules.json
- inherited_base_summary.json
- zenodo_metadata_suggestion.json
- README.md
- SHA256SUMS.txt
