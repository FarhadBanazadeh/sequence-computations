#!/usr/bin/env python3
"""Consistency verifier for the 7^r-scaled ternary (7k +/- 1)/6 map.

This script is intentionally lightweight.  It verifies the exact scaling identities
on finite samples; the proof in the paper is algebraic and does not rely on this
program.  The exhaustive 10^11 base scan is inherited from the cited base record
and is not repeated here.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def v_p(m: int, p: int) -> int:
    c = 0
    while m % p == 0:
        c += 1
        m //= p
    return c


def eps(n: int) -> int:
    r = n % 6
    if r == 1:
        return -1
    if r == 5:
        return +1
    raise ValueError(f"state {n} is not coprime to 6")


def base_step(n: int):
    if n <= 0 or n % 6 not in (1, 5):
        raise ValueError("base state must be positive and coprime to 6")
    e = eps(n)
    N = 7 * n + e
    a = v_p(N, 2)
    b = v_p(N, 3)
    y = N // (2 ** a * 3 ** b)
    return y, a, b, e, N


def scaled_step(x: int, r: int):
    f = 7 ** r
    if x <= 0 or x % f != 0:
        raise ValueError("scaled state must lie in D_r = 7^r D")
    n = x // f
    if n % 6 not in (1, 5):
        raise ValueError("normalized state must be coprime to 6")
    e = eps(x)  # same branch as eps(n), because 7^r == 1 mod 6
    N = 7 * x + f * e
    a = v_p(N, 2)
    b = v_p(N, 3)
    y = N // (2 ** a * 3 ** b)
    if y % f != 0:
        raise AssertionError("closure failure")
    return y, a, b, e, N


def orbit(step, start: int, terminal: int, cap: int = 10000):
    out = [start]
    x = start
    for _ in range(cap):
        if x == terminal:
            return out
        x = step(x)[0]
        out.append(x)
    raise RuntimeError("orbit cap reached")


def verify(max_n: int, max_r: int, iterate_depth: int):
    checked_states = 0
    checked_iterates = 0
    for n in range(1, max_n + 1):
        if n % 6 not in (1, 5):
            continue
        bnext, ba, bb, be, bN = base_step(n)
        for r in range(max_r + 1):
            f = 7 ** r
            x = f * n
            snext, sa, sb, se, sN = scaled_step(x, r)
            assert x % 6 == n % 6
            assert se == be
            assert sN == f * bN
            assert (sa, sb) == (ba, bb)
            assert snext == f * bnext
            checked_states += 1

            bn = n
            sx = x
            for _ in range(iterate_depth):
                if bn == 1:
                    assert sx == f
                    break
                bn = base_step(bn)[0]
                sx = scaled_step(sx, r)[0]
                assert sx == f * bn
                checked_iterates += 1

    # Explicit example 71 -> ... -> 1 and its r=1,2,3 copies.
    expected_base = [71, 83, 97, 113, 11, 13, 5, 1]
    got = orbit(base_step, 71, 1)
    assert got == expected_base, got
    scaled_examples = {}
    for r in (1, 2, 3):
        f = 7 ** r
        got_scaled = orbit(lambda x, rr=r: scaled_step(x, rr), f * 71, f)
        expected_scaled = [f * z for z in expected_base]
        assert got_scaled == expected_scaled
        scaled_examples[str(r)] = got_scaled

    # Transferred record arithmetic used in the paper.
    records = {
        "first_descent_start": 7_449_779_881,
        "first_lower_value": 237_507_511,
        "total_steps_start": 62_073_713_149,
        "peak_start": 97_860_819_035,
        "peak_value": 1_830_618_509_383,
    }
    transferred = {}
    for r in (1, 2, 3):
        f = 7 ** r
        transferred[str(r)] = {k: f * v for k, v in records.items()}

    return {
        "status": "PASS",
        "max_normalized_state_checked": max_n,
        "max_scale_r_checked": max_r,
        "iterate_depth_checked": iterate_depth,
        "one_step_state_scale_pairs_checked": checked_states,
        "iterate_equalities_checked": checked_iterates,
        "base_example": expected_base,
        "scaled_examples": scaled_examples,
        "record_transfers_r_1_to_3": transferred,
        "note": "Finite consistency check only; exact conjugacy is proved algebraically in the paper."
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-n", type=int, default=200000)
    ap.add_argument("--max-r", type=int, default=6)
    ap.add_argument("--iterate-depth", type=int, default=20)
    ap.add_argument("--json-out", default="verification_results.json")
    args = ap.parse_args()
    result = verify(args.max_n, args.max_r, args.iterate_depth)
    Path(args.json_out).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
