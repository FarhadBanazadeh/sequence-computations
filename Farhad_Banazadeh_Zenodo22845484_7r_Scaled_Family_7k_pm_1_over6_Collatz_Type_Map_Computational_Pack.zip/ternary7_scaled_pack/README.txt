A TERNARY (7k +/- 1)/6 MAP AND ITS (7k +/- 7^r)/6 SCALED FAMILY
Reproducibility / source package
19 September 2026

CONTENTS
--------
Farhad_Banazadeh_Ternary_7k_pm_1_over_6_and_7r_Scaled_Family.pdf
    Compiled 20-page paper.

Farhad_Banazadeh_Ternary_7k_pm_1_over_6_and_7r_Scaled_Family.tex
    Complete LaTeX source for the paper.

verify_scaled_family.py
    Lightweight independent consistency verifier for the exact scaling identities.
    The proof is algebraic; this verifier is not a substitute for the proof and does
    not repeat the 10^11 exhaustive base scan.

verification_results.json
    Output of:
      ./verify_scaled_family.py --max-n 200000 --max-r 6 --iterate-depth 20
    It records PASS after checking 466,669 one-step base/scale pairs and more than
    4.8 million iterate equalities.

scaled_family_statement.json
    Machine-readable definitions, central theorem, and logical-status summary.

transferred_records_r1_r3.csv
    Exact arithmetic transfer of the principal base records to r=1,2,3.

sample_trajectories.csv
    Base trajectory 71 -> ... -> 1 and exact scaled copies for r=1,2,3.

INHERITED_BASE_RESULTS.txt
    Compact statement of the base finite record used by the transfer theorem.

provenance/
    Exact user-supplied base PDF, base LaTeX source, and base computational pack.
    These establish the provenance of the inherited 10^11 finite computation.

SHA256SUMS.txt
    SHA-256 checksums for package files (excluding SHA256SUMS.txt itself).

CENTRAL EXACT IDENTITIES
------------------------
D_r = 7^r D, where D={n>=1:gcd(n,6)=1}.

N_r(7^r n) = 7^r N_0(n).
nu_2(N_r(7^r n)) = nu_2(N_0(n)).
nu_3(N_r(7^r n)) = nu_3(N_0(n)).
T_r(7^r n) = 7^r T_0(n).
T_r^j(7^r n) = 7^r T_0^j(n).

IMPORTANT DOMAIN QUALIFICATION
------------------------------
The exact conjugacy is on D_r=7^r D. It is generally false to apply the formula
with correction +/-7^r to an arbitrary k outside D_r and expect the result to be
7^r times the base map at k. The paper gives the explicit counterexample r=1,k=11.

REFERENCES / PROVENANCE
-----------------------
Base 7-map record:
https://zenodo.org/records/22829703

Earlier structural scaled-family record used as a presentation/model reference:
https://zenodo.org/records/22228200

Separate 6^r scaled paper supplied as a witness for presentation style only:
https://zenodo.org/records/22809470

No numerical result from the 4-map or 6-map systems is used as evidence for the
7-map family.
