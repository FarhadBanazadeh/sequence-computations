/*
 * scan_ternary_minus_1e11.c
 *
 * Chunked/checkpoint scanner for the accelerated ternary map
 *
 *   T(x) = (4*x-r) / 3^v3(4*x-r), r=x mod 3 in {1,2}
 *
 * Known positive attractors:
 *   {1}, {2}, 22 -> 29 -> 38 -> 50 -> 22
 *
 * Exact orbit arithmetic supports unsigned __int128.
 * Performance V2 uses a 64-bit fast path whenever the current transition
 * is provably safe in uint64_t, and automatically promotes to 128-bit.
 *
 * Usage:
 *   ./scan_ternary_minus_1e11 START END CHUNK THREADS RESULTS_DIR
 *
 * Example validation:
 *   ./scan_ternary_minus_1e11 1 1000000 100000 4 test_chunks
 *
 * Example new-domain scan:
 *   ./scan_ternary_minus_1e11 1000000001 100000000000 100000000 4 results_1e11_chunks
 *
 * A chunk is considered complete only after its .done file is atomically renamed
 * into place. Re-running the same command skips completed chunks and reconstructs
 * session totals from their saved records.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>

typedef unsigned __int128 u128;

#define WORK_BLOCK 65536ULL
#define LINEBUF 1024

typedef struct {
    uint64_t tested, to1, to2, to4, unknown, overflow;
    u128 total_steps, total_v3;
    uint64_t max_steps, max_steps_start;
    uint64_t max_v3, max_v3_start;
    u128 max_peak;
    uint64_t max_peak_start;
    uint64_t unknown_start;
    u128 unknown_state;
} Stats;

typedef struct {
    uint64_t lo, hi;
    _Atomic uint64_t next_raw;
    Stats *locals;
} ChunkCtx;

static inline u128 u128_max(void) { return ~(u128)0; }

static void u128_to_str(u128 x, char *buf, size_t n) {
    char tmp[64];
    size_t i = 0, j = 0;
    if (n == 0) return;
    if (x == 0) { if (n > 1) { buf[0]='0'; buf[1]='\0'; } return; }
    while (x && i < sizeof(tmp)) { tmp[i++] = (char)('0' + (unsigned)(x % 10)); x /= 10; }
    while (i && j + 1 < n) buf[j++] = tmp[--i];
    buf[j] = '\0';
}

static int str_to_u128(const char *s, u128 *out) {
    u128 x = 0, mx = u128_max();
    if (!s || !*s) return 0;
    for (; *s; ++s) {
        if (*s < '0' || *s > '9') return 0;
        unsigned d = (unsigned)(*s - '0');
        if (x > (mx - d) / 10) return 0;
        x = x * 10 + d;
    }
    *out = x;
    return 1;
}

static inline int attractor_id(u128 x) {
    if (x == 1) return 1;
    if (x == 2) return 2;
    if (x == 22 || x == 29 || x == 38 || x == 50) return 4;
    return 0;
}

static inline int map_step(u128 x, u128 *next, uint32_t *v) {
    /*
     * Fast path: almost all states in the measured domain fit in uint64_t.
     * Keep division/modulo in native 64-bit arithmetic whenever 4*x-r is
     * also guaranteed to fit. Otherwise promote exactly to unsigned __int128.
     */
    if (x <= (u128)UINT64_MAX) {
        uint64_t a = (uint64_t)x;
        unsigned r = (unsigned)(a % 3ULL);
        if (r == 0) return 0;

        if (a <= UINT64_MAX/4ULL + 1ULL) {
            uint64_t y = 4ULL*a - (uint64_t)r;
            uint32_t k = 0;
            do { y /= 3ULL; ++k; } while (y % 3ULL == 0);
            *next = (u128)y;
            *v = k;
            return 1;
        }
    }

    unsigned r = (unsigned)(x % (u128)3);
    if (r == 0) return 0;

    /* 4*x-r <= UMAX.  For UMAX=4q+3 and r in {1,2}, x=q+1 is safe. */
    if (x > u128_max()/4 + 1) return 0;

    u128 y = 4*x - (u128)r;
    uint32_t k = 0;
    do { y /= (u128)3; ++k; } while (y % (u128)3 == 0);
    *next = y;
    *v = k;
    return 1;
}

static inline void finish_known(Stats *s, uint64_t start, int a,
                                uint64_t steps, uint64_t vsum, u128 peak) {
    ++s->tested;
    if (a == 1) ++s->to1;
    else if (a == 2) ++s->to2;
    else ++s->to4;
    s->total_steps += (u128)steps;
    s->total_v3 += (u128)vsum;
    if (steps > s->max_steps) { s->max_steps=steps; s->max_steps_start=start; }
    if (vsum > s->max_v3) { s->max_v3=vsum; s->max_v3_start=start; }
    if (peak > s->max_peak) { s->max_peak=peak; s->max_peak_start=start; }
}

static inline void scan_one(uint64_t start, Stats *s) {
    u128 x = (u128)start, peak = (u128)start;
    u128 tortoise = x;
    uint64_t power = 1, lam = 0, steps = 0, vsum = 0;

    for (;;) {
        int a = attractor_id(x);
        if (a) { finish_known(s,start,a,steps,vsum,peak); return; }

        u128 y; uint32_t v;
        if (!map_step(x,&y,&v)) { ++s->tested; ++s->overflow; return; }

        ++steps; vsum += v;
        if (y > peak) peak = y;
        x = y;
        ++lam;

        if (x == tortoise) {
            ++s->tested; ++s->unknown;
            s->total_steps += (u128)steps; s->total_v3 += (u128)vsum;
            if (steps > s->max_steps) { s->max_steps=steps; s->max_steps_start=start; }
            if (vsum > s->max_v3) { s->max_v3=vsum; s->max_v3_start=start; }
            if (peak > s->max_peak) { s->max_peak=peak; s->max_peak_start=start; }
            if (!s->unknown_start) { s->unknown_start=start; s->unknown_state=x; }
            return;
        }
        if (lam == power) {
            tortoise = x;
            if (power <= UINT64_MAX/2) power <<= 1;
            lam = 0;
        }
    }
}

typedef struct { ChunkCtx *ctx; Stats *s; } WorkerArg;

static void *worker(void *p) {
    WorkerArg *a = (WorkerArg*)p;
    ChunkCtx *c = a->ctx; Stats *s = a->s;
    memset(s,0,sizeof(*s));

    for (;;) {
        uint64_t lo = atomic_fetch_add_explicit(&c->next_raw, WORK_BLOCK, memory_order_relaxed);
        if (lo > c->hi) break;
        uint64_t hi = (c->hi - lo + 1 < WORK_BLOCK) ? c->hi : lo + WORK_BLOCK - 1;
        for (uint64_t n=lo; n<=hi; ++n) {
            if (n % 3) scan_one(n,s);
            if (n == UINT64_MAX) break;
        }
    }
    return NULL;
}

static void merge(Stats *d, const Stats *s) {
    d->tested += s->tested; d->to1 += s->to1; d->to2 += s->to2; d->to4 += s->to4;
    d->unknown += s->unknown; d->overflow += s->overflow;
    d->total_steps += s->total_steps; d->total_v3 += s->total_v3;
    if (s->max_steps > d->max_steps) { d->max_steps=s->max_steps; d->max_steps_start=s->max_steps_start; }
    if (s->max_v3 > d->max_v3) { d->max_v3=s->max_v3; d->max_v3_start=s->max_v3_start; }
    if (s->max_peak > d->max_peak) { d->max_peak=s->max_peak; d->max_peak_start=s->max_peak_start; }
    if (!d->unknown_start && s->unknown_start) { d->unknown_start=s->unknown_start; d->unknown_state=s->unknown_state; }
}

static int mkdir_if_needed(const char *p) {
    if (mkdir(p,0755)==0 || errno==EEXIST) return 1;
    perror("mkdir"); return 0;
}

static int save_done(const char *dir, uint64_t idx, uint64_t lo, uint64_t hi,
                     double sec, const Stats *s) {
    char path[512], tmp[520], a[64], b[64], c[64];
    snprintf(path,sizeof(path),"%s/chunk_%06" PRIu64 ".done",dir,idx);
    snprintf(tmp,sizeof(tmp),"%s.tmp",path);
    FILE *f=fopen(tmp,"w"); if(!f) return 0;
    u128_to_str(s->total_steps,a,sizeof(a)); u128_to_str(s->total_v3,b,sizeof(b));
    u128_to_str(s->max_peak,c,sizeof(c));
    fprintf(f,"index=%" PRIu64 "\nlo=%" PRIu64 "\nhi=%" PRIu64 "\nseconds=%.9f\n",idx,lo,hi,sec);
    fprintf(f,"tested=%" PRIu64 "\nto1=%" PRIu64 "\nto2=%" PRIu64 "\nto4=%" PRIu64 "\nunknown=%" PRIu64 "\noverflow=%" PRIu64 "\n",
            s->tested,s->to1,s->to2,s->to4,s->unknown,s->overflow);
    fprintf(f,"total_steps=%s\ntotal_v3=%s\n",a,b);
    fprintf(f,"max_steps=%" PRIu64 "\nmax_steps_start=%" PRIu64 "\n",s->max_steps,s->max_steps_start);
    fprintf(f,"max_v3=%" PRIu64 "\nmax_v3_start=%" PRIu64 "\n",s->max_v3,s->max_v3_start);
    fprintf(f,"max_peak=%s\nmax_peak_start=%" PRIu64 "\n",c,s->max_peak_start);
    fprintf(f,"unknown_start=%" PRIu64 "\n",s->unknown_start);
    u128_to_str(s->unknown_state,c,sizeof(c)); fprintf(f,"unknown_state=%s\n",c);
    if (fclose(f)!=0) return 0;
    if (rename(tmp,path)!=0) { perror("rename"); return 0; }
    return 1;
}

static int load_done(const char *dir, uint64_t idx, Stats *s, double *sec) {
    char path[512], line[LINEBUF];
    snprintf(path,sizeof(path),"%s/chunk_%06" PRIu64 ".done",dir,idx);
    FILE *f=fopen(path,"r"); if(!f) return 0;
    memset(s,0,sizeof(*s)); *sec=0.0;
    while(fgets(line,sizeof(line),f)) {
        char *eq=strchr(line,'='); if(!eq) continue; *eq++='\0'; eq[strcspn(eq,"\r\n")]='\0';
        if(!strcmp(line,"seconds")) *sec=strtod(eq,NULL);
        else if(!strcmp(line,"tested")) s->tested=strtoull(eq,NULL,10);
        else if(!strcmp(line,"to1")) s->to1=strtoull(eq,NULL,10);
        else if(!strcmp(line,"to2")) s->to2=strtoull(eq,NULL,10);
        else if(!strcmp(line,"to4")) s->to4=strtoull(eq,NULL,10);
        else if(!strcmp(line,"unknown")) s->unknown=strtoull(eq,NULL,10);
        else if(!strcmp(line,"overflow")) s->overflow=strtoull(eq,NULL,10);
        else if(!strcmp(line,"total_steps")) str_to_u128(eq,&s->total_steps);
        else if(!strcmp(line,"total_v3")) str_to_u128(eq,&s->total_v3);
        else if(!strcmp(line,"max_steps")) s->max_steps=strtoull(eq,NULL,10);
        else if(!strcmp(line,"max_steps_start")) s->max_steps_start=strtoull(eq,NULL,10);
        else if(!strcmp(line,"max_v3")) s->max_v3=strtoull(eq,NULL,10);
        else if(!strcmp(line,"max_v3_start")) s->max_v3_start=strtoull(eq,NULL,10);
        else if(!strcmp(line,"max_peak")) str_to_u128(eq,&s->max_peak);
        else if(!strcmp(line,"max_peak_start")) s->max_peak_start=strtoull(eq,NULL,10);
        else if(!strcmp(line,"unknown_start")) s->unknown_start=strtoull(eq,NULL,10);
        else if(!strcmp(line,"unknown_state")) str_to_u128(eq,&s->unknown_state);
    }
    fclose(f); return 1;
}

static void show_chunk(uint64_t idx,uint64_t chunks,uint64_t lo,uint64_t hi,double sec,
                       const Stats *c,const Stats *session) {
    char peak[64], st[64], tv[64], sp[64];
    u128_to_str(c->max_peak,peak,sizeof(peak));
    u128_to_str(session->total_steps,st,sizeof(st));
    u128_to_str(session->total_v3,tv,sizeof(tv));
    u128_to_str(session->max_peak,sp,sizeof(sp));
    double pct=100.0*(double)idx/(double)chunks;
    printf("\nchunk:          %" PRIu64 " / %" PRIu64 "   (%.2f%% complete)\n",idx,chunks,pct);
    printf("n-range:        [%" PRIu64 ", %" PRIu64 "]\n",lo,hi);
    printf("chunk starts:   %" PRIu64 "\n",c->tested);
    printf("chunk seconds:  %.3f\n",sec);
    printf("chunk rate:     %.0f starts/sec\n",sec>0?(double)c->tested/sec:0.0);
    printf("outcomes:       1=%" PRIu64 "  2=%" PRIu64 "  cycle4=%" PRIu64 "  new=%" PRIu64 "  ovf=%" PRIu64 "\n",
           c->to1,c->to2,c->to4,c->unknown,c->overflow);
    printf("chunk max steps: n=%" PRIu64 " steps=%" PRIu64 "\n",c->max_steps_start,c->max_steps);
    printf("chunk max v3:    n=%" PRIu64 " v3=%" PRIu64 "\n",c->max_v3_start,c->max_v3);
    printf("chunk max peak:  n=%" PRIu64 " peak=%s\n",c->max_peak_start,peak);
    printf("session totals:\n");
    printf("starts:         %" PRIu64 "\n",session->tested);
    printf("to 1:           %" PRIu64 "\n",session->to1);
    printf("to 2:           %" PRIu64 "\n",session->to2);
    printf("cycle4:         %" PRIu64 "\n",session->to4);
    printf("new:            %" PRIu64 "\n",session->unknown);
    printf("overflow:       %" PRIu64 "\n",session->overflow);
    printf("total steps:    %s\n",st);
    printf("total v3:       %s\n",tv);
    printf("max steps:      n=%" PRIu64 " steps=%" PRIu64 "\n",session->max_steps_start,session->max_steps);
    printf("max v3:         n=%" PRIu64 " v3=%" PRIu64 "\n",session->max_v3_start,session->max_v3);
    printf("max peak:       n=%" PRIu64 " peak=%s\n",session->max_peak_start,sp);
    fflush(stdout);
}

int main(int argc,char **argv) {
    if(argc!=6) {
        fprintf(stderr,"Usage: %s START END CHUNK THREADS RESULTS_DIR\n",argv[0]);
        return 1;
    }
    uint64_t start=strtoull(argv[1],NULL,10), end=strtoull(argv[2],NULL,10);
    uint64_t chunk=strtoull(argv[3],NULL,10);
    int threads=atoi(argv[4]); const char *dir=argv[5];
    if(start<1 || end<start || chunk<1 || threads<1 || threads>256) {
        fprintf(stderr,"Invalid arguments.\n"); return 1;
    }
    if(!mkdir_if_needed(dir)) return 1;

    uint64_t span=end-start+1;
    uint64_t chunks=span/chunk + (span%chunk != 0);
    Stats session; memset(&session,0,sizeof(session));

    printf("TERNARY (4k-1(2))/3 CHUNKED 128-BIT SCAN - PERFORMANCE V2\n");
    printf("range:   [%" PRIu64 ", %" PRIu64 "]\nchunk:   %" PRIu64 " raw integers\nthreads: %d\nresults: %s\n",
           start,end,chunk,threads,dir);

    for(uint64_t idx=1; idx<=chunks; ++idx) {
        uint64_t lo=start+(idx-1)*chunk;
        uint64_t hi=(end-lo+1<chunk)?end:lo+chunk-1;
        Stats cs; double sec=0.0;

        if(load_done(dir,idx,&cs,&sec)) {
            merge(&session,&cs);
            printf("\n[resume] chunk %" PRIu64 " already complete; loaded checkpoint.\n",idx);
            show_chunk(idx,chunks,lo,hi,sec,&cs,&session);
            continue;
        }

        ChunkCtx ctx; ctx.lo=lo; ctx.hi=hi; atomic_init(&ctx.next_raw,lo);
        pthread_t *tid=malloc((size_t)threads*sizeof(*tid));
        Stats *locals=calloc((size_t)threads,sizeof(*locals));
        WorkerArg *args=malloc((size_t)threads*sizeof(*args));
        if(!tid || !locals || !args) { fprintf(stderr,"Allocation failed.\n"); return 1; }

        struct timespec t0,t1; clock_gettime(CLOCK_MONOTONIC,&t0);
        for(int i=0;i<threads;++i) {
            args[i].ctx=&ctx; args[i].s=&locals[i];
            if(pthread_create(&tid[i],NULL,worker,&args[i])!=0) { fprintf(stderr,"pthread_create failed.\n"); return 1; }
        }
        for(int i=0;i<threads;++i) pthread_join(tid[i],NULL);
        clock_gettime(CLOCK_MONOTONIC,&t1);
        sec=(double)(t1.tv_sec-t0.tv_sec)+(double)(t1.tv_nsec-t0.tv_nsec)/1e9;

        memset(&cs,0,sizeof(cs));
        for(int i=0;i<threads;++i) merge(&cs,&locals[i]);
        free(tid); free(locals); free(args);

        if(!save_done(dir,idx,lo,hi,sec,&cs)) {
            fprintf(stderr,"Could not save checkpoint for chunk %" PRIu64 ".\n",idx);
            return 1;
        }
        merge(&session,&cs);
        show_chunk(idx,chunks,lo,hi,sec,&cs,&session);
    }

    char st[64],tv[64],pk[64];
    u128_to_str(session.total_steps,st,sizeof(st)); u128_to_str(session.total_v3,tv,sizeof(tv));
    u128_to_str(session.max_peak,pk,sizeof(pk));
    printf("\n============================================================\nFINAL NEW-RANGE TOTALS\n");
    printf("starts=%" PRIu64 "  1=%" PRIu64 "  2=%" PRIu64 "  cycle4=%" PRIu64 "  new=%" PRIu64 "  ovf=%" PRIu64 "\n",
           session.tested,session.to1,session.to2,session.to4,session.unknown,session.overflow);
    printf("total_steps=%s  total_v3=%s\n",st,tv);
    printf("max_steps: n=%" PRIu64 " steps=%" PRIu64 "\n",session.max_steps_start,session.max_steps);
    printf("max_v3:    n=%" PRIu64 " v3=%" PRIu64 "\n",session.max_v3_start,session.max_v3);
    printf("max_peak:  n=%" PRIu64 " peak=%s\n",session.max_peak_start,pk);
    printf("============================================================\n");
    return 0;
}
