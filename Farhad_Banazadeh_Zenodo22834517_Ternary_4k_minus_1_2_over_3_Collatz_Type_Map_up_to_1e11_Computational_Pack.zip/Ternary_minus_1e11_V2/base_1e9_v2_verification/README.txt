Supplementary V2 base verification
==================================

This directory contains ten V2 checkpoint files covering 1 <= x <= 10^9.
They were generated with the same V2 scanner source included at the archive root.
Their aggregate reproduces the published 10^9 attractor counts and extrema and
supplies exact aggregate total_steps and total_v3 values used in the 10^11 paper.

Reproduction command (thread count may be changed without changing results):

  ./scan_ternary_minus_1e11_v2 1 1000000000 100000000 4 base_1e9_v2_verification

The earlier 10^9 publication remains independently citable at:
  https://doi.org/10.5281/zenodo.22662980
