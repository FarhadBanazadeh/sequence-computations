#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <signal.h>
#include <sys/stat.h>
#include <errno.h>

#if !defined(__SIZEOF_INT128__)
#error "Requires compiler support for unsigned __int128."
#endif

typedef unsigned __int128 u128;

typedef struct {
    uint64_t count[4];
    uint64_t unknown;
    uint64_t max_steps, max_steps_start;
    u128 max_steps_peak;
    u128 max_peak;
    uint64_t max_peak_start, max_peak_steps;
} Stats;

typedef struct {
    uint64_t first;
    uint64_t count;
    Stats stats;
    FILE *unknown_file;
    pthread_mutex_t *unknown_mutex;
} Worker;

static volatile sig_atomic_t stop_requested = 0;
static void on_signal(int sig){ (void)sig; stop_requested = 1; }

static inline unsigned ctz128(u128 x){
    uint64_t lo=(uint64_t)x;
    if(lo) return (unsigned)__builtin_ctzll(lo);
    return 64u+(unsigned)__builtin_ctzll((uint64_t)(x>>64));
}

static inline u128 T(u128 n){
    u128 m=5u*n+(((n&3u)==1u)?3u:1u);
    return m>>ctz128(m);
}

static inline int known(u128 n){
    if(n > UINT64_MAX) return -1;
    switch((uint64_t)n){
        case 1:return 0;
        case 31: case 39: case 49:return 1;
        case 37: case 47: case 59:return 2;
        case 61: case 77: case 97:return 3;
        default:return -1;
    }
}

static void u128str(u128 x,char b[64]){
    char t[64]; int i=0,j=0;
    if(!x){strcpy(b,"0");return;}
    while(x){t[i++]=(char)('0'+x%10);x/=10;}
    while(i) b[j++]=t[--i];
    b[j]=0;
}

static u128 parse_u128(const char *s){
    u128 x=0;
    while(*s>='0'&&*s<='9'){x=x*10+(unsigned)(*s-'0');s++;}
    return x;
}

static int mkdir_p(const char *path){
    if(mkdir(path,0755)==0 || errno==EEXIST) return 0;
    return -1;
}

static void merge(Stats *a,const Stats *b){
    for(int i=0;i<4;i++) a->count[i]+=b->count[i];
    a->unknown+=b->unknown;
    if(b->max_steps>a->max_steps){
        a->max_steps=b->max_steps;
        a->max_steps_start=b->max_steps_start;
        a->max_steps_peak=b->max_steps_peak;
    }
    if(b->max_peak>a->max_peak){
        a->max_peak=b->max_peak;
        a->max_peak_start=b->max_peak_start;
        a->max_peak_steps=b->max_peak_steps;
    }
}

/* Correct Brent cycle detection, while the main trajectory itself is traversed once.
   Returns 0..3 for known cycle, -1 for a newly detected/overlong cycle. */
static int scan_one(uint64_t s,uint64_t *steps,u128 *peak){
    u128 start=(u128)s;
    int cid=known(start);
    if(cid>=0){*steps=0;*peak=start;return cid;}

    u128 p=start;
    u128 tortoise=start;
    u128 hare=T(start);
    uint64_t k=1, power=1, lam=1;
    if(hare>p)p=hare;

    for(;;){
        cid=known(hare);
        if(cid>=0){*steps=k;*peak=p;return cid;}
        if(tortoise==hare){*steps=k;*peak=p;return -1;}
        if(k>=10000000ULL){*steps=k;*peak=p;return -1;}
        if(power==lam){
            tortoise=hare;
            if(power <= UINT64_MAX/2) power <<= 1; else power=UINT64_MAX;
            lam=0;
        }
        hare=T(hare); k++; lam++;
        if(hare>p)p=hare;
    }
}

static void *worker_main(void *vp){
    Worker *w=(Worker*)vp;
    Stats st={0};
    for(uint64_t i=0;i<w->count && !stop_requested;i++){
        uint64_t s=w->first+2*i;
        uint64_t steps=0; u128 peak=0;
        int cid=scan_one(s,&steps,&peak);
        if(cid>=0){
            st.count[cid]++;
        }else{
            st.unknown++;
            if(w->unknown_file){
                char pb[64]; u128str(peak,pb);
                pthread_mutex_lock(w->unknown_mutex);
                fprintf(w->unknown_file,"%"PRIu64",%"PRIu64",%s\n",s,steps,pb);
                fflush(w->unknown_file);
                pthread_mutex_unlock(w->unknown_mutex);
            }
        }
        if(steps>st.max_steps){
            st.max_steps=steps; st.max_steps_start=s; st.max_steps_peak=peak;
        }
        if(peak>st.max_peak){
            st.max_peak=peak; st.max_peak_start=s; st.max_peak_steps=steps;
        }
    }
    w->stats=st;
    return NULL;
}

static int save_state(const char *path,uint64_t next,const Stats *s){
    char tmp[1024], peak[64], steppeak[64];
    snprintf(tmp,sizeof tmp,"%s.tmp",path);
    u128str(s->max_peak,peak); u128str(s->max_steps_peak,steppeak);
    FILE *f=fopen(tmp,"w"); if(!f)return -1;
    fprintf(f,"%"PRIu64" %"PRIu64" %"PRIu64" %"PRIu64" %"PRIu64" %"PRIu64" %"PRIu64" %"PRIu64" %s %"PRIu64" %"PRIu64" %s\n",
            next,s->count[0],s->count[1],s->count[2],s->count[3],s->unknown,
            s->max_steps,s->max_steps_start,steppeak,s->max_peak_start,s->max_peak_steps,peak);
    fflush(f); fclose(f);
    return rename(tmp,path);
}

static int load_state(const char *path,uint64_t *next,Stats *s){
    FILE *f=fopen(path,"r"); if(!f)return -1;
    char peak[64], steppeak[64];
    Stats x={0}; uint64_t n=0;
    int nr=fscanf(f,"%"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64" %63s %"SCNu64" %"SCNu64" %63s",
                  &n,&x.count[0],&x.count[1],&x.count[2],&x.count[3],&x.unknown,
                  &x.max_steps,&x.max_steps_start,steppeak,&x.max_peak_start,&x.max_peak_steps,peak);
    fclose(f);
    if(nr!=12)return -1;
    x.max_steps_peak=parse_u128(steppeak); x.max_peak=parse_u128(peak);
    *next=n; *s=x; return 0;
}

int main(int argc,char **argv){
    uint64_t start=1, stop=10000000000ULL, chunk=10000000ULL;
    int threads=4;
    const char *out="results_1e10_pthread";
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"--start")&&i+1<argc) start=strtoull(argv[++i],0,10);
        else if(!strcmp(argv[i],"--stop")&&i+1<argc) stop=strtoull(argv[++i],0,10);
        else if(!strcmp(argv[i],"--chunk-starts")&&i+1<argc) chunk=strtoull(argv[++i],0,10);
        else if(!strcmp(argv[i],"--threads")&&i+1<argc) threads=atoi(argv[++i]);
        else if(!strcmp(argv[i],"--out")&&i+1<argc) out=argv[++i];
        else {fprintf(stderr,"Usage: %s [--start N] [--stop N] [--threads N] [--chunk-starts N] [--out DIR]\n",argv[0]);return 2;}
    }
    if(start<1)start=1;
    if(!(start&1))start++;
    if(!(stop&1))stop--;
    if(start>stop || threads<1 || chunk<1){fprintf(stderr,"Invalid range/options.\n");return 2;}
    if(threads>256)threads=256;

    signal(SIGINT,on_signal); signal(SIGTERM,on_signal);
    if(mkdir_p(out)!=0){perror("mkdir");return 1;}

    char statep[1024],recordp[1024],unknownp[1024],summaryp[1024];
    snprintf(statep,sizeof statep,"%s/state_pthread.txt",out);
    snprintf(recordp,sizeof recordp,"%s/records_pthread.csv",out);
    snprintf(unknownp,sizeof unknownp,"%s/unknown_cycles_pthread.csv",out);
    snprintf(summaryp,sizeof summaryp,"%s/summary_pthread.json",out);

    uint64_t next=start; Stats total={0};
    (void)load_state(statep,&next,&total);
    if(next<start)next=start;
    if(!(next&1))next++;

    FILE *rf=fopen(recordp,"a+"); FILE *uf=fopen(unknownp,"a+");
    if(!rf||!uf){perror("output");return 1;}
    fseek(rf,0,SEEK_END); if(ftell(rf)==0)fprintf(rf,"kind,start,steps,peak,cycle\n");
    fseek(uf,0,SEEK_END); if(ftell(uf)==0)fprintf(uf,"start,steps,peak\n");

    pthread_mutex_t unknown_mutex=PTHREAD_MUTEX_INITIALIZER;
    time_t all_t0=time(NULL);

    while(next<=stop && !stop_requested){
        uint64_t starts_left=(stop-next)/2+1;
        uint64_t this_chunk=starts_left<chunk?starts_left:chunk;
        int nt=(int)((this_chunk<(uint64_t)threads)?this_chunk:(uint64_t)threads);
        pthread_t *ids=(pthread_t*)calloc((size_t)nt,sizeof(*ids));
        Worker *ws=(Worker*)calloc((size_t)nt,sizeof(*ws));
        if(!ids||!ws){fprintf(stderr,"Out of memory.\n");return 1;}

        uint64_t base=this_chunk/(uint64_t)nt, rem=this_chunk%(uint64_t)nt, off=0;
        time_t t0=time(NULL);
        for(int t=0;t<nt;t++){
            uint64_t cnt=base+(t<(int)rem?1:0);
            ws[t].first=next+2*off; ws[t].count=cnt;
            ws[t].unknown_file=uf; ws[t].unknown_mutex=&unknown_mutex;
            off+=cnt;
            if(pthread_create(&ids[t],NULL,worker_main,&ws[t])!=0){fprintf(stderr,"pthread_create failed\n");return 1;}
        }
        Stats chunk_total={0};
        for(int t=0;t<nt;t++){pthread_join(ids[t],NULL);merge(&chunk_total,&ws[t].stats);}
        free(ids); free(ws);

        if(chunk_total.max_steps>total.max_steps){
            char pb[64]; u128str(chunk_total.max_steps_peak,pb);
            fprintf(rf,"max_steps,%"PRIu64",%"PRIu64",%s,-1\n",chunk_total.max_steps_start,chunk_total.max_steps,pb); fflush(rf);
        }
        if(chunk_total.max_peak>total.max_peak){
            char pb[64]; u128str(chunk_total.max_peak,pb);
            fprintf(rf,"max_peak,%"PRIu64",%"PRIu64",%s,-1\n",chunk_total.max_peak_start,chunk_total.max_peak_steps,pb); fflush(rf);
        }
        merge(&total,&chunk_total);

        uint64_t completed=chunk_total.count[0]+chunk_total.count[1]+chunk_total.count[2]+chunk_total.count[3]+chunk_total.unknown;
        next += 2*completed;
        save_state(statep,next,&total);

        uint64_t done=total.count[0]+total.count[1]+total.count[2]+total.count[3]+total.unknown;
        double sec=difftime(time(NULL),t0); if(sec<1)sec=1;
        fprintf(stderr,"done=%"PRIu64" next=%"PRIu64" chunk_rate=%.0f starts/s unknown=%"PRIu64"\n",
                done,next,completed/sec,total.unknown);
        if(completed<this_chunk) break;
    }

    char peak[64], steppeak[64]; u128str(total.max_peak,peak); u128str(total.max_steps_peak,steppeak);
    uint64_t done=total.count[0]+total.count[1]+total.count[2]+total.count[3]+total.unknown;
    FILE *js=fopen(summaryp,"w");
    if(js){
        fprintf(js,"{\n");
        fprintf(js,"  \"rule\": \"T(n)=odd(5n+c), c=3 if n mod 4=1, c=1 if n mod 4=3\",\n");
        fprintf(js,"  \"backend\": \"unsigned __int128 + POSIX pthreads\",\n");
        fprintf(js,"  \"threads\": %d,\n",threads);
        fprintf(js,"  \"requested_start\": %"PRIu64",\n",start);
        fprintf(js,"  \"requested_stop\": %"PRIu64",\n",stop);
        fprintf(js,"  \"processed\": %"PRIu64",\n",done);
        fprintf(js,"  \"cycle_counts\": {\"1\": %"PRIu64", \"31-39-49\": %"PRIu64", \"37-47-59\": %"PRIu64", \"61-77-97\": %"PRIu64"},\n",total.count[0],total.count[1],total.count[2],total.count[3]);
        fprintf(js,"  \"unknown\": %"PRIu64",\n",total.unknown);
        fprintf(js,"  \"max_steps\": %"PRIu64",\n",total.max_steps);
        fprintf(js,"  \"max_steps_start\": %"PRIu64",\n",total.max_steps_start);
        fprintf(js,"  \"max_steps_peak\": \"%s\",\n",steppeak);
        fprintf(js,"  \"max_peak\": \"%s\",\n",peak);
        fprintf(js,"  \"max_peak_start\": %"PRIu64",\n",total.max_peak_start);
        fprintf(js,"  \"max_peak_steps\": %"PRIu64",\n",total.max_peak_steps);
        fprintf(js,"  \"interrupted\": %s,\n",stop_requested?"true":"false");
        fprintf(js,"  \"elapsed_seconds_this_invocation\": %.0f\n",difftime(time(NULL),all_t0));
        fprintf(js,"}\n"); fclose(js);
    }
    fclose(rf); fclose(uf);
    fprintf(stderr,"Done. Results in %s\n",out);
    return stop_requested?130:0;
}
