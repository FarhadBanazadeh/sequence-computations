#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <signal.h>

#if !defined(__SIZEOF_INT128__)
#error "This program requires compiler support for unsigned __int128 (GCC/Clang)."
#endif

typedef unsigned __int128 u128;

typedef struct {
    uint64_t start;
    uint64_t stop;
    uint64_t checkpoint_every;
    uint64_t progress_every;
    int full_trace;
    const char *outdir;
} Config;

static volatile sig_atomic_t stop_requested = 0;

static void on_signal(int sig) { (void)sig; stop_requested = 1; }

static inline int u128_cmp(u128 a, u128 b){ return (a>b) - (a<b); }

static void u128_to_str(u128 x, char *buf, size_t n) {
    char tmp[64]; size_t i = 0;
    if (x == 0) { snprintf(buf,n,"0"); return; }
    while (x && i < sizeof(tmp)-1) { tmp[i++] = (char)('0' + x % 10); x /= 10; }
    size_t j=0; while(i && j+1<n) buf[j++] = tmp[--i]; buf[j]='\0';
}

static inline unsigned ctz_u128(u128 x) {
    uint64_t lo = (uint64_t)x;
    if (lo) return (unsigned)__builtin_ctzll(lo);
    uint64_t hi = (uint64_t)(x >> 64);
    return 64u + (unsigned)__builtin_ctzll(hi);
}

// T(n)=odd(5n+c), where c=3 for n=1 mod 4, c=1 for n=3 mod 4.
// n is always odd; 5n+c is always divisible by at least 4.
static inline u128 step(u128 n, unsigned *v2_out) {
    u128 c = ((n & 3u) == 1u) ? 3u : 1u;
    u128 m = 5u*n + c;
    unsigned z = ctz_u128(m);
    if (v2_out) *v2_out = z;
    return m >> z;
}

static int is_known_cycle_member(u128 n, int *cid) {
    static const uint64_t cyc0[] = {1};
    static const uint64_t cyc1[] = {31,39,49};
    static const uint64_t cyc2[] = {37,47,59};
    static const uint64_t cyc3[] = {61,77,97};
    const uint64_t *arrs[] = {cyc0,cyc1,cyc2,cyc3};
    const int lens[] = {1,3,3,3};
    for(int i=0;i<4;i++) for(int j=0;j<lens[i];j++) if(n==(u128)arrs[i][j]) { if(cid)*cid=i; return 1; }
    return 0;
}

static int mkdir_p(const char *path) {
    char cmd[1024];
    if (snprintf(cmd,sizeof(cmd),"mkdir -p '%s'",path) >= (int)sizeof(cmd)) return -1;
    return system(cmd);
}

static int load_checkpoint(const char *path, uint64_t *next_n) {
    FILE *f=fopen(path,"r"); if(!f) return -1;
    unsigned long long x=0; int ok=fscanf(f,"%llu",&x); fclose(f);
    if(ok==1){ *next_n=(uint64_t)x; return 0; } return -1;
}

static int save_checkpoint(const char *path, uint64_t next_n) {
    char tmp[1024]; snprintf(tmp,sizeof(tmp),"%s.tmp",path);
    FILE *f=fopen(tmp,"w"); if(!f) return -1;
    fprintf(f,"%" PRIu64 "\n",next_n);
    fflush(f); fclose(f);
    return rename(tmp,path);
}

static void usage(const char *p){
    fprintf(stderr,"Usage: %s [--start N] [--stop N] [--out DIR] [--checkpoint-every N] [--progress-every N] [--full-trace]\n",p);
}

int main(int argc,char **argv){
    Config cfg={1,10000000000ULL,1000000ULL,5000000ULL,0,"results"};
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"--start") && i+1<argc) cfg.start=strtoull(argv[++i],0,10);
        else if(!strcmp(argv[i],"--stop") && i+1<argc) cfg.stop=strtoull(argv[++i],0,10);
        else if(!strcmp(argv[i],"--out") && i+1<argc) cfg.outdir=argv[++i];
        else if(!strcmp(argv[i],"--checkpoint-every") && i+1<argc) cfg.checkpoint_every=strtoull(argv[++i],0,10);
        else if(!strcmp(argv[i],"--progress-every") && i+1<argc) cfg.progress_every=strtoull(argv[++i],0,10);
        else if(!strcmp(argv[i],"--full-trace")) cfg.full_trace=1;
        else { usage(argv[0]); return 2; }
    }
    if(cfg.start<1) cfg.start=1;
    if((cfg.start&1)==0) cfg.start++;
    if((cfg.stop&1)==0) cfg.stop--;
    if(cfg.start>cfg.stop){ fprintf(stderr,"Empty odd range.\n"); return 2; }

    signal(SIGINT,on_signal); signal(SIGTERM,on_signal);
    if(mkdir_p(cfg.outdir)!=0){ fprintf(stderr,"Cannot create output directory.\n"); return 1; }

    char p_summary[1024],p_records[1024],p_unknown[1024],p_trace[1024],p_ckpt[1024];
    snprintf(p_summary,sizeof p_summary,"%s/summary.json",cfg.outdir);
    snprintf(p_records,sizeof p_records,"%s/records.csv",cfg.outdir);
    snprintf(p_unknown,sizeof p_unknown,"%s/unknown_cycles.csv",cfg.outdir);
    snprintf(p_trace,sizeof p_trace,"%s/full_trace.csv",cfg.outdir);
    snprintf(p_ckpt,sizeof p_ckpt,"%s/checkpoint.txt",cfg.outdir);

    FILE *fr=fopen(p_records,"a+"); if(!fr){perror("records");return 1;}
    fseek(fr,0,SEEK_END); if(ftell(fr)==0) fprintf(fr,"kind,start,steps,peak,terminal_cycle\n");
    FILE *fu=fopen(p_unknown,"a+"); if(!fu){perror("unknown");return 1;}
    fseek(fu,0,SEEK_END); if(ftell(fu)==0) fprintf(fu,"start,meeting_value,steps\n");
    FILE *ft=NULL;
    if(cfg.full_trace){ ft=fopen(p_trace,"a+"); if(!ft){perror("trace");return 1;} fseek(ft,0,SEEK_END); if(ftell(ft)==0) fprintf(ft,"start,step_index,value,v2\n"); }

    uint64_t begin=cfg.start, ck=0;
    if(load_checkpoint(p_ckpt,&ck)==0 && ck>=cfg.start && ck<=cfg.stop) begin=(ck&1)?ck:ck+1;

    uint64_t counts[4]={0,0,0,0}, unknown=0, processed=0;
    uint64_t max_steps=0, max_steps_start=0;
    u128 global_peak=0; uint64_t global_peak_start=0;
    time_t t0=time(NULL);

    for(uint64_t s=begin; s<=cfg.stop; s+=2){
        if(stop_requested) break;
        u128 n=(u128)s, peak=n;
        uint64_t steps=0;
        int cid=-1;

        // Floyd cycle detection while also respecting known terminal cycles.
        u128 tort=n, hare=n;
        int resolved=0;
        for(;;){
            if(is_known_cycle_member(n,&cid)){ resolved=1; break; }
            unsigned z=0;
            u128 next=step(n,&z);
            if(ft){ char vb[64]; u128_to_str(n,vb,sizeof vb); fprintf(ft,"%" PRIu64 ",%" PRIu64 ",%s,%u\n",s,steps,vb,z); }
            n=next; steps++;
            if(u128_cmp(n,peak)>0) peak=n;

            tort=step(tort,NULL);
            hare=step(step(hare,NULL),NULL);
            if(tort==hare){
                if(is_known_cycle_member(tort,&cid)) resolved=1;
                else {
                    char mb[64]; u128_to_str(tort,mb,sizeof mb);
                    fprintf(fu,"%" PRIu64 ",%s,%" PRIu64 "\n",s,mb,steps);
                    fflush(fu); unknown++;
                }
                break;
            }
            if(steps > 10000000ULL){
                char mb[64]; u128_to_str(n,mb,sizeof mb);
                fprintf(fu,"%" PRIu64 ",%s,%" PRIu64 "\n",s,mb,steps);
                fflush(fu); unknown++; break;
            }
        }
        if(resolved && cid>=0 && cid<4) counts[cid]++;
        processed++;

        if(steps>max_steps){
            max_steps=steps; max_steps_start=s;
            char pb[64]; u128_to_str(peak,pb,sizeof pb);
            fprintf(fr,"max_steps,%" PRIu64 ",%" PRIu64 ",%s,%d\n",s,steps,pb,cid); fflush(fr);
        }
        if(u128_cmp(peak,global_peak)>0){
            global_peak=peak; global_peak_start=s;
            char pb[64]; u128_to_str(peak,pb,sizeof pb);
            fprintf(fr,"max_peak,%" PRIu64 ",%" PRIu64 ",%s,%d\n",s,steps,pb,cid); fflush(fr);
        }

        if(cfg.checkpoint_every && processed % cfg.checkpoint_every==0){ save_checkpoint(p_ckpt,s+2); }
        if(cfg.progress_every && processed % cfg.progress_every==0){
            double sec=difftime(time(NULL),t0), rate=sec>0?processed/sec:0;
            fprintf(stderr,"processed=%" PRIu64 " current=%" PRIu64 " rate=%.0f starts/s unknown=%" PRIu64 "\n",processed,s,rate,unknown);
        }
        if(s > cfg.stop-2) break; // avoid uint64 wrap
    }

    uint64_t next = begin + processed*2;
    if(next<=cfg.stop) save_checkpoint(p_ckpt,next); else save_checkpoint(p_ckpt,cfg.stop+2);

    char peakbuf[64]; u128_to_str(global_peak,peakbuf,sizeof peakbuf);
    FILE *fs=fopen(p_summary,"w");
    if(fs){
        fprintf(fs,"{\n");
        fprintf(fs,"  \"rule\": \"T(n)=odd(5n+c), c=3 if n mod 4=1, c=1 if n mod 4=3\",\n");
        fprintf(fs,"  \"integer_backend\": \"unsigned __int128\",\n");
        fprintf(fs,"  \"requested_start\": %" PRIu64 ",\n",cfg.start);
        fprintf(fs,"  \"requested_stop\": %" PRIu64 ",\n",cfg.stop);
        fprintf(fs,"  \"processed_this_run\": %" PRIu64 ",\n",processed);
        fprintf(fs,"  \"cycle_counts_this_run\": {\"1\": %" PRIu64 ", \"31-39-49\": %" PRIu64 ", \"37-47-59\": %" PRIu64 ", \"61-77-97\": %" PRIu64 "},\n",counts[0],counts[1],counts[2],counts[3]);
        fprintf(fs,"  \"unknown_cycle_hits_this_run\": %" PRIu64 ",\n",unknown);
        fprintf(fs,"  \"max_steps_this_run\": %" PRIu64 ",\n",max_steps);
        fprintf(fs,"  \"max_steps_start_this_run\": %" PRIu64 ",\n",max_steps_start);
        fprintf(fs,"  \"max_peak_this_run\": \"%s\",\n",peakbuf);
        fprintf(fs,"  \"max_peak_start_this_run\": %" PRIu64 ",\n",global_peak_start);
        fprintf(fs,"  \"interrupted\": %s\n",stop_requested?"true":"false");
        fprintf(fs,"}\n"); fclose(fs);
    }
    if(ft) fclose(ft);
    fclose(fu);
    fclose(fr);
    fprintf(stderr,"Done. Results in %s\n",cfg.outdir);
    return stop_requested?130:0;
}
