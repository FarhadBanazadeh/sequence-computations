# Zenodo Reproducibility Pack: 5k+1(3)/4 Collatz-Type Domain

Author: Farhad Banazadeh  
Email: fn.bana@hotmail.com  
ORCID: 0009-0004-7023-0298  
Date: 10 September 2026

## Map
For positive odd x:

- if x ≡ 1 (mod 4), use N(x)=5x+3;
- if x ≡ 3 (mod 4), use N(x)=5x+1;
- set T(x)=N(x)/2^v2(N(x)), removing all factors of 2.

The four observed attractors are {1}, {31,39,49}, {37,47,59}, and {61,77,97}.

## Main finite result
Every positive odd start x < 10^10 was exhaustively tested: 5,000,000,000 starts. All entered one of the four displayed attractors; unknown=0.

## Contents
- `5k1_3_over4_article.tex` and `.pdf`: paper source and compiled paper.
- `article/`: LaTeX build copy.
- `code/seq5_scan_pthread.c`: macOS/POSIX-threaded production scanner.
- `code/seq5_scan.c`: single-thread reference scanner.
- `results/cutoff_summary.csv`: consolidated cutoff table.
- `results/summary_*.json`: exact scan summaries.
- `results/records_1e10.csv`: record-breaking stopping-time/peak events from the full scan.
- `results/unknown_cycles_1e10.csv`: header-only file, corresponding to zero unknown cycles.
- `zenodo_metadata.json`: suggested deposit metadata.
- `CITATION.cff`: citation metadata.
- `SHA256SUMS.txt`: integrity hashes.

## Build on macOS
```bash
clang -O3 -march=native -std=c11 -Wall -Wextra -DNDEBUG -pthread \
  code/seq5_scan_pthread.c -o seq5_scan_pthread
```

## Full exhaustive run
```bash
./seq5_scan_pthread \
  --start 1 \
  --stop 10000000000 \
  --threads 4 \
  --chunk-starts 10000000 \
  --out results_1e10_pthread
```

The scanner is checkpoint/resume capable. If interrupted, rerun the same command with the same output directory.

## Compile the paper
```bash
pdflatex 5k1_3_over4_article.tex
pdflatex 5k1_3_over4_article.tex
```

## Scientific scope
The exhaustive result is a finite-range computational theorem about the executed search. The statement that the four displayed cycles are the only global attractors is presented as the Four-Attractor Conjecture, not as a proof.

## Provenance of the 10^10 production results
The files `results/summary_1e10.json`, `results/records_1e10.csv`,
`results/unknown_cycles_1e10.csv`, and `results/state_1e10.txt` are copied
verbatim from the uploaded macOS production run archive (`seq5_pack.zip`).
The archived production source `code/seq5_scan_pthread.c` is likewise copied
from that run archive. This preserves the exact computational evidence used
for the paper.
