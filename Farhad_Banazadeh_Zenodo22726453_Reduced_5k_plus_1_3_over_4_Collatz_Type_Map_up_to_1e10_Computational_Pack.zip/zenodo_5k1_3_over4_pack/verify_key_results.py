import json
from pathlib import Path
p=Path(__file__).resolve().parent
s=json.loads((p/'results/summary_1e10.json').read_text())
assert s['processed']==5_000_000_000
assert sum(s['cycle_counts'].values())==s['processed']
assert s['unknown']==0
assert s['max_steps']==194 and s['max_steps_start']==9_614_632_545
assert int(s['max_peak'])==17_570_609_003_297 and s['max_peak_start']==9_123_181_791
cycles=[
    [1],
    [31,39,49],
    [37,47,59],
    [61,77,97],
]
def T(x):
    c=3 if x%4==1 else 1
    y=5*x+c
    while y%2==0: y//=2
    return y
for cyc in cycles:
    for i,x in enumerate(cyc):
        assert T(x)==cyc[(i+1)%len(cyc)]
print('All archived key-result and cycle checks passed.')
