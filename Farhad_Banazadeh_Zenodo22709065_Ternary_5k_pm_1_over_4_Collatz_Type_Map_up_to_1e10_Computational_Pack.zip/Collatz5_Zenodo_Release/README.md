# Reduced 5x±1 Collatz-Type Map — Zenodo Reproducibility Archive

## Scope

This archive accompanies:

**A Reduced 5x±1 Collatz-Type Map with Two Observed Attractors:
Algebraic Structure and Exhaustive Computational Verification up to 10^10**

Author line in manuscript: Farhad B.
Version: 1.0
Date: 2026-09-10

## Map

For each positive odd integer x,

- if x ≡ 1 (mod 4), set N(x) = 5x - 1;
- if x ≡ 3 (mod 4), set N(x) = 5x + 1;

then define T(x) by dividing N(x) by all powers of 2.

The two displayed exact periodic attractors are:

- fixed point: 1;
- three-cycle: 7 -> 9 -> 11 -> 7.

## Main exhaustive result

All 5,000,000,000 positive odd starting values x < 10^10 were tested.

- resolved: 5,000,000,000
- unresolved: 0
- basin of 1: 3,599,424,753 (71.988495060%)
- basin of 7-9-11: 1,400,575,247 (28.011504940%)
- mean stopping time: 43.775639881800
- maximum stopping time: 174, start 8,793,787,045
- maximum reduced odd peak: 11,134,926,214,451, start 9,250,534,785
- maximum raw affine peak: 55,674,631,072,256, same start
- maximum v2 observed: 34
- maximum reduced-peak/start ratio: 3673.419845666274

IMPORTANT: these are finite-range computational statements. They do not prove
global convergence or exclude all cycles outside the tested range.

## Stopping convention

Stopping time is the number of reduced-map applications until first entry into
{1} or {7,9,11}. A start already in an attractor has stopping time 0.

## Build

Recorded compiler environment:

Apple LLVM version 10.0.0
Target: x86_64-apple-darwin17.7.0

Production scan:

    clang -O3 -march=native collatz5_scan_1e10.c -o collatz5_scan_1e10
    time ./collatz5_scan_1e10 10000000000 | tee collatz5_1e10.txt

Deep scan:

    clang -O3 -march=native collatz5_deep_scan.c -o collatz5_deep_scan
    time ./collatz5_deep_scan 10000000000 | tee collatz5_deep_1e10.txt

## Archive contents

The source code, raw saved terminal outputs, CSV/JSON summaries, manuscript source,
compiled article PDF, and checksums are included.

Platform-specific executable binaries from the original working folder are not
included in this curated archive; compile from source instead.

## Preservation note

`original_computation_archive.zip` is the exact ZIP supplied for this release, preserved unchanged inside the curated package.
