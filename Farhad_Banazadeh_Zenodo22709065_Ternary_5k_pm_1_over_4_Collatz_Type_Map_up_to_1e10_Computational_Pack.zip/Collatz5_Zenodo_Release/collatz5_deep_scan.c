// collatz5_deep_scan.c
// Exhaustive analysis of the odd-only 5x±1 map:
// x ≡ 1 (mod 4): N=5x-1
// x ≡ 3 (mod 4): N=5x+1
// T(x)=N/2^v2(N)
//
// Compile on macOS:
// clang -O3 -march=native collatz5_deep_scan.c -o collatz5_deep_scan
//
// Run:
// ./collatz5_deep_scan 10000000000 | tee collatz5_deep_1e10.txt

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <inttypes.h>
#include <time.h>

typedef unsigned __int128 u128;

#define HIST_MAX 10000

static inline unsigned v2_u128(u128 n) {
    unsigned c = 0;
    while ((n & 1) == 0) {
        n >>= 1;
        ++c;
    }
    return c;
}

static void print_u128(u128 x) {
    if (x == 0) { putchar('0'); return; }
    char buf[64];
    int i = 0;
    while (x) {
        buf[i++] = (char)('0' + (x % 10));
        x /= 10;
    }
    while (i--) putchar(buf[i]);
}

static inline u128 next_T(u128 x, unsigned *v2_out, u128 *raw_out) {
    u128 n = ((x & 3) == 1) ? (5*x - 1) : (5*x + 1);
    unsigned v = v2_u128(n);
    if (v2_out) *v2_out = v;
    if (raw_out) *raw_out = n;
    return n >> v;
}

static int attractor_id(u128 x) {
    if (x == 1) return 1;
    if (x == 7 || x == 9 || x == 11) return 7;
    return 0;
}

static void print_orbit(uint64_t start, uint64_t max_iter) {
    u128 x = start;
    printf("\nORBIT start=%" PRIu64 "\n", start);

    for (uint64_t k = 0; k < max_iter; ++k) {
        int a = attractor_id(x);
        if (a) {
            printf("step=%" PRIu64 " x=", k);
            print_u128(x);
            printf("  [attractor %s]\n", a == 1 ? "1" : "7-9-11");
            return;
        }

        unsigned v;
        u128 raw;
        u128 y = next_T(x, &v, &raw);

        printf("step=%" PRIu64 " x=", k);
        print_u128(x);
        printf(" raw=");
        print_u128(raw);
        printf(" v2=%u next=", v);
        print_u128(y);
        putchar('\n');

        x = y;
    }
    printf("orbit did not resolve within %" PRIu64 " steps\n", max_iter);
}

int main(int argc, char **argv) {
    uint64_t limit = 10000000000ULL;
    uint64_t max_iter = 1000000ULL;

    if (argc >= 2) limit = strtoull(argv[1], NULL, 10);
    if (argc >= 3) max_iter = strtoull(argv[2], NULL, 10);

    uint64_t tested = 0, resolved = 0, unresolved = 0;
    uint64_t basin1 = 0, basin7 = 0;
    long double total_steps = 0.0L;

    uint64_t max_steps = 0, argmax_steps = 0;
    u128 max_reduced_peak = 0;
    uint64_t argmax_reduced_peak = 0;
    u128 max_raw_peak = 0;
    uint64_t argmax_raw_peak = 0;

    unsigned max_v2 = 0;
    uint64_t argmax_v2_start = 0;
    u128 argmax_v2_x = 0, argmax_v2_raw = 0;

    long double max_peak_ratio = 0.0L;
    uint64_t argmax_peak_ratio = 0;
    u128 peak_at_max_ratio = 0;

    uint64_t *hist = calloc(HIST_MAX + 1, sizeof(uint64_t));
    if (!hist) {
        fprintf(stderr, "hist allocation failed\n");
        return 1;
    }

    clock_t t0 = clock();

    uint64_t first = 1;
    uint64_t last = (limit & 1ULL) ? limit : limit - 1ULL;

    printf("map: x%%4=1 -> (5x-1)/2^v2; x%%4=3 -> (5x+1)/2^v2\n");
    printf("limit=%" PRIu64 " odd_starts=%" PRIu64 " max_iter=%" PRIu64 "\n\n",
           limit, (last + 1ULL)/2ULL, max_iter);

    for (uint64_t s = first; s <= last; s += 2ULL) {
        ++tested;

        u128 x = s;
        u128 reduced_peak = x;
        u128 raw_peak = 0;
        uint64_t steps = 0;
        int aid = 0;

        for (; steps < max_iter; ++steps) {
            aid = attractor_id(x);
            if (aid) break;

            unsigned v;
            u128 raw;
            u128 y = next_T(x, &v, &raw);

            if (raw > raw_peak) raw_peak = raw;
            if (y > reduced_peak) reduced_peak = y;

            if (v > max_v2) {
                max_v2 = v;
                argmax_v2_start = s;
                argmax_v2_x = x;
                argmax_v2_raw = raw;
            }

            x = y;
        }

        if (!aid) {
            ++unresolved;
            continue;
        }

        ++resolved;
        if (aid == 1) ++basin1;
        else ++basin7;

        total_steps += (long double)steps;

        if (steps <= HIST_MAX) ++hist[steps];

        if (steps > max_steps) {
            max_steps = steps;
            argmax_steps = s;
        }

        if (reduced_peak > max_reduced_peak) {
            max_reduced_peak = reduced_peak;
            argmax_reduced_peak = s;
        }

        if (raw_peak > max_raw_peak) {
            max_raw_peak = raw_peak;
            argmax_raw_peak = s;
        }

        long double ratio = (long double)reduced_peak / (long double)s;
        if (ratio > max_peak_ratio) {
            max_peak_ratio = ratio;
            argmax_peak_ratio = s;
            peak_at_max_ratio = reduced_peak;
        }
    }

    clock_t t1 = clock();
    double elapsed = (double)(t1 - t0) / CLOCKS_PER_SEC;

    printf("tested=%" PRIu64 " resolved=%" PRIu64 " unresolved=%" PRIu64 "\n\n",
           tested, resolved, unresolved);

    if (tested) {
        printf("basin_1=%" PRIu64 " (%.9Lf%%)\n",
               basin1, 100.0L*(long double)basin1/(long double)tested);
        printf("basin_7_9_11=%" PRIu64 " (%.9Lf%%)\n\n",
               basin7, 100.0L*(long double)basin7/(long double)tested);
    }

    if (resolved) {
        printf("avg_steps_resolved=%.12Lf\n", total_steps/(long double)resolved);
    }

    printf("max_steps=%" PRIu64 " start=%" PRIu64 "\n",
           max_steps, argmax_steps);

    printf("max_reduced_peak=");
    print_u128(max_reduced_peak);
    printf(" start=%" PRIu64 "\n", argmax_reduced_peak);

    printf("max_raw_affine_peak=");
    print_u128(max_raw_peak);
    printf(" start=%" PRIu64 "\n", argmax_raw_peak);

    printf("max_v2=%u start=%" PRIu64 " at_x=", max_v2, argmax_v2_start);
    print_u128(argmax_v2_x);
    printf(" raw=");
    print_u128(argmax_v2_raw);
    putchar('\n');

    printf("max_reduced_peak_ratio=%.12Lf start=%" PRIu64 " peak=",
           max_peak_ratio, argmax_peak_ratio);
    print_u128(peak_at_max_ratio);
    putchar('\n');

    printf("\nSTEP_HISTOGRAM (nonzero bins)\n");
    for (uint64_t i = 0; i <= HIST_MAX; ++i) {
        if (hist[i]) printf("%" PRIu64 " %" PRIu64 "\n", i, hist[i]);
    }

    printf("\nelapsed_cpu=%.6f s rate=%.3f starts/s\n",
           elapsed, elapsed > 0 ? tested/elapsed : 0.0);

    // Current record-holders discovered in the exhaustive scan to 1e10.
    // Printing these is cheap and gives exact trajectories for the paper.
    print_orbit(8793787045ULL, max_iter);
    print_orbit(9250534785ULL, max_iter);

    // Also print the newly found record holders if different.
    if (argmax_steps != 8793787045ULL && argmax_steps != 9250534785ULL)
        print_orbit(argmax_steps, max_iter);

    if (argmax_reduced_peak != 8793787045ULL &&
        argmax_reduced_peak != 9250534785ULL &&
        argmax_reduced_peak != argmax_steps)
        print_orbit(argmax_reduced_peak, max_iter);

    if (argmax_peak_ratio != 8793787045ULL &&
        argmax_peak_ratio != 9250534785ULL &&
        argmax_peak_ratio != argmax_steps &&
        argmax_peak_ratio != argmax_reduced_peak)
        print_orbit(argmax_peak_ratio, max_iter);

    free(hist);
    return 0;
}
