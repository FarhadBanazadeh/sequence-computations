#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <inttypes.h>
#include <time.h>
#ifdef _OPENMP
#include <omp.h>
#endif

typedef unsigned __int128 u128;

typedef struct {
    uint64_t tested, basin1, basin7, unresolved;
    u128 sum_steps;
    uint64_t max_steps, argmax_steps;
    u128 max_reduced_peak;
    uint64_t argmax_reduced_peak;
    u128 max_raw_affine_peak;
    uint64_t argmax_raw_affine_peak;
} stats_t;

static inline int is_cycle_state(u128 x, int *basin) {
    if (x == 1) { *basin = 1; return 1; }
    if (x == 7 || x == 9 || x == 11) { *basin = 7; return 1; }
    return 0;
}

/* Count trailing zero bits of nonzero u128. */
static inline unsigned ctz128(u128 x) {
    uint64_t lo = (uint64_t)x;
    if (lo) return (unsigned)__builtin_ctzll(lo);
    return 64u + (unsigned)__builtin_ctzll((uint64_t)(x >> 64));
}

static inline u128 step5(u128 x, u128 *raw) {
    u128 n = ((x & 3u) == 1u) ? (5u*x - 1u) : (5u*x + 1u);
    *raw = n;
    n >>= ctz128(n);
    return n;
}

static void print_u128(u128 x) {
    char buf[64];
    int i = 0;
    if (x == 0) { putchar('0'); return; }
    while (x) {
        buf[i++] = (char)('0' + (unsigned)(x % 10));
        x /= 10;
    }
    while (i--) putchar(buf[i]);
}

static long double u128_to_ld(u128 x) {
    const long double TWO64 = 18446744073709551616.0L;
    uint64_t hi = (uint64_t)(x >> 64);
    uint64_t lo = (uint64_t)x;
    return (long double)hi * TWO64 + (long double)lo;
}

static void merge_stats(stats_t *g, const stats_t *s) {
    g->tested += s->tested;
    g->basin1 += s->basin1;
    g->basin7 += s->basin7;
    g->unresolved += s->unresolved;
    g->sum_steps += s->sum_steps;

    if (s->max_steps > g->max_steps) {
        g->max_steps = s->max_steps;
        g->argmax_steps = s->argmax_steps;
    }
    if (s->max_reduced_peak > g->max_reduced_peak) {
        g->max_reduced_peak = s->max_reduced_peak;
        g->argmax_reduced_peak = s->argmax_reduced_peak;
    }
    if (s->max_raw_affine_peak > g->max_raw_affine_peak) {
        g->max_raw_affine_peak = s->max_raw_affine_peak;
        g->argmax_raw_affine_peak = s->argmax_raw_affine_peak;
    }
}

int main(int argc, char **argv) {
    uint64_t limit = 10000000000ULL;   /* default: 10^10 */
    uint64_t max_iter = 1000000ULL;

    if (argc >= 2) limit = strtoull(argv[1], NULL, 10);
    if (argc >= 3) max_iter = strtoull(argv[2], NULL, 10);
    if (limit < 1) return 0;

    const uint64_t n_odds = (limit + 1ULL) / 2ULL;
    stats_t G = {0};

#ifdef _OPENMP
    const double t0 = omp_get_wtime();
#else
    const double t0 = (double)clock() / CLOCKS_PER_SEC;
#endif

#pragma omp parallel
    {
        stats_t L = {0};

#pragma omp for schedule(static)
        for (uint64_t i = 0; i < n_odds; ++i) {
            const uint64_t start = 2ULL*i + 1ULL;
            u128 x = (u128)start;
            u128 rpeak = x;
            u128 rawpeak = x;
            uint64_t steps = 0;
            int basin = 0;
            int unresolved = 0;

            while (!is_cycle_state(x, &basin)) {
                if (steps >= max_iter) {
                    unresolved = 1;
                    break;
                }

                /* Guard the u128 multiplication 5*x +/- 1. */
                const u128 U128_MAX = ~(u128)0;
                if (x > (U128_MAX - 1u) / 5u) {
                    unresolved = 1;
                    break;
                }

                u128 raw;
                x = step5(x, &raw);
                ++steps;

                if (raw > rawpeak) rawpeak = raw;
                if (x > rpeak) rpeak = x;
            }

            ++L.tested;
            if (unresolved) {
                ++L.unresolved;
                continue;
            }

            if (basin == 1) ++L.basin1;
            else            ++L.basin7;

            L.sum_steps += (u128)steps;

            if (steps > L.max_steps) {
                L.max_steps = steps;
                L.argmax_steps = start;
            }
            if (rpeak > L.max_reduced_peak) {
                L.max_reduced_peak = rpeak;
                L.argmax_reduced_peak = start;
            }
            if (rawpeak > L.max_raw_affine_peak) {
                L.max_raw_affine_peak = rawpeak;
                L.argmax_raw_affine_peak = start;
            }
        }

#pragma omp critical
        merge_stats(&G, &L);
    }

#ifdef _OPENMP
    const double t1 = omp_get_wtime();
#else
    const double t1 = (double)clock() / CLOCKS_PER_SEC;
#endif

    const double sec = t1 - t0;
    const uint64_t resolved = G.basin1 + G.basin7;

    printf("map: x%%4=1 -> (5x-1)/2^v2; x%%4=3 -> (5x+1)/2^v2\n");
    printf("limit=%" PRIu64 " odd_starts=%" PRIu64 " max_iter=%" PRIu64 "\n",
           limit, n_odds, max_iter);
#ifdef _OPENMP
    printf("threads=%d\n", omp_get_max_threads());
#endif
    printf("tested=%" PRIu64 " resolved=%" PRIu64 " unresolved=%" PRIu64 "\n",
           G.tested, resolved, G.unresolved);
    printf("basin_1=%" PRIu64 " (%.9f%%)\n",
           G.basin1, G.tested ? 100.0*(double)G.basin1/(double)G.tested : 0.0);
    printf("basin_7_9_11=%" PRIu64 " (%.9f%%)\n",
           G.basin7, G.tested ? 100.0*(double)G.basin7/(double)G.tested : 0.0);
    printf("avg_steps_resolved=%.9Lf\n",
           resolved ? u128_to_ld(G.sum_steps)/(long double)resolved : 0.0L);
    printf("max_steps=%" PRIu64 " start=%" PRIu64 "\n",
           G.max_steps, G.argmax_steps);

    printf("max_reduced_peak=");
    print_u128(G.max_reduced_peak);
    printf(" start=%" PRIu64 "\n", G.argmax_reduced_peak);

    printf("max_raw_affine_peak=");
    print_u128(G.max_raw_affine_peak);
    printf(" start=%" PRIu64 "\n", G.argmax_raw_affine_peak);

    printf("elapsed=%.6f s rate=%.3f starts/s\n",
           sec, sec > 0 ? (double)G.tested/sec : 0.0);

    return G.unresolved ? 2 : 0;
}
