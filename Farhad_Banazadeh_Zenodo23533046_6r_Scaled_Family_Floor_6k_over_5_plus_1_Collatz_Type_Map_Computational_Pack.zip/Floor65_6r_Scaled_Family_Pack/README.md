# 6^r-Scaled Family of the Reduced floor(6k/5)+1 Map

## Publication identifiers

- DOI: https://doi.org/10.5281/zenodo.23533046
- Version: v1 [NT]
- Publication date: 21 October 2026
- ORCID: https://orcid.org/0009-0004-7023-0298
- GitHub: https://github.com/FarhadBanazadeh

The article LaTeX source adds a clickable identification strip in the left margin of compiled pages. Scientific calculations and archived data are unchanged.

This archive accompanies the article by Farhad Banazadeh on the `6^r`-scaled family of the reduced `floor(6k/5)+1` Collatz-type map.

## Mathematical scope

The base map is `G0(n)=floor(6n/5)+1`, followed by complete removal of factors of 5. The scaled family is defined on the scaled domain `D_r=6^r D` by

`H_r(x)=(6x+6^r c(x))/5`, followed by complete 5-adic reduction,

where `c(x)` is the residue correction forced by `x mod 5`. The main exact identity is

`T_r(6^r n)=6^r T_0(n)`.

The package checks this conjugacy and the equivalent floor-function formula on a finite sample. The proof in the article is algebraic and does not depend on the finite checker.

## Contents

- `article/Farhad_Banazadeh_Zenodo23533046_6r_Scaled_Family_Floor_6k_over_5_plus_1_Collatz_Type_Map.tex` - complete LaTeX source.
- `src/verify_scaled_family.py` - lightweight identity verifier.
- `data/scaled_family_statement.json` - machine-readable definitions and main identities.
- `data/verification_results.json` - results of the included verification run.
- `data/transferred_records.csv` - symbolic transfer of selected base finite records.
- `provenance/base_article.tex` - source of the base study supplied for provenance.
- `provenance/base_summary.json` and selected base CSVs - base computational results used by the transfer theorem.
- `SHA256SUMS.txt` - checksums for archived files.

The compiled PDF is intentionally not included in this ZIP.

## Reproduce the lightweight checks

```bash
python3 src/verify_scaled_family.py --limit 10000 --max-r 5 --out data/verification_results.json
```

The distributed run checks 300,000 assertions.

## Logical status

1. The scaling/conjugacy results are exact on the stated scaled domains.
2. The `10^11` finite theorem is transferred from the completed base verification; it is not a new independent `10^11` scan at each scale.
3. Global convergence remains conjectural exactly as in the base system.
