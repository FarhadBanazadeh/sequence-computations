#!/usr/bin/env python3
# DOI: https://doi.org/10.5281/zenodo.23533046
# Version: v1 [NT] | 21 October 2026
# ORCID: https://orcid.org/0009-0004-7023-0298
# GitHub: https://github.com/FarhadBanazadeh
import argparse, json

def v5(n):
    e=0
    while n%5==0:
        n//=5; e+=1
    return e

def c(n):
    s=n%5
    return 5-s if s else 5

def G0(n): return (6*n+c(n))//5

def T0(n):
    g=G0(n)
    return g//(5**v5(g))

def Hr(x,r):
    # generalized initial quotient; branch correction c(x)6^r
    return (6*x+c(x)*(6**r))//5

def Tr(x,r):
    h=Hr(x,r)
    return h//(5**v5(h))

def floor_form(x,r):
    cc=c(x)
    return (6*x)//5 + 1 + ((6**r-1)//5)*cc

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--limit',type=int,default=100000)
    ap.add_argument('--max-r',type=int,default=6)
    ap.add_argument('--out',default='verification_results.json')
    a=ap.parse_args()
    checks=0
    for r in range(a.max_r+1):
        s6=6**r
        for n in range(1,a.limit+1):
            x=s6*n
            assert x%5==n%5
            assert Hr(x,r)==s6*G0(n)
            assert floor_form(x,r)==Hr(x,r)
            assert v5(Hr(x,r))==v5(G0(n))
            assert Tr(x,r)==s6*T0(n)
            checks+=5
    out={'status':'PASS','normalized_limit':a.limit,'max_r':a.max_r,'scale_levels':a.max_r+1,
         'assertions_checked':checks,
         'identities':['x mod 5 = n mod 5 for x=6^r n','H_r(6^r n)=6^r G_0(n)',
                       'floor representation equals residue-affine representation',
                       'v5(H_r(6^r n))=v5(G_0(n))','T_r(6^r n)=6^r T_0(n)']}
    with open(a.out,'w') as f: json.dump(out,f,indent=2)
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
