COMPUTATIONAL PACK
A Ternary (4k + 1(2))/3 Collatz-Type Map with Two Attracting Cycles:
Theoretical Analysis and Exhaustive Computational Verification up to 10^11
Farhad Banazadeh, 18 September 2026

CONTENTS
article/
  Updated LaTeX source and compiled PDF for the 10^11 version.

original_1e9_audit/
  Materials from the previously completed 10^9 audit, retained for provenance.

extension_1e9_to_1e11/
  Complete extension scan supplied after the 10^11 run, including FAST source,
  checkpoint/chunk CSV, final summary, earlier scanner source, and executables
  present in the original scan archive.

COMBINED_RESULTS_UP_TO_1e11.txt
  Arithmetic combination of the original 10^9 audit and the new extension.

SHA256SUMS.txt
  SHA-256 checksums for files in this archive (except SHA256SUMS.txt itself).

REPRODUCTION OF THE EXTENSION
Recommended source:
  extension_1e9_to_1e11/scan_ternary_4k_plus_1_2_over_3_FAST_mac_v2.c

Representative macOS compilation:
  clang -O3 -march=native -flto -DNDEBUG -std=c11 -pthread \
    scan_ternary_4k_plus_1_2_over_3_FAST_mac_v2.c -o scan_ternary_FAST

The extension scanner uses a uint64_t hot path and promotes to unsigned __int128
when required. This is necessary because the observed global peak exceeds 2^64-1.

FINITE VERIFICATION ONLY
The exhaustive computation establishes the reported behavior for the tested finite
domain. It does not prove the all-positive-integers convergence conjecture.

Publication PDF note: the article PDF in this archive is a 300-DPI raster-safe rendering, used to prevent viewer-dependent embedded-font/line-layout corruption. The editable LaTeX source is supplied alongside it.
