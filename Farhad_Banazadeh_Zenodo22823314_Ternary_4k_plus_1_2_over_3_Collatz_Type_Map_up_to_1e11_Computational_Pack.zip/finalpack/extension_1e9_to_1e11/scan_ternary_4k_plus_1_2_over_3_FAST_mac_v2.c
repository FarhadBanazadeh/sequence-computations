/*
 FAST macOS scanner: Ternary (4k + 1(2))/3 map
 Extension interval only: 1e9 < n <= 1e11, 3 ∤ n

 Key speed change:
   Hot trajectory arithmetic uses uint64_t.
   Before computing 4*n+{1,2}, it checks whether uint64_t would overflow.
   Only if that rare condition occurs does it promote that trajectory to
   unsigned __int128. Thus numerical safety is retained without paying
   128-bit division/modulo cost on every ordinary step.

 Compile:
   clang -O3 -march=native -flto -DNDEBUG -std=c11 -pthread \
     scan_ternary_4k_plus_1_2_over_3_FAST_mac.c -o scan_ternary_FAST

 Run:
   ./scan_ternary_FAST

 Optional:
   ./scan_ternary_FAST 4 30000000

 NOTE: Uses NEW checkpoint filenames, so it does not mix with the earlier
 benchmark checkpoint.
*/

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>

typedef unsigned __int128 u128;
typedef uint64_t u64;

#define RANGE_LO 1000000001ULL
#define RANGE_HI 100000000000ULL
#define DEFAULT_THREADS 4
#define DEFAULT_CHUNK_WIDTH 30000000ULL
#define MAX_STEPS 1000000ULL

static const u128 U128MAX = (u128)~(u128)0;

typedef struct {
    u64 starts,c1,c7,unknown,overflow,step_limit;
    u64 total_steps,total_removed;
    u64 max_steps,max_steps_start;
    u128 max_peak; u64 max_peak_start,max_peak_step;
    u64 max_removed,max_removed_start,max_removed_step;
} Stats;

typedef struct { u64 id,lo,hi; Stats s; double sec; } Chunk;

static int nth=DEFAULT_THREADS;
static u64 cw=DEFAULT_CHUNK_WIDTH,nchunks;
static atomic_ullong nextid;
static unsigned char *done;
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
static Stats total;
static u64 completed=0;
static double tstart;

static const char *CK="ternary_4k1_2_FAST_1e9_to_1e11_chunks.csv";
static const char *SUM="ternary_4k1_2_FAST_1e9_to_1e11_summary.txt";

static double nowsec(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+1e-9*t.tv_nsec;}
static void z(Stats*s){memset(s,0,sizeof(*s));}
static void s128(u128 x,char*b,size_t n){char q[64];size_t k=0,j=0;if(!x){snprintf(b,n,"0");return;}while(x){q[k++]=(char)('0'+x%10);x/=10;}while(k&&j+1<n)b[j++]=q[--k];b[j]=0;}
static int p128(const char*s,u128*out){u128 x=0;if(!s||!*s)return 0;for(;*s;s++){if(*s<'0'||*s>'9')return 0;unsigned d=*s-'0';if(x>(U128MAX-d)/10)return 0;x=x*10+d;}*out=x;return 1;}

static inline int c1_64(u64 x){return x==1||x==2;}
static inline int c7_64(u64 x){return x==7||x==10||x==14||x==19||x==26||x==35||x==47;}
static inline int c1_128(u128 x){return x==1||x==2;}
static inline int c7_128(u128 x){return x==7||x==10||x==14||x==19||x==26||x==35||x==47;}

static void merge(Stats*a,const Stats*b){
 a->starts+=b->starts;a->c1+=b->c1;a->c7+=b->c7;a->unknown+=b->unknown;
 a->overflow+=b->overflow;a->step_limit+=b->step_limit;a->total_steps+=b->total_steps;
 a->total_removed+=b->total_removed;
 if(b->max_steps>a->max_steps){a->max_steps=b->max_steps;a->max_steps_start=b->max_steps_start;}
 if(b->max_peak>a->max_peak){a->max_peak=b->max_peak;a->max_peak_start=b->max_peak_start;a->max_peak_step=b->max_peak_step;}
 if(b->max_removed>a->max_removed){a->max_removed=b->max_removed;a->max_removed_start=b->max_removed_start;a->max_removed_step=b->max_removed_step;}
}

/* Continue one trajectory after it becomes too large for safe uint64 4*x+add. */
static int continue128(u128 x,u64 start,u64 *steps,u128 *peak,u64 *peakstep,Stats*s){
 while(*steps<MAX_STEPS){
   if(c1_128(x)) return 1;
   if(c7_128(x)) return 7;
   unsigned r=(unsigned)(x%3);
   if(!r) return -3;
   u128 add=(r==1)?2:1;
   if(x>(U128MAX-add)/4) return -1;
   u128 y=(4*x+add)/3;
   u64 v=0;
   while(y%3==0){y/=3;++v;}
   ++*steps;s->total_removed+=v;
   if(v>s->max_removed){s->max_removed=v;s->max_removed_start=start;s->max_removed_step=*steps;}
   x=y;
   if(x>*peak){*peak=x;*peakstep=*steps;}
 }
 return -2;
}

static void scan(u64 lo,u64 hi,Stats*s){
 z(s);
 u64 n=lo;
 while(n<=hi && n%3==0)++n;
 for(;n<=hi;){
   ++s->starts;
   u64 x=n;
   u128 peak=(u128)x;
   u64 peakstep=0,steps=0;
   int cls=0;

   while(steps<MAX_STEPS){
     if(c1_64(x)){cls=1;break;}
     if(c7_64(x)){cls=7;break;}

     unsigned r=(unsigned)(x%3);
     if(!r){cls=-3;break;}
     u64 add=(r==1)?2ULL:1ULL;

     /* Rare slow path only when 4*x+add does not fit uint64_t. */
     if(x>(UINT64_MAX-add)/4ULL){
       cls=continue128((u128)x,n,&steps,&peak,&peakstep,s);
       break;
     }

     u64 y=(4ULL*x+add)/3ULL;
     u64 v=0;
     while(y%3ULL==0ULL){y/=3ULL;++v;}
     ++steps;s->total_removed+=v;
     if(v>s->max_removed){s->max_removed=v;s->max_removed_start=n;s->max_removed_step=steps;}
     x=y;
     if((u128)x>peak){peak=(u128)x;peakstep=steps;}
   }
   if(cls==0)cls=-2;
   if(cls==1)++s->c1; else if(cls==7)++s->c7;
   else {++s->unknown;if(cls==-1)++s->overflow;if(cls==-2)++s->step_limit;}
   s->total_steps+=steps;
   if(steps>s->max_steps){s->max_steps=steps;s->max_steps_start=n;}
   if(peak>s->max_peak){s->max_peak=peak;s->max_peak_start=n;s->max_peak_step=peakstep;}

   /* Iterate admissible starts directly: residues alternate +1,+2. */
   if(n%3==1){ if(n==UINT64_MAX)break; n+=1; }
   else { if(n>UINT64_MAX-2)break; n+=2; }
 }
}

static void header(void){
 FILE*f=fopen(CK,"a+");if(!f){perror(CK);exit(1);}fseek(f,0,SEEK_END);
 if(ftell(f)==0){fprintf(f,"chunk,lo,hi,starts,c1,c7,unknown,overflow,step_limit,total_steps,max_steps,max_steps_start,max_peak,max_peak_start,max_peak_step,total_removed,max_removed,max_removed_start,max_removed_step,seconds\n");fflush(f);fsync(fileno(f));}fclose(f);
}
static void load(void){
 header();FILE*f=fopen(CK,"r");if(!f)return;char l[1024];fgets(l,sizeof l,f);
 while(fgets(l,sizeof l,f)){char*a[20]={0},*sv=NULL,*p=strtok_r(l,",\r\n",&sv);int k=0;while(p&&k<20){a[k++]=p;p=strtok_r(NULL,",\r\n",&sv);}if(k!=20)continue;
  u64 id=strtoull(a[0],0,10);if(id>=nchunks||done[id])continue;Stats s;z(&s);
  s.starts=strtoull(a[3],0,10);s.c1=strtoull(a[4],0,10);s.c7=strtoull(a[5],0,10);s.unknown=strtoull(a[6],0,10);s.overflow=strtoull(a[7],0,10);s.step_limit=strtoull(a[8],0,10);s.total_steps=strtoull(a[9],0,10);s.max_steps=strtoull(a[10],0,10);s.max_steps_start=strtoull(a[11],0,10);p128(a[12],&s.max_peak);s.max_peak_start=strtoull(a[13],0,10);s.max_peak_step=strtoull(a[14],0,10);s.total_removed=strtoull(a[15],0,10);s.max_removed=strtoull(a[16],0,10);s.max_removed_start=strtoull(a[17],0,10);s.max_removed_step=strtoull(a[18],0,10);
  done[id]=1;++completed;merge(&total,&s);
 }fclose(f);
}
static void save(const Chunk*c){
 char pk[64];s128(c->s.max_peak,pk,sizeof pk);FILE*f=fopen(CK,"a");if(!f)return;
 fprintf(f,"%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%s,%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%"PRIu64",%.6f\n",
 c->id,c->lo,c->hi,c->s.starts,c->s.c1,c->s.c7,c->s.unknown,c->s.overflow,c->s.step_limit,c->s.total_steps,c->s.max_steps,c->s.max_steps_start,pk,c->s.max_peak_start,c->s.max_peak_step,c->s.total_removed,c->s.max_removed,c->s.max_removed_start,c->s.max_removed_step,c->sec);
 fflush(f);fsync(fileno(f));fclose(f);
}
static void show(const Chunk*c){
 char cp[64],tp[64];s128(c->s.max_peak,cp,sizeof cp);s128(total.max_peak,tp,sizeof tp);
 double e=nowsec()-tstart,rate=e?total.starts/e:0;
 printf("\nchunk:          %"PRIu64" / %"PRIu64"   (%.2f%% complete)\n",completed,nchunks,100.0*completed/nchunks);
 printf("chunk id:       %"PRIu64"\nn-range:        [%"PRIu64", %"PRIu64"]\nchunk starts:   %"PRIu64"\nchunk seconds:  %.3f\n",c->id,c->lo,c->hi,c->s.starts,c->sec);
 printf("overall rate:   %.0f starts/sec\n",rate);
 printf("outcomes:       C1=%"PRIu64"  C7=%"PRIu64"  unknown=%"PRIu64"  ovf=%"PRIu64"  limit=%"PRIu64"\n",c->s.c1,c->s.c7,c->s.unknown,c->s.overflow,c->s.step_limit);
 printf("chunk max steps: n=%"PRIu64" steps=%"PRIu64"\n",c->s.max_steps_start,c->s.max_steps);
 printf("chunk max peak:  n=%"PRIu64" peak=%s step=%"PRIu64"\n",c->s.max_peak_start,cp,c->s.max_peak_step);
 printf("\nsession totals:\nstarts:         %"PRIu64"\nC1:             %"PRIu64"\nC7:             %"PRIu64"\nunknown:        %"PRIu64"\noverflow:       %"PRIu64"\nstep limit:     %"PRIu64"\n",total.starts,total.c1,total.c7,total.unknown,total.overflow,total.step_limit);
 printf("max steps:      n=%"PRIu64" steps=%"PRIu64"\nmax peak:       n=%"PRIu64" peak=%s step=%"PRIu64"\n",total.max_steps_start,total.max_steps,total.max_peak_start,tp,total.max_peak_step);
 fflush(stdout);
}
static void*worker(void*x){
 (void)x;for(;;){u64 id=atomic_fetch_add(&nextid,1);if(id>=nchunks)break;if(done[id])continue;
  Chunk c;memset(&c,0,sizeof c);c.id=id;c.lo=RANGE_LO+id*cw;c.hi=c.lo+cw-1;if(c.hi<c.lo||c.hi>RANGE_HI)c.hi=RANGE_HI;
  double t=nowsec();scan(c.lo,c.hi,&c.s);c.sec=nowsec()-t;
  pthread_mutex_lock(&lock);if(!done[id]){save(&c);done[id]=1;++completed;merge(&total,&c.s);show(&c);}pthread_mutex_unlock(&lock);
 }return NULL;
}
static void summary(double e){
 char p[64];s128(total.max_peak,p,sizeof p);FILE*f=fopen(SUM,"w");if(!f)return;
 fprintf(f,"FAST Ternary (4k + 1(2))/3 extension scan\nInterval: [%"PRIu64", %"PRIu64"], 3 does not divide n\nThreads: %d\nAdmissible starts: %"PRIu64"\nC1: %"PRIu64"\nC7: %"PRIu64"\nUnknown: %"PRIu64"\nOverflow: %"PRIu64"\nStep limit: %"PRIu64"\nTotal steps to known cycle: %"PRIu64"\nMean steps to known cycle: %.12Lf\nMax steps to known cycle: %"PRIu64" at n=%"PRIu64"\nGlobal peak: %s at n=%"PRIu64" step=%"PRIu64"\nTotal extra factors of 3 removed: %"PRIu64"\nMax extra factors in one step: %"PRIu64" at start=%"PRIu64" step=%"PRIu64"\nWall time: %.3f s\n",
 (u64)RANGE_LO,(u64)RANGE_HI,nth,total.starts,total.c1,total.c7,total.unknown,total.overflow,total.step_limit,total.total_steps,total.starts?(long double)total.total_steps/total.starts:0,total.max_steps,total.max_steps_start,p,total.max_peak_start,total.max_peak_step,total.total_removed,total.max_removed,total.max_removed_start,total.max_removed_step,e);fclose(f);
}
int main(int ac,char**av){
 if(ac>1){nth=atoi(av[1]);if(nth<1||nth>64)return fprintf(stderr,"threads 1..64\n"),1;}
 if(ac>2){cw=strtoull(av[2],0,10);if(cw<1000)return fprintf(stderr,"chunk too small\n"),1;}
 u64 span=RANGE_HI-RANGE_LO+1;nchunks=(span+cw-1)/cw;done=calloc((size_t)nchunks,1);if(!done)return 1;z(&total);load();
 printf("============================================================\nFAST Ternary (4k + 1(2))/3 extension scan\nNew interval: [%"PRIu64", %"PRIu64"] ; 3 does not divide n\nThreads: %d\nInteger chunk width: %"PRIu64"\nChunks: %"PRIu64"\nAlready completed FAST checkpoint: %"PRIu64"\nHot path: uint64_t; rare automatic promotion to unsigned __int128\nMAX_STEPS: %"PRIu64"\n============================================================\n",(u64)RANGE_LO,(u64)RANGE_HI,nth,cw,nchunks,completed,(u64)MAX_STEPS);
 tstart=nowsec();atomic_init(&nextid,0);pthread_t*th=calloc((size_t)nth,sizeof(pthread_t));if(!th)return 1;
 for(int i=0;i<nth;i++)if(pthread_create(&th[i],0,worker,0))return 1;
 for(int i=0;i<nth;i++)pthread_join(th[i],0);
 double e=nowsec()-tstart;summary(e);char p[64];s128(total.max_peak,p,sizeof p);
 printf("\n================ FINAL FAST RESULT =================\nstarts: %"PRIu64"\nC1: %"PRIu64"\nC7: %"PRIu64"\nunknown: %"PRIu64"\noverflow: %"PRIu64"\nstep limit: %"PRIu64"\nmax steps: %"PRIu64" at n=%"PRIu64"\nglobal peak: %s at n=%"PRIu64" step=%"PRIu64"\nwall time: %.3f s\nsummary: %s\ncheckpoint: %s\n====================================================\n",total.starts,total.c1,total.c7,total.unknown,total.overflow,total.step_limit,total.max_steps,total.max_steps_start,p,total.max_peak_start,total.max_peak_step,e,SUM,CK);
 free(th);free(done);return 0;
}
