/*
  scan_ternary_4k_plus_1_2_over_3_1e9_to_1e11_mac.c

  Exhaustive extension scan for:
      A Ternary (4k + 1(2))/3 Collatz-Type Map with Two Attracting Cycles

  New interval only:
      1,000,000,001 <= n <= 100,000,000,000,  3 does not divide n

  Known terminal cycles:
      C1 = (1,2)
      C7 = (7,10,14,19,26,35,47)

  Designed for a 4-core macOS machine with modest RAM:
    - pthreads (default 4 workers)
    - dynamic chunk scheduling
    - constant-memory trajectory processing
    - unsigned __int128 arithmetic for safe intermediate values/peaks
    - overflow counter if a trajectory exceeds 128-bit arithmetic
    - step-limit counter
    - progressive terminal output after every completed chunk
    - per-chunk CSV checkpoint log; completed chunks are skipped on restart
    - final summary file

  Compile:
      clang -O3 -march=native -std=c11 -pthread \
        scan_ternary_4k_plus_1_2_over_3_1e9_to_1e11_mac.c \
        -o scan_ternary_1e11

  Run:
      ./scan_ternary_1e11

  Optional:
      ./scan_ternary_1e11 4 30000000
      arguments: THREADS, INTEGER_CHUNK_WIDTH

  IMPORTANT:
    "steps" here means steps to first entry into one of the two known cycles.
    It is NOT the first-lower stopping time sigma(n).
*/

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

typedef unsigned __int128 u128;
typedef uint64_t u64;

#define DEFAULT_THREADS 4
#define DEFAULT_CHUNK_WIDTH 30000000ULL
#define RANGE_LO 1000000001ULL
#define RANGE_HI 100000000000ULL
#define MAX_STEPS 1000000ULL

static const u128 U128_MAX_VALUE = (u128)(~(u128)0);

typedef struct {
    u64 starts;
    u64 c1;
    u64 c7;
    u64 unknown;
    u64 overflow;
    u64 step_limit;
    u64 total_steps;
    u64 total_removed;

    u64 max_steps;
    u64 max_steps_start;

    u128 max_peak;
    u64 max_peak_start;
    u64 max_peak_step;

    u64 max_removed;
    u64 max_removed_start;
    u64 max_removed_step;
} Stats;

typedef struct {
    u64 chunk_id;
    u64 lo;
    u64 hi;
    Stats s;
    double seconds;
} ChunkResult;

static u64 g_chunk_width = DEFAULT_CHUNK_WIDTH;
static u64 g_num_chunks = 0;
static int g_threads = DEFAULT_THREADS;

static atomic_ullong g_next_chunk;
static unsigned char *g_done = NULL;

static pthread_mutex_t g_merge_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t g_log_mutex   = PTHREAD_MUTEX_INITIALIZER;

static Stats g_total;
static u64 g_completed_chunks = 0;
static double g_wall_start = 0.0;

static const char *CHECKPOINT = "ternary_4k1_2_1e9_to_1e11_chunks.csv";
static const char *SUMMARY    = "ternary_4k1_2_1e9_to_1e11_summary.txt";

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

static void u128_to_str(u128 v, char *buf, size_t n) {
    if (n == 0) return;
    if (v == 0) {
        if (n >= 2) { buf[0] = '0'; buf[1] = '\0'; }
        return;
    }
    char tmp[64];
    size_t k = 0;
    while (v && k < sizeof(tmp)) {
        tmp[k++] = (char)('0' + (v % 10));
        v /= 10;
    }
    size_t out = 0;
    while (k && out + 1 < n) buf[out++] = tmp[--k];
    buf[out] = '\0';
}

static int parse_u128(const char *s, u128 *out) {
    u128 v = 0;
    if (!s || !*s) return 0;
    for (; *s; ++s) {
        if (*s < '0' || *s > '9') return 0;
        unsigned d = (unsigned)(*s - '0');
        if (v > (U128_MAX_VALUE - d) / 10) return 0;
        v = v * 10 + d;
    }
    *out = v;
    return 1;
}

static inline int in_c1(u128 n) {
    return n == 1 || n == 2;
}
static inline int in_c7(u128 n) {
    return n == 7 || n == 10 || n == 14 || n == 19 ||
           n == 26 || n == 35 || n == 47;
}

/* One compressed map step.
   For n mod 3 = 1: pre-reduced integer is (4n+2)/3.
   For n mod 3 = 2: pre-reduced integer is (4n+1)/3.
   Then remove every additional factor of 3.
*/
static inline int next_value(u128 n, u128 *out, u64 *removed) {
    unsigned r = (unsigned)(n % 3);
    if (r == 0) return 0; /* should never occur in compressed state */

    u128 add = (r == 1) ? 2 : 1;

    /* guard 4*n + add in 128-bit arithmetic */
    if (n > (U128_MAX_VALUE - add) / 4) return -1;

    u128 x = (4 * n + add) / 3;
    u64 v = 0;

    while (x % 3 == 0) {
        x /= 3;
        ++v;
    }

    *out = x;
    *removed = v;
    return 1;
}

static inline void stats_zero(Stats *s) {
    memset(s, 0, sizeof(*s));
}

static void stats_merge(Stats *a, const Stats *b) {
    a->starts        += b->starts;
    a->c1            += b->c1;
    a->c7            += b->c7;
    a->unknown       += b->unknown;
    a->overflow      += b->overflow;
    a->step_limit    += b->step_limit;
    a->total_steps   += b->total_steps;
    a->total_removed += b->total_removed;

    if (b->max_steps > a->max_steps) {
        a->max_steps = b->max_steps;
        a->max_steps_start = b->max_steps_start;
    }
    if (b->max_peak > a->max_peak) {
        a->max_peak = b->max_peak;
        a->max_peak_start = b->max_peak_start;
        a->max_peak_step = b->max_peak_step;
    }
    if (b->max_removed > a->max_removed) {
        a->max_removed = b->max_removed;
        a->max_removed_start = b->max_removed_start;
        a->max_removed_step = b->max_removed_step;
    }
}

static void scan_chunk(u64 lo, u64 hi, Stats *s) {
    stats_zero(s);

    /* Move to first nonmultiple of 3. */
    u64 start = lo;
    while (start <= hi && start % 3 == 0) ++start;

    for (; start <= hi; ++start) {
        if (start % 3 == 0) continue;

        ++s->starts;

        u128 x = (u128)start;
        u128 peak = x;
        u64 peak_step = 0;
        u64 steps = 0;
        int cls = 0; /* 1=C1, 7=C7, -1 overflow, -2 limit, -3 unexpected */

        while (steps < MAX_STEPS) {
            if (in_c1(x)) { cls = 1; break; }
            if (in_c7(x)) { cls = 7; break; }

            u128 nx;
            u64 removed = 0;
            int rc = next_value(x, &nx, &removed);
            if (rc < 0) { cls = -1; break; }
            if (rc == 0) { cls = -3; break; }

            ++steps;
            s->total_removed += removed;

            if (removed > s->max_removed) {
                s->max_removed = removed;
                s->max_removed_start = start;
                s->max_removed_step = steps;
            }

            x = nx;
            if (x > peak) {
                peak = x;
                peak_step = steps;
            }
        }

        if (cls == 0) cls = -2;

        if (cls == 1) ++s->c1;
        else if (cls == 7) ++s->c7;
        else {
            ++s->unknown;
            if (cls == -1) ++s->overflow;
            if (cls == -2) ++s->step_limit;
        }

        s->total_steps += steps;

        if (steps > s->max_steps) {
            s->max_steps = steps;
            s->max_steps_start = start;
        }

        if (peak > s->max_peak) {
            s->max_peak = peak;
            s->max_peak_start = start;
            s->max_peak_step = peak_step;
        }

        if (start == UINT64_MAX) break;
    }
}

static void ensure_checkpoint_header(void) {
    FILE *f = fopen(CHECKPOINT, "a+");
    if (!f) {
        fprintf(stderr, "Cannot open %s: %s\n", CHECKPOINT, strerror(errno));
        exit(1);
    }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    if (sz == 0) {
        fprintf(f,
          "chunk,lo,hi,starts,c1,c7,unknown,overflow,step_limit,total_steps,"
          "max_steps,max_steps_start,max_peak,max_peak_start,max_peak_step,"
          "total_removed,max_removed,max_removed_start,max_removed_step,seconds\n");
        fflush(f);
        fsync(fileno(f));
    }
    fclose(f);
}

static void load_checkpoint(void) {
    ensure_checkpoint_header();

    FILE *f = fopen(CHECKPOINT, "r");
    if (!f) return;

    char line[1024];
    if (!fgets(line, sizeof(line), f)) { fclose(f); return; } /* header */

    while (fgets(line, sizeof(line), f)) {
        char *fields[20] = {0};
        int nf = 0;
        char *save = NULL;
        char *tok = strtok_r(line, ",\n\r", &save);
        while (tok && nf < 20) {
            fields[nf++] = tok;
            tok = strtok_r(NULL, ",\n\r", &save);
        }
        if (nf != 20) continue;

        u64 cid = strtoull(fields[0], NULL, 10);
        if (cid >= g_num_chunks || g_done[cid]) continue;

        ChunkResult cr;
        memset(&cr, 0, sizeof(cr));
        cr.chunk_id = cid;
        cr.lo = strtoull(fields[1], NULL, 10);
        cr.hi = strtoull(fields[2], NULL, 10);
        cr.s.starts = strtoull(fields[3], NULL, 10);
        cr.s.c1 = strtoull(fields[4], NULL, 10);
        cr.s.c7 = strtoull(fields[5], NULL, 10);
        cr.s.unknown = strtoull(fields[6], NULL, 10);
        cr.s.overflow = strtoull(fields[7], NULL, 10);
        cr.s.step_limit = strtoull(fields[8], NULL, 10);
        cr.s.total_steps = strtoull(fields[9], NULL, 10);
        cr.s.max_steps = strtoull(fields[10], NULL, 10);
        cr.s.max_steps_start = strtoull(fields[11], NULL, 10);
        parse_u128(fields[12], &cr.s.max_peak);
        cr.s.max_peak_start = strtoull(fields[13], NULL, 10);
        cr.s.max_peak_step = strtoull(fields[14], NULL, 10);
        cr.s.total_removed = strtoull(fields[15], NULL, 10);
        cr.s.max_removed = strtoull(fields[16], NULL, 10);
        cr.s.max_removed_start = strtoull(fields[17], NULL, 10);
        cr.s.max_removed_step = strtoull(fields[18], NULL, 10);
        cr.seconds = strtod(fields[19], NULL);

        g_done[cid] = 1;
        ++g_completed_chunks;
        stats_merge(&g_total, &cr.s);
    }
    fclose(f);
}

static void append_checkpoint(const ChunkResult *cr) {
    char peak[64];
    u128_to_str(cr->s.max_peak, peak, sizeof(peak));

    FILE *f = fopen(CHECKPOINT, "a");
    if (!f) {
        fprintf(stderr, "\nWARNING: cannot append checkpoint: %s\n", strerror(errno));
        return;
    }
    fprintf(f,
      "%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64
      ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64
      ",%s,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64
      ",%" PRIu64 ",%.6f\n",
      cr->chunk_id, cr->lo, cr->hi,
      cr->s.starts, cr->s.c1, cr->s.c7, cr->s.unknown,
      cr->s.overflow, cr->s.step_limit, cr->s.total_steps,
      cr->s.max_steps, cr->s.max_steps_start,
      peak, cr->s.max_peak_start, cr->s.max_peak_step,
      cr->s.total_removed, cr->s.max_removed,
      cr->s.max_removed_start, cr->s.max_removed_step,
      cr->seconds);
    fflush(f);
    fsync(fileno(f));
    fclose(f);
}

static void print_progress(const ChunkResult *cr) {
    char chunk_peak[64], total_peak[64];
    u128_to_str(cr->s.max_peak, chunk_peak, sizeof(chunk_peak));
    u128_to_str(g_total.max_peak, total_peak, sizeof(total_peak));

    double elapsed = now_sec() - g_wall_start;
    double rate = elapsed > 0.0 ? (double)g_total.starts / elapsed : 0.0;
    double pct = 100.0 * (double)g_completed_chunks / (double)g_num_chunks;

    printf("\nchunk:          %" PRIu64 " / %" PRIu64 "   (%.2f%% complete)\n",
           g_completed_chunks, g_num_chunks, pct);
    printf("chunk id:       %" PRIu64 "\n", cr->chunk_id);
    printf("n-range:        [%" PRIu64 ", %" PRIu64 "]\n", cr->lo, cr->hi);
    printf("chunk starts:   %" PRIu64 "\n", cr->s.starts);
    printf("chunk seconds:  %.3f\n", cr->seconds);
    printf("overall rate:   %.0f starts/sec\n", rate);
    printf("outcomes:       C1=%" PRIu64 "  C7=%" PRIu64
           "  unknown=%" PRIu64 "  ovf=%" PRIu64 "  limit=%" PRIu64 "\n",
           cr->s.c1, cr->s.c7, cr->s.unknown, cr->s.overflow, cr->s.step_limit);
    printf("chunk max steps: n=%" PRIu64 " steps=%" PRIu64 "\n",
           cr->s.max_steps_start, cr->s.max_steps);
    printf("chunk max peak:  n=%" PRIu64 " peak=%s step=%" PRIu64 "\n",
           cr->s.max_peak_start, chunk_peak, cr->s.max_peak_step);

    printf("\nsession totals:\n");
    printf("starts:         %" PRIu64 "\n", g_total.starts);
    printf("C1:             %" PRIu64 "\n", g_total.c1);
    printf("C7:             %" PRIu64 "\n", g_total.c7);
    printf("unknown:        %" PRIu64 "\n", g_total.unknown);
    printf("overflow:       %" PRIu64 "\n", g_total.overflow);
    printf("step limit:     %" PRIu64 "\n", g_total.step_limit);
    printf("max steps:      n=%" PRIu64 " steps=%" PRIu64 "\n",
           g_total.max_steps_start, g_total.max_steps);
    printf("max peak:       n=%" PRIu64 " peak=%s step=%" PRIu64 "\n",
           g_total.max_peak_start, total_peak, g_total.max_peak_step);
    printf("checkpoint:     %s\n", CHECKPOINT);
    fflush(stdout);
}

static void *worker(void *arg) {
    (void)arg;

    for (;;) {
        u64 cid = atomic_fetch_add(&g_next_chunk, 1);
        if (cid >= g_num_chunks) break;
        if (g_done[cid]) continue;

        u64 lo = RANGE_LO + cid * g_chunk_width;
        u64 hi = lo + g_chunk_width - 1;
        if (hi < lo || hi > RANGE_HI) hi = RANGE_HI;

        ChunkResult cr;
        memset(&cr, 0, sizeof(cr));
        cr.chunk_id = cid;
        cr.lo = lo;
        cr.hi = hi;

        double t0 = now_sec();
        scan_chunk(lo, hi, &cr.s);
        cr.seconds = now_sec() - t0;

        pthread_mutex_lock(&g_log_mutex);
        /* mark/log exactly once */
        if (!g_done[cid]) {
            append_checkpoint(&cr);
            g_done[cid] = 1;

            pthread_mutex_lock(&g_merge_mutex);
            stats_merge(&g_total, &cr.s);
            ++g_completed_chunks;
            print_progress(&cr);
            pthread_mutex_unlock(&g_merge_mutex);
        }
        pthread_mutex_unlock(&g_log_mutex);
    }
    return NULL;
}

static void write_summary(double elapsed) {
    char peak[64];
    u128_to_str(g_total.max_peak, peak, sizeof(peak));

    FILE *f = fopen(SUMMARY, "w");
    if (!f) return;

    long double mean = g_total.starts
        ? (long double)g_total.total_steps / (long double)g_total.starts : 0.0L;

    fprintf(f, "Ternary (4k + 1(2))/3 extension scan\n");
    fprintf(f, "Interval: [%" PRIu64 ", %" PRIu64 "], excluding multiples of 3\n",
            (u64)RANGE_LO, (u64)RANGE_HI);
    fprintf(f, "Threads: %d\n", g_threads);
    fprintf(f, "Integer chunk width: %" PRIu64 "\n", g_chunk_width);
    fprintf(f, "Admissible starts: %" PRIu64 "\n", g_total.starts);
    fprintf(f, "C1 count: %" PRIu64 "\n", g_total.c1);
    fprintf(f, "C7 count: %" PRIu64 "\n", g_total.c7);
    fprintf(f, "Unknown: %" PRIu64 "\n", g_total.unknown);
    fprintf(f, "Overflow: %" PRIu64 "\n", g_total.overflow);
    fprintf(f, "Step limit: %" PRIu64 "\n", g_total.step_limit);
    fprintf(f, "Total steps to known cycle: %" PRIu64 "\n", g_total.total_steps);
    fprintf(f, "Mean steps to known cycle: %.12Lf\n", mean);
    fprintf(f, "Max steps to known cycle: %" PRIu64 " at n=%" PRIu64 "\n",
            g_total.max_steps, g_total.max_steps_start);
    fprintf(f, "Global peak: %s at n=%" PRIu64 " step=%" PRIu64 "\n",
            peak, g_total.max_peak_start, g_total.max_peak_step);
    fprintf(f, "Total extra factors of 3 removed: %" PRIu64 "\n", g_total.total_removed);
    fprintf(f, "Max extra factors of 3 in one step: %" PRIu64
               " at start=%" PRIu64 " step=%" PRIu64 "\n",
            g_total.max_removed, g_total.max_removed_start, g_total.max_removed_step);
    fprintf(f, "Wall time: %.6f seconds\n", elapsed);
    fclose(f);
}

int main(int argc, char **argv) {
    if (argc >= 2) {
        g_threads = atoi(argv[1]);
        if (g_threads < 1 || g_threads > 64) {
            fprintf(stderr, "THREADS must be 1..64\n");
            return 1;
        }
    }
    if (argc >= 3) {
        g_chunk_width = strtoull(argv[2], NULL, 10);
        if (g_chunk_width < 1000) {
            fprintf(stderr, "chunk width is too small\n");
            return 1;
        }
    }

    u64 span = RANGE_HI - RANGE_LO + 1;
    g_num_chunks = (span + g_chunk_width - 1) / g_chunk_width;

    g_done = (unsigned char *)calloc((size_t)g_num_chunks, 1);
    if (!g_done) {
        fprintf(stderr, "Cannot allocate checkpoint bitmap.\n");
        return 1;
    }

    stats_zero(&g_total);
    load_checkpoint();

    printf("============================================================\n");
    printf(" Ternary (4k + 1(2))/3 exhaustive extension scan\n");
    printf(" New interval: [%" PRIu64 ", %" PRIu64 "] ; 3 does not divide n\n",
           (u64)RANGE_LO, (u64)RANGE_HI);
    printf(" Threads: %d\n", g_threads);
    printf(" Integer chunk width: %" PRIu64 "\n", g_chunk_width);
    printf(" Chunks: %" PRIu64 "\n", g_num_chunks);
    printf(" Already completed from checkpoint: %" PRIu64 "\n", g_completed_chunks);
    printf(" Arithmetic: unsigned __int128 with overflow detection\n");
    printf(" MAX_STEPS: %" PRIu64 "\n", (u64)MAX_STEPS);
    printf("============================================================\n");
    fflush(stdout);

    g_wall_start = now_sec();
    atomic_init(&g_next_chunk, 0);

    pthread_t *threads = (pthread_t *)calloc((size_t)g_threads, sizeof(pthread_t));
    if (!threads) return 1;

    for (int i = 0; i < g_threads; ++i) {
        if (pthread_create(&threads[i], NULL, worker, NULL) != 0) {
            fprintf(stderr, "pthread_create failed\n");
            return 1;
        }
    }
    for (int i = 0; i < g_threads; ++i) pthread_join(threads[i], NULL);

    double elapsed = now_sec() - g_wall_start;
    write_summary(elapsed);

    char peak[64];
    u128_to_str(g_total.max_peak, peak, sizeof(peak));

    printf("\n================ FINAL NEW-INTERVAL RESULT ================\n");
    printf("starts:       %" PRIu64 "\n", g_total.starts);
    printf("C1:           %" PRIu64 "\n", g_total.c1);
    printf("C7:           %" PRIu64 "\n", g_total.c7);
    printf("unknown:      %" PRIu64 "\n", g_total.unknown);
    printf("overflow:     %" PRIu64 "\n", g_total.overflow);
    printf("step limit:   %" PRIu64 "\n", g_total.step_limit);
    printf("total steps:  %" PRIu64 "\n", g_total.total_steps);
    if (g_total.starts)
        printf("mean steps:   %.12Lf\n",
               (long double)g_total.total_steps / (long double)g_total.starts);
    printf("max steps:    %" PRIu64 " at n=%" PRIu64 "\n",
           g_total.max_steps, g_total.max_steps_start);
    printf("global peak:  %s at n=%" PRIu64 " step=%" PRIu64 "\n",
           peak, g_total.max_peak_start, g_total.max_peak_step);
    printf("max v3 extra: %" PRIu64 " at start=%" PRIu64 " step=%" PRIu64 "\n",
           g_total.max_removed, g_total.max_removed_start, g_total.max_removed_step);
    printf("wall time:    %.3f s\n", elapsed);
    printf("summary:      %s\n", SUMMARY);
    printf("checkpoint:   %s\n", CHECKPOINT);
    printf("===========================================================\n");

    free(threads);
    free(g_done);
    return 0;
}
