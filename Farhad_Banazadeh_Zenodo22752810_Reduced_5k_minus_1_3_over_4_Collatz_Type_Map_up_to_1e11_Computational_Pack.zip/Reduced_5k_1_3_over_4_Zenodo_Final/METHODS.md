# Methods

## Map

The computation is restricted to positive odd starting integers. For each odd state \(n\), the program chooses

- \(r=1\) when \(n\equiv1\pmod4\),
- \(r=3\) when \(n\equiv3\pmod4\),

computes `raw = 5*n - r`, and removes every factor of 2:

\[
T(n)=\frac{5n-r}{2^{v_2(5n-r)}}.
\]

The result is again odd. One application of this accelerated odd-to-odd map counts as one trajectory step.

The two immediate fixed points are

\[
T(1)=1,\qquad T(3)=3.
\]

## Exhaustive search domain

The production run used `max_n = 100000000000` and scanned every positive odd start at or below this value. This yields exactly 50,000,000,000 starting values.

The run was partitioned into 1000 chunks, each containing 50,000,000 odd starts. The chunk file independently records each chunk's exact numerical range and counts.

## Arithmetic

Trajectory states and intermediate raw values use `unsigned __int128`. The implementation checks whether multiplication by 5 would exceed the unsigned 128-bit range before performing the multiplication. Such a path is classified as an overflow event rather than silently wrapping.

No 128-bit overflow event occurred in the deposited \(10^{11}\) run.

## Cycle detection

The production source uses Brent's cycle-detection algorithm with O(1) auxiliary trajectory memory. Reaching 1 or 3 terminates a path as one of the two known fixed points. A repeated state not identified as 1 or 3 is classified as an `other cycle`, with its length and canonical minimum recorded in the cycle output file.

No such cycle was detected in the production run.

## Recorded metrics

### Terminal steps
Number of accelerated odd-to-odd map applications until first arrival at 1, 3, or another detected cycle.

### First-lower time
For starting value \(n_0\), the first positive step \(k\) such that

\[
T^k(n_0)<n_0.
\]

### Odd peak
Largest odd trajectory state encountered, including the starting value.

### Raw peak
Largest intermediate `5*n-r` value before factors of 2 are removed.

### Total /2 count
Total number of factors of 2 removed over all accelerated steps in the trajectory. If a step divides by \(2^s\), it contributes \(s\) to this metric.

## Deterministic record ties

When equal record values occur, the implementation selects the smaller starting value. This makes reported records deterministic across thread scheduling orders.

## Parallelization and durability

The scanner uses POSIX threads. Completed chunks are appended to the chunk TSV and flushed before being treated as durable. The same command may be rerun with the same output prefix; already completed chunks are skipped. This provides a checkpoint/resume mechanism for long runs.
