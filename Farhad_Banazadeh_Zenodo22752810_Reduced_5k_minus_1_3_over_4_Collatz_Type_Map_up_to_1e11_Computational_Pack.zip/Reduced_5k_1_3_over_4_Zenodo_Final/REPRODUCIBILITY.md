# Reproducibility

## Compiler requirement

The source requires a C compiler supporting `unsigned __int128`. It was designed for clang on macOS and uses POSIX threads.

## Build

```bash
clang -O3 -march=native -pthread -std=c11 -Wall -Wextra src/scan_5n_128.c -o scan_5n_128
```

## Small validation run

```bash
./scan_5n_128 -m 1000000 -t 4 -c 100000 -o test_1e6_repro
```

Expected final values include:

```text
total_odd_starts=500000
completed_starts=500000
reached_1=323407
reached_3=176593
other_cycles=0
u128_overflows=0
best_terminal_n=575945
best_terminal_steps=87
best_first_lower_n=575945
best_first_lower_sigma=58
best_odd_peak_n=640515
best_odd_peak=51740141
best_raw_peak_n=640515
best_raw_peak=258700704
best_div2_n=575945
best_div2_total=221
```

## Production configuration

The deposited production run corresponds to:

```bash
./scan_5n_128 -m 100000000000 -t 4 -c 50000000 -o scan_1e11
```

This scans 50,000,000,000 odd starts in 1000 chunks.

## Resume behavior

If execution is interrupted, rerun the exact same command with the same output prefix. The program reads the existing `.chunks.tsv`, reconstructs completed work and current global records, and skips already durable chunks.

## Independent package check

```bash
python3 verify_results.py
```

This checker verifies:

1. all chunk IDs 0 through 999 are present exactly once;
2. every chunk has the expected range and 50,000,000 odd starts;
3. all outcome counts sum exactly to 50,000,000,000;
4. final outcome totals match the summary;
5. global records reconstructed from all chunk rows match the summary;
6. the cycle output is header-only;
7. the stored \(10^6\) validation summary matches the reference result.

## Binary note

The archived `bin/macOS/scan_5n_128_original` is included for provenance. It is platform/architecture dependent and should not be treated as the canonical executable. The C source is the canonical implementation for rebuilding.
