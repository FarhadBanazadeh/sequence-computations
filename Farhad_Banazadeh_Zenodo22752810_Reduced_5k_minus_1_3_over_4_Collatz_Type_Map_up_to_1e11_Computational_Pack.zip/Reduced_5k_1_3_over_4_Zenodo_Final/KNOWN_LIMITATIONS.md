# Known limitations and scope

1. **Finite verification only.** The computation establishes the reported behavior only for positive odd starts through \(10^{11}\). It does not prove global convergence or exclude cycles beyond the tested domain.

2. **128-bit production arithmetic.** The exact source used for this run detects an impending unsigned-128-bit overflow and increments the overflow count instead of wrapping. It does **not** save the complete pre-overflow trajectory state to a dedicated overflow file. This did not affect the deposited result because `u128_overflows=0` for the full production run.

3. **Future overflow logging.** For larger searches, a revised scanner should persist at least the original start, current 128-bit state, accelerated step, current peaks, total removed powers of 2, and pending operation whenever a 128-bit boundary event is detected. Such saved candidates can then be continued with arbitrary-precision arithmetic.

4. **Runtime measurements.** Per-chunk elapsed times are included in the raw TSV but may reflect OS scheduling, thermal throttling, sleep/wake events, or other machine activity. They should not be interpreted as controlled benchmarking data.

5. **Thread scheduling.** Chunk completion order is nondeterministic under multithreading. Numerical results and record tie-breaking are deterministic.
