# Results

## Exhaustive run through \(10^{11}\)

All 50,000,000,000 positive odd starts with \(n\le10^{11}\) were accounted for.

| Outcome | Count | Percentage |
|---|---:|---:|
| Reached 1 | 32,318,909,987 | 64.637819974% |
| Reached 3 | 17,681,090,013 | 35.362180026% |
| Other detected cycles | 0 | 0% |
| 128-bit overflow events | 0 | 0% |
| **Total** | **50,000,000,000** | **100%** |

The identity

\[
32,318,909,987+17,681,090,013=50,000,000,000
\]

provides an exact outcome-count check because both exceptional categories are zero.

## Global records

- Maximum terminal steps: **192**, attained at start **86,568,413,515**.
- Maximum first-lower time: **102**, attained at start **25,450,479,209**.
- Maximum odd peak: **303,776,985,040,453**, attained by start **62,483,301,665** at accelerated step **66**.
- Maximum raw peak: **1,518,884,925,202,264**, attained by start **62,483,301,665** at accelerated step **67**.
- Maximum total number of removed factors of 2: **482**, attained at start **86,568,413,515**.

## Cycle result

The `scan_1e11.cycles.tsv` file contains only its header. Therefore no non-{1,3} cycle encounter was recorded during the exhaustive run.

The conclusion is deliberately finite:

> For every tested positive odd starting value \(n\le10^{11}\), the accelerated map eventually reached 1 or 3, and no other cycle was detected.

This statement is computational evidence over the stated finite domain and is not presented as a proof for all positive odd integers.
