#!/usr/bin/env python3
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
TESTS = ROOT / 'tests'

def read_summary(path):
    out = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        if '=' in line and not line.startswith('map:'):
            k, v = line.split('=', 1)
            out[k.strip()] = v.strip()
    return out

with (DATA/'scan_1e11.chunks.tsv').open(newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f, delimiter='\t'))

assert len(rows) == 1000, f'expected 1000 chunks, got {len(rows)}'
ids = sorted(int(r['chunk_id']) for r in rows)
assert ids == list(range(1000)), 'chunk IDs are not exactly 0..999'

# Structural range checks. Each chunk contains 50,000,000 odd starts = width 100,000,000 in n.
for r in rows:
    cid = int(r['chunk_id'])
    assert int(r['starts']) == 50_000_000
    assert int(r['n_lo']) == cid * 100_000_000 + 1
    assert int(r['n_hi']) == (cid + 1) * 100_000_000 - 1

num = lambda k: sum(int(r[k]) for r in rows)
total = num('starts')
r1 = num('reached1')
r3 = num('reached3')
other = num('other_cycles')
ov = num('overflows')
assert total == 50_000_000_000
assert r1 + r3 + other + ov == total
assert (r1, r3, other, ov) == (32_318_909_987, 17_681_090_013, 0, 0)

# Global records reconstructed from chunk-local maxima.
def best(nkey, vkey, stepkey=None):
    vmax = max(int(r[vkey]) for r in rows)
    candidates = [r for r in rows if int(r[vkey]) == vmax]
    nmin = min(int(r[nkey]) for r in candidates)
    rr = next(r for r in candidates if int(r[nkey]) == nmin)
    return nmin, vmax, (int(rr[stepkey]) if stepkey else None)

assert best('max_terminal_n', 'max_terminal_steps')[:2] == (86_568_413_515, 192)
assert best('max_firstlower_n', 'max_firstlower_step')[:2] == (25_450_479_209, 102)
assert best('max_oddpeak_n', 'max_oddpeak', 'max_oddpeak_step') == (62_483_301_665, 303_776_985_040_453, 66)
assert best('max_rawpeak_n', 'max_rawpeak', 'max_rawpeak_step') == (62_483_301_665, 1_518_884_925_202_264, 67)
assert best('max_div2_n', 'max_div2_total')[:2] == (86_568_413_515, 482)

summary = read_summary(DATA/'scan_1e11.summary.txt')
expected = {
    'max_n':'100000000000', 'total_odd_starts':'50000000000', 'completed_starts':'50000000000',
    'reached_1':'32318909987', 'reached_3':'17681090013', 'other_cycles':'0', 'u128_overflows':'0',
    'best_terminal_n':'86568413515', 'best_terminal_steps':'192',
    'best_first_lower_n':'25450479209', 'best_first_lower_sigma':'102',
    'best_odd_peak_n':'62483301665', 'best_odd_peak':'303776985040453', 'best_odd_peak_step':'66',
    'best_raw_peak_n':'62483301665', 'best_raw_peak':'1518884925202264', 'best_raw_peak_step':'67',
    'best_div2_n':'86568413515', 'best_div2_total':'482'
}
for k,v in expected.items():
    assert summary.get(k) == v, f'summary mismatch {k}: {summary.get(k)} != {v}'

# cycles file must contain only its header for this run.
cycle_lines = (DATA/'scan_1e11.cycles.tsv').read_text(encoding='utf-8').splitlines()
assert cycle_lines == ['chunk_id\tstart_n\tcycle_len\tcycle_min']

# Reference 1e6 test stored in the package.
t1 = read_summary(TESTS/'test_1e6.summary.txt')
assert t1['completed_starts'] == '500000'
assert t1['reached_1'] == '323407' and t1['reached_3'] == '176593'
assert t1['other_cycles'] == '0' and t1['u128_overflows'] == '0'
assert t1['best_terminal_n'] == '575945' and t1['best_terminal_steps'] == '87'
assert t1['best_odd_peak'] == '51740141' and t1['best_raw_peak'] == '258700704'

print('PASS: package structure and numerical results are internally consistent.')
print(f'PASS: {total:,} odd starts accounted for exactly.')
print(f'PASS: reached 1 = {r1:,}; reached 3 = {r3:,}; other cycles = {other}; u128 overflows = {ov}.')
print('PASS: global records reconstructed from all 1000 chunk rows match the final summary.')
print('PASS: stored 1e6 validation result matches the known reference values.')
