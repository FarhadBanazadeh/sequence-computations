#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <pthread.h>
#include <stdatomic.h>
#include <unistd.h>
#include <getopt.h>

#if !defined(__SIZEOF_INT128__)
#error "This compiler does not support unsigned __int128"
#endif

typedef unsigned __int128 u128;
typedef uint64_t u64;

static const u128 U128_MAXV = (u128)(~(u128)0);

typedef struct {
    u64 n;
    u64 value;
} Rec64;

typedef struct {
    u64 start_n;
    u128 value;
    u64 step;
} Rec128;

typedef struct {
    u64 start_n;
    u64 cycle_len;
    u128 cycle_min;
} CycleHit;

typedef struct {
    u64 chunk_id;
    u64 idx_lo, idx_hi;      // odd-index range [lo, hi)
    u64 n_lo, n_hi;          // actual odd n range inclusive
    u64 starts;
    double seconds;

    u64 reached1, reached3, other_cycles, overflows;

    Rec64 max_terminal;      // value = odd->odd steps to first 1/3/other-cycle
    Rec64 max_first_lower;   // value = first step where trajectory < start; UINT64_MAX if none per path, never chosen
    Rec128 max_odd_peak;
    Rec128 max_raw_peak;
    Rec64 max_div2_total;

    CycleHit *cycle_hits;
    size_t cycle_count, cycle_cap;
} ChunkResult;

typedef struct {
    u64 max_n;
    u64 total_starts;
    u64 chunk_starts;
    u64 num_chunks;
    int threads;
    char prefix[512];
    char chunks_path[640];
    char records_path[640];
    char cycles_path[640];
    char summary_path[640];

    bool *completed;
    atomic_ullong next_chunk;

    pthread_mutex_t lock;
    FILE *chunks_fp;
    FILE *records_fp;
    FILE *cycles_fp;

    u64 done_chunks;
    u64 done_starts;
    u64 reached1, reached3, other_cycles, overflows;

    Rec64 best_terminal;
    Rec64 best_first_lower;
    Rec128 best_odd_peak;
    Rec128 best_raw_peak;
    Rec64 best_div2_total;

    struct timespec session_t0;
} Global;

typedef struct { Global *g; int tid; } WorkerArg;

static inline double now_seconds(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static void u128_to_str(u128 x, char *buf, size_t cap) {
    if (cap == 0) return;
    if (x == 0) { if (cap > 1) { buf[0] = '0'; buf[1] = '\0'; } return; }
    char tmp[64];
    size_t i = 0;
    while (x && i < sizeof(tmp)) {
        unsigned d = (unsigned)(x % 10);
        tmp[i++] = (char)('0' + d);
        x /= 10;
    }
    size_t out = 0;
    while (i && out + 1 < cap) buf[out++] = tmp[--i];
    buf[out] = '\0';
}

static bool str_to_u128(const char *s, u128 *out) {
    if (!s || !*s) return false;
    u128 x = 0;
    for (const unsigned char *p = (const unsigned char*)s; *p; ++p) {
        if (*p < '0' || *p > '9') return false;
        unsigned d = (unsigned)(*p - '0');
        if (x > (U128_MAXV - d) / 10) return false;
        x = x * 10 + d;
    }
    *out = x;
    return true;
}

static inline unsigned ctz128(u128 x) {
    u64 lo = (u64)x;
    if (lo) return (unsigned)__builtin_ctzll(lo);
    u64 hi = (u64)(x >> 64);
    return 64u + (unsigned)__builtin_ctzll(hi);
}

// One accelerated odd->odd map step.
// For odd n: r=1 when n=1 mod 4, else r=3.
// raw = 5n-r, then remove ALL powers of 2.
static inline bool next_odd(u128 n, u128 *next, u128 *raw, unsigned *div2) {
    // max mod 5 == 0 for 2^128-1, so n > max/5 cannot be saved by subtracting r<=3.
    if (n > U128_MAXV / 5u) return false;
    u128 r = ((n & 3u) == 1u) ? 1u : 3u;
    u128 x = n * 5u - r;
    unsigned s = ctz128(x); // x is nonzero and divisible by at least 4 for odd n
    *raw = x;
    *div2 = s;
    *next = x >> s;
    return true;
}

typedef enum { DEST_1=1, DEST_3=3, DEST_OTHER=9, DEST_OVERFLOW=10 } Dest;

typedef struct {
    Dest dest;
    u64 steps;
    u64 first_lower_step; // UINT64_MAX if never before terminal/cycle
    u64 div2_total;
    u128 odd_peak;
    u64 odd_peak_step;
    u128 raw_peak;
    u64 raw_peak_step;
    u64 cycle_len;
    u128 cycle_min;
} PathStats;

static PathStats analyze_start(u64 start) {
    PathStats ps;
    memset(&ps, 0, sizeof(ps));
    ps.first_lower_step = UINT64_MAX;
    ps.odd_peak = (u128)start;
    ps.odd_peak_step = 0;
    ps.raw_peak = 0;
    ps.raw_peak_step = 0;
    ps.cycle_min = 0;

    if (start == 1) { ps.dest = DEST_1; return ps; }
    if (start == 3) { ps.dest = DEST_3; return ps; }

    u128 start128 = (u128)start;
    u128 hare = start128;

    // Brent cycle detection integrated into the primary traversal: one map evaluation per step.
    u128 tortoise = hare;
    u64 power = 1, lam = 0;

    for (;;) {
        u128 nxt, raw;
        unsigned d2;
        if (!next_odd(hare, &nxt, &raw, &d2)) {
            ps.dest = DEST_OVERFLOW;
            return ps;
        }

        ps.steps++;
        ps.div2_total += d2;
        if (raw > ps.raw_peak) { ps.raw_peak = raw; ps.raw_peak_step = ps.steps; }
        hare = nxt;
        if (hare > ps.odd_peak) { ps.odd_peak = hare; ps.odd_peak_step = ps.steps; }
        if (ps.first_lower_step == UINT64_MAX && hare < start128) ps.first_lower_step = ps.steps;

        if (hare == 1) { ps.dest = DEST_1; return ps; }
        if (hare == 3) { ps.dest = DEST_3; return ps; }

        lam++;
        if (hare == tortoise) {
            // A non-1/3 cycle was encountered. Canonicalize by minimum member.
            ps.dest = DEST_OTHER;
            ps.cycle_len = lam;
            u128 x = hare;
            u128 mn = hare;
            for (u64 i = 0; i < lam; ++i) {
                u128 y, rr; unsigned dd;
                if (!next_odd(x, &y, &rr, &dd)) break; // cannot happen for an already traversed finite cycle
                x = y;
                if (x < mn) mn = x;
            }
            ps.cycle_min = mn;
            return ps;
        }
        if (lam == power) {
            tortoise = hare;
            if (power <= UINT64_MAX/2) power <<= 1;
            lam = 0;
        }
    }
}

static void init_chunk_result(ChunkResult *r, u64 cid, u64 ilo, u64 ihi) {
    memset(r, 0, sizeof(*r));
    r->chunk_id = cid;
    r->idx_lo = ilo; r->idx_hi = ihi;
    r->starts = ihi - ilo;
    r->n_lo = 2u * ilo + 1u;
    r->n_hi = (ihi > ilo) ? (2u * (ihi - 1u) + 1u) : r->n_lo;
}

static void push_cycle_hit(ChunkResult *r, u64 start_n, u64 cycle_len, u128 cycle_min) {
    if (r->cycle_count == r->cycle_cap) {
        size_t nc = r->cycle_cap ? r->cycle_cap * 2 : 8;
        CycleHit *nv = realloc(r->cycle_hits, nc * sizeof(*nv));
        if (!nv) { fprintf(stderr, "fatal: realloc cycle_hits failed\n"); exit(1); }
        r->cycle_hits = nv; r->cycle_cap = nc;
    }
    r->cycle_hits[r->cycle_count++] = (CycleHit){start_n, cycle_len, cycle_min};
}

static void scan_chunk(ChunkResult *r) {
    double t0 = now_seconds();
    for (u64 idx = r->idx_lo; idx < r->idx_hi; ++idx) {
        u64 n = 2u * idx + 1u;
        PathStats ps = analyze_start(n);

        if (ps.dest == DEST_1) r->reached1++;
        else if (ps.dest == DEST_3) r->reached3++;
        else if (ps.dest == DEST_OTHER) {
            r->other_cycles++;
            push_cycle_hit(r, n, ps.cycle_len, ps.cycle_min);
        } else r->overflows++;

        if (ps.steps > r->max_terminal.value || (ps.steps == r->max_terminal.value && ps.steps && n < r->max_terminal.n)) {
            r->max_terminal.n = n; r->max_terminal.value = ps.steps;
        }
        if (ps.first_lower_step != UINT64_MAX && (ps.first_lower_step > r->max_first_lower.value || (ps.first_lower_step == r->max_first_lower.value && ps.first_lower_step && n < r->max_first_lower.n))) {
            r->max_first_lower.n = n; r->max_first_lower.value = ps.first_lower_step;
        }
        if (ps.odd_peak > r->max_odd_peak.value || (ps.odd_peak == r->max_odd_peak.value && n < r->max_odd_peak.start_n)) {
            r->max_odd_peak.start_n = n; r->max_odd_peak.value = ps.odd_peak; r->max_odd_peak.step = ps.odd_peak_step;
        }
        if (ps.raw_peak > r->max_raw_peak.value || (ps.raw_peak == r->max_raw_peak.value && n < r->max_raw_peak.start_n)) {
            r->max_raw_peak.start_n = n; r->max_raw_peak.value = ps.raw_peak; r->max_raw_peak.step = ps.raw_peak_step;
        }
        if (ps.div2_total > r->max_div2_total.value || (ps.div2_total == r->max_div2_total.value && ps.div2_total && n < r->max_div2_total.n)) {
            r->max_div2_total.n = n; r->max_div2_total.value = ps.div2_total;
        }
    }
    r->seconds = now_seconds() - t0;
}

static void append_record64(FILE *fp, const char *kind, u64 chunk, Rec64 x) {
    fprintf(fp, "%s\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t\n", kind, chunk, x.n, x.value);
}

static void append_record128(FILE *fp, const char *kind, u64 chunk, Rec128 x) {
    char v[64]; u128_to_str(x.value, v, sizeof(v));
    fprintf(fp, "%s\t%" PRIu64 "\t%" PRIu64 "\t%s\t%" PRIu64 "\n", kind, chunk, x.start_n, v, x.step);
}

static void print_progress_locked(Global *g, const ChunkResult *r, int tid) {
    char op[64], rp[64];
    u128_to_str(g->best_odd_peak.value, op, sizeof(op));
    u128_to_str(g->best_raw_peak.value, rp, sizeof(rp));
    double elapsed = now_seconds() - ((double)g->session_t0.tv_sec + (double)g->session_t0.tv_nsec*1e-9);
    double rate = elapsed > 0 ? (double)g->done_starts / elapsed : 0.0;
    double pct = g->total_starts ? 100.0 * (double)g->done_starts / (double)g->total_starts : 100.0;
    double chunk_rate = r->seconds > 0 ? (double)r->starts / r->seconds : 0.0;

    printf("\n============================================================\n");
    printf("thread:          %d\n", tid);
    printf("chunk:           %" PRIu64 " / %" PRIu64 "\n", r->chunk_id + 1, g->num_chunks);
    printf("n-range:         [%-" PRIu64 ", %-" PRIu64 "] odd only\n", r->n_lo, r->n_hi);
    printf("chunk starts:    %" PRIu64 "\n", r->starts);
    printf("chunk seconds:   %.3f\n", r->seconds);
    printf("chunk rate:      %.0f starts/sec\n", chunk_rate);
    printf("session rate:    %.0f starts/sec\n", rate);
    printf("total starts:    %" PRIu64 " / %" PRIu64 "\n", g->done_starts, g->total_starts);
    printf("complete:        %.6f %%\n", pct);
    printf("reached 1:       %" PRIu64 "\n", g->reached1);
    printf("reached 3:       %" PRIu64 "\n", g->reached3);
    printf("other cycles:    %" PRIu64 "\n", g->other_cycles);
    printf("128 overflows:   %" PRIu64 "\n", g->overflows);
    printf("best terminal:   n=%" PRIu64 " steps=%" PRIu64 "\n", g->best_terminal.n, g->best_terminal.value);
    printf("best firstlower: n=%" PRIu64 " sigma=%" PRIu64 "\n", g->best_first_lower.n, g->best_first_lower.value);
    printf("best odd peak:   n=%" PRIu64 " peak=%s step=%" PRIu64 "\n", g->best_odd_peak.start_n, op, g->best_odd_peak.step);
    printf("best raw peak:   n=%" PRIu64 " peak=%s step=%" PRIu64 "\n", g->best_raw_peak.start_n, rp, g->best_raw_peak.step);
    printf("best /2 total:   n=%" PRIu64 " div2=%" PRIu64 "\n", g->best_div2_total.n, g->best_div2_total.value);
    printf("============================================================\n");
    fflush(stdout);
}

static void commit_chunk(Global *g, const ChunkResult *r, int tid) {
    pthread_mutex_lock(&g->lock);

    char op[64], rp[64];
    u128_to_str(r->max_odd_peak.value, op, sizeof(op));
    u128_to_str(r->max_raw_peak.value, rp, sizeof(rp));

    // chunk_id is first field; a full flushed line is the durable checkpoint.
    fprintf(g->chunks_fp,
        "%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%.6f\t"
        "%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t"
        "%" PRIu64 "\t%" PRIu64 "\t"
        "%" PRIu64 "\t%" PRIu64 "\t"
        "%" PRIu64 "\t%s\t%" PRIu64 "\t"
        "%" PRIu64 "\t%s\t%" PRIu64 "\t"
        "%" PRIu64 "\t%" PRIu64 "\n",
        r->chunk_id, r->n_lo, r->n_hi, r->starts, r->seconds,
        r->reached1, r->reached3, r->other_cycles, r->overflows,
        r->max_terminal.n, r->max_terminal.value,
        r->max_first_lower.n, r->max_first_lower.value,
        r->max_odd_peak.start_n, op, r->max_odd_peak.step,
        r->max_raw_peak.start_n, rp, r->max_raw_peak.step,
        r->max_div2_total.n, r->max_div2_total.value);
    fflush(g->chunks_fp);

    g->completed[r->chunk_id] = true;
    g->done_chunks++;
    g->done_starts += r->starts;
    g->reached1 += r->reached1; g->reached3 += r->reached3;
    g->other_cycles += r->other_cycles; g->overflows += r->overflows;

    for (size_t i = 0; i < r->cycle_count; ++i) {
        char cm[64]; u128_to_str(r->cycle_hits[i].cycle_min, cm, sizeof(cm));
        fprintf(g->cycles_fp, "%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%s\n",
                r->chunk_id, r->cycle_hits[i].start_n, r->cycle_hits[i].cycle_len, cm);
    }
    if (r->cycle_count) fflush(g->cycles_fp);

    if (r->max_terminal.value > g->best_terminal.value || (r->max_terminal.value == g->best_terminal.value && r->max_terminal.value && r->max_terminal.n < g->best_terminal.n)) {
        g->best_terminal = r->max_terminal;
        append_record64(g->records_fp, "terminal_steps", r->chunk_id, g->best_terminal);
    }
    if (r->max_first_lower.value > g->best_first_lower.value || (r->max_first_lower.value == g->best_first_lower.value && r->max_first_lower.value && r->max_first_lower.n < g->best_first_lower.n)) {
        g->best_first_lower = r->max_first_lower;
        append_record64(g->records_fp, "first_lower", r->chunk_id, g->best_first_lower);
    }
    if (r->max_odd_peak.value > g->best_odd_peak.value || (r->max_odd_peak.value == g->best_odd_peak.value && r->max_odd_peak.start_n < g->best_odd_peak.start_n)) {
        g->best_odd_peak = r->max_odd_peak;
        append_record128(g->records_fp, "odd_peak", r->chunk_id, g->best_odd_peak);
    }
    if (r->max_raw_peak.value > g->best_raw_peak.value || (r->max_raw_peak.value == g->best_raw_peak.value && r->max_raw_peak.start_n < g->best_raw_peak.start_n)) {
        g->best_raw_peak = r->max_raw_peak;
        append_record128(g->records_fp, "raw_peak", r->chunk_id, g->best_raw_peak);
    }
    if (r->max_div2_total.value > g->best_div2_total.value || (r->max_div2_total.value == g->best_div2_total.value && r->max_div2_total.value && r->max_div2_total.n < g->best_div2_total.n)) {
        g->best_div2_total = r->max_div2_total;
        append_record64(g->records_fp, "div2_total", r->chunk_id, g->best_div2_total);
    }
    fflush(g->records_fp);

    print_progress_locked(g, r, tid);
    pthread_mutex_unlock(&g->lock);
}

static void *worker_main(void *vp) {
    WorkerArg *wa = (WorkerArg*)vp;
    Global *g = wa->g;
    for (;;) {
        u64 cid = atomic_fetch_add(&g->next_chunk, 1);
        if (cid >= g->num_chunks) break;
        if (g->completed[cid]) continue;

        u64 ilo = cid * g->chunk_starts;
        u64 ihi = ilo + g->chunk_starts;
        if (ihi > g->total_starts) ihi = g->total_starts;
        ChunkResult r;
        init_chunk_result(&r, cid, ilo, ihi);
        scan_chunk(&r);
        commit_chunk(g, &r, wa->tid);
        free(r.cycle_hits);
    }
    return NULL;
}

static void write_headers_if_empty(FILE *fp, const char *header) {
    long pos;
    fseek(fp, 0, SEEK_END);
    pos = ftell(fp);
    if (pos == 0) { fputs(header, fp); fflush(fp); }
}

static int split_tabs(char *line, char **f, int maxf) {
    int n = 0;
    char *save = NULL;
    for (char *p = strtok_r(line, "\t\r\n", &save); p && n < maxf; p = strtok_r(NULL, "\t\r\n", &save)) f[n++] = p;
    return n;
}

static void fold_loaded_chunk(Global *g, char **f) {
    // Expected 21 fields; parsing only fully formed lines.
    u64 cid = strtoull(f[0], NULL, 10);
    if (cid >= g->num_chunks || g->completed[cid]) return;

    u64 starts = strtoull(f[3], NULL, 10);
    u64 r1 = strtoull(f[5], NULL, 10), r3 = strtoull(f[6], NULL, 10);
    u64 oth = strtoull(f[7], NULL, 10), ov = strtoull(f[8], NULL, 10);
    Rec64 terminal = {strtoull(f[9],NULL,10), strtoull(f[10],NULL,10)};
    Rec64 firstlow = {strtoull(f[11],NULL,10), strtoull(f[12],NULL,10)};
    Rec128 odd = {strtoull(f[13],NULL,10),0,strtoull(f[15],NULL,10)};
    Rec128 raw = {strtoull(f[16],NULL,10),0,strtoull(f[18],NULL,10)};
    Rec64 div2 = {strtoull(f[19],NULL,10), strtoull(f[20],NULL,10)};
    if (!str_to_u128(f[14], &odd.value) || !str_to_u128(f[17], &raw.value)) return;

    g->completed[cid] = true; g->done_chunks++; g->done_starts += starts;
    g->reached1 += r1; g->reached3 += r3; g->other_cycles += oth; g->overflows += ov;
    if (terminal.value > g->best_terminal.value || (terminal.value == g->best_terminal.value && terminal.value && terminal.n < g->best_terminal.n)) g->best_terminal = terminal;
    if (firstlow.value > g->best_first_lower.value || (firstlow.value == g->best_first_lower.value && firstlow.value && firstlow.n < g->best_first_lower.n)) g->best_first_lower = firstlow;
    if (odd.value > g->best_odd_peak.value || (odd.value == g->best_odd_peak.value && odd.start_n < g->best_odd_peak.start_n)) g->best_odd_peak = odd;
    if (raw.value > g->best_raw_peak.value || (raw.value == g->best_raw_peak.value && raw.start_n < g->best_raw_peak.start_n)) g->best_raw_peak = raw;
    if (div2.value > g->best_div2_total.value || (div2.value == g->best_div2_total.value && div2.value && div2.n < g->best_div2_total.n)) g->best_div2_total = div2;
}

static void load_resume(Global *g) {
    FILE *fp = fopen(g->chunks_path, "r");
    if (!fp) return;
    char *line = NULL; size_t cap = 0; ssize_t nr;
    bool first = true;
    while ((nr = getline(&line, &cap, fp)) >= 0) {
        if (first) { first = false; if (strncmp(line, "chunk_id\t", 9)==0) continue; }
        char *fields[24];
        int nf = split_tabs(line, fields, 24);
        if (nf == 21) fold_loaded_chunk(g, fields);
    }
    free(line); fclose(fp);
}

static void write_summary(Global *g) {
    FILE *fp = fopen(g->summary_path, "w");
    if (!fp) return;
    char op[64], rp[64];
    u128_to_str(g->best_odd_peak.value, op, sizeof(op));
    u128_to_str(g->best_raw_peak.value, rp, sizeof(rp));
    fprintf(fp, "map: T(n)=(5n-r)/2^v2(5n-r), r=1 if n%%4=1 else 3; odd n only\n");
    fprintf(fp, "max_n=%" PRIu64 "\n", g->max_n);
    fprintf(fp, "total_odd_starts=%" PRIu64 "\n", g->total_starts);
    fprintf(fp, "completed_starts=%" PRIu64 "\n", g->done_starts);
    fprintf(fp, "reached_1=%" PRIu64 "\n", g->reached1);
    fprintf(fp, "reached_3=%" PRIu64 "\n", g->reached3);
    fprintf(fp, "other_cycles=%" PRIu64 "\n", g->other_cycles);
    fprintf(fp, "u128_overflows=%" PRIu64 "\n", g->overflows);
    fprintf(fp, "best_terminal_n=%" PRIu64 "\n", g->best_terminal.n);
    fprintf(fp, "best_terminal_steps=%" PRIu64 "\n", g->best_terminal.value);
    fprintf(fp, "best_first_lower_n=%" PRIu64 "\n", g->best_first_lower.n);
    fprintf(fp, "best_first_lower_sigma=%" PRIu64 "\n", g->best_first_lower.value);
    fprintf(fp, "best_odd_peak_n=%" PRIu64 "\n", g->best_odd_peak.start_n);
    fprintf(fp, "best_odd_peak=%s\n", op);
    fprintf(fp, "best_odd_peak_step=%" PRIu64 "\n", g->best_odd_peak.step);
    fprintf(fp, "best_raw_peak_n=%" PRIu64 "\n", g->best_raw_peak.start_n);
    fprintf(fp, "best_raw_peak=%s\n", rp);
    fprintf(fp, "best_raw_peak_step=%" PRIu64 "\n", g->best_raw_peak.step);
    fprintf(fp, "best_div2_n=%" PRIu64 "\n", g->best_div2_total.n);
    fprintf(fp, "best_div2_total=%" PRIu64 "\n", g->best_div2_total.value);
    fclose(fp);
}

static void usage(const char *argv0) {
    fprintf(stderr,
        "Usage: %s [-m max_n] [-t threads] [-c odd_starts_per_chunk] [-o prefix]\n"
        "Defaults: -m 10000000000 -t 4 -c 10000000 -o scan_5n_1e10\n"
        "Example:  %s -m 10000000000 -t 4 -c 10000000 -o run_1e10\n",
        argv0, argv0);
}

int main(int argc, char **argv) {
    Global g; memset(&g, 0, sizeof(g));
    g.max_n = UINT64_C(10000000000);
    g.chunk_starts = UINT64_C(10000000);
    g.threads = 4;
    snprintf(g.prefix, sizeof(g.prefix), "scan_5n_1e10");

    int opt;
    while ((opt = getopt(argc, argv, "m:t:c:o:h")) != -1) {
        switch (opt) {
            case 'm': g.max_n = strtoull(optarg, NULL, 10); break;
            case 't': g.threads = atoi(optarg); break;
            case 'c': g.chunk_starts = strtoull(optarg, NULL, 10); break;
            case 'o': snprintf(g.prefix, sizeof(g.prefix), "%s", optarg); break;
            default: usage(argv[0]); return opt=='h' ? 0 : 2;
        }
    }
    if (g.max_n < 1 || g.chunk_starts < 1 || g.threads < 1 || g.threads > 64) { usage(argv[0]); return 2; }

    // Number of positive odd integers <= max_n.
    g.total_starts = (g.max_n + 1u) / 2u;
    g.num_chunks = (g.total_starts + g.chunk_starts - 1u) / g.chunk_starts;
    g.completed = calloc((size_t)g.num_chunks, sizeof(bool));
    if (!g.completed) { perror("calloc"); return 1; }

    snprintf(g.chunks_path, sizeof(g.chunks_path), "%s.chunks.tsv", g.prefix);
    snprintf(g.records_path, sizeof(g.records_path), "%s.records.tsv", g.prefix);
    snprintf(g.cycles_path, sizeof(g.cycles_path), "%s.cycles.tsv", g.prefix);
    snprintf(g.summary_path, sizeof(g.summary_path), "%s.summary.txt", g.prefix);

    load_resume(&g);

    g.chunks_fp = fopen(g.chunks_path, "a+");
    g.records_fp = fopen(g.records_path, "a+");
    g.cycles_fp = fopen(g.cycles_path, "a+");
    if (!g.chunks_fp || !g.records_fp || !g.cycles_fp) { perror("fopen output"); return 1; }

    write_headers_if_empty(g.chunks_fp,
      "chunk_id\tn_lo\tn_hi\tstarts\tseconds\treached1\treached3\tother_cycles\toverflows\t"
      "max_terminal_n\tmax_terminal_steps\tmax_firstlower_n\tmax_firstlower_step\t"
      "max_oddpeak_n\tmax_oddpeak\tmax_oddpeak_step\tmax_rawpeak_n\tmax_rawpeak\tmax_rawpeak_step\t"
      "max_div2_n\tmax_div2_total\n");
    write_headers_if_empty(g.records_fp, "kind\tchunk_id\tstart_n\tvalue\tstep_optional\n");
    write_headers_if_empty(g.cycles_fp, "chunk_id\tstart_n\tcycle_len\tcycle_min\n");

    pthread_mutex_init(&g.lock, NULL);
    atomic_init(&g.next_chunk, 0);
    clock_gettime(CLOCK_MONOTONIC, &g.session_t0);

    printf("5n-r accelerated odd-map scanner (128-bit)\n");
    printf("max n:         %" PRIu64 "\n", g.max_n);
    printf("odd starts:    %" PRIu64 "\n", g.total_starts);
    printf("threads:       %d\n", g.threads);
    printf("chunk starts:  %" PRIu64 "\n", g.chunk_starts);
    printf("chunks:        %" PRIu64 "\n", g.num_chunks);
    printf("resume found:  %" PRIu64 " completed chunks (%" PRIu64 " starts)\n", g.done_chunks, g.done_starts);
    printf("prefix:        %s\n", g.prefix);
    fflush(stdout);

    pthread_t *ths = calloc((size_t)g.threads, sizeof(pthread_t));
    WorkerArg *args = calloc((size_t)g.threads, sizeof(WorkerArg));
    if (!ths || !args) { perror("calloc threads"); return 1; }

    for (int i = 0; i < g.threads; ++i) {
        args[i].g = &g; args[i].tid = i;
        if (pthread_create(&ths[i], NULL, worker_main, &args[i]) != 0) { perror("pthread_create"); return 1; }
    }
    for (int i = 0; i < g.threads; ++i) pthread_join(ths[i], NULL);

    write_summary(&g);
    printf("\nDONE. Summary: %s\n", g.summary_path);

    fclose(g.chunks_fp); fclose(g.records_fp); fclose(g.cycles_fp);
    pthread_mutex_destroy(&g.lock);
    free(ths); free(args); free(g.completed);
    return 0;
}
