5n-r accelerated odd-map scanner — macOS / clang
=================================================

Map
---
For every positive odd n:
  r = 1 if n mod 4 = 1
  r = 3 if n mod 4 = 3
  raw = 5*n - r
  T(n) = raw / 2^v2(raw)
All trajectory arithmetic uses unsigned __int128.

Compile on Mac
--------------
clang -O3 -march=native -pthread -std=c11 -Wall -Wextra scan_5n_128.c -o scan_5n_128

Recommended full run for the 4-logical-CPU Mac
-----------------------------------------------
./scan_5n_128 -m 10000000000 -t 4 -c 10000000 -o scan_5n_1e10

Small validation run
--------------------
./scan_5n_128 -m 1000000 -t 4 -c 100000 -o test_1e6

Resume
------
Run the exact same command again with the same -o prefix. Completed chunks in
<prefix>.chunks.tsv are skipped automatically.

Output files
------------
<prefix>.chunks.tsv   one durable row per completed chunk; also acts as checkpoint
<prefix>.records.tsv  new global record events
<prefix>.cycles.tsv   every start that reaches a detected non-{1,3} cycle, with length and canonical minimum
<prefix>.summary.txt  current/final compact summary

Metrics
-------
terminal_steps : odd->odd map steps until first arrival at 1, 3, or another detected cycle
first_lower    : first odd->odd step k for which T^k(n) < n
odd_peak       : maximum odd state in the accelerated trajectory
raw_peak       : maximum 5*n-r before powers of 2 are removed
div2_total     : total number of factors of 2 removed along the trajectory

Notes
-----
* Positive odd starts <= max_n are scanned; for max_n=10^10 this is 5,000,000,000 starts.
* Non-{1,3} cycles are detected with Brent's O(1)-memory cycle detection.
* 128-bit overflow is detected and counted instead of silently wrapping.
* Record tie-breaking is deterministic: the smaller starting n wins when record values are equal.
* A chunk line is flushed before it is considered completed, so rerunning safely resumes from durable chunk output.

Validated at max_n=1,000,000
----------------------------
odd starts             500,000
reached 1              323,407
reached 3              176,593
other cycles           0
u128 overflows         0
max terminal steps     87 at n=575945
max first-lower sigma  58 at n=575945
max odd peak           51,740,141 at smallest tying start n=640515
max raw peak           258,700,704 at smallest tying start n=640515
max total /2 count     221 at n=575945
