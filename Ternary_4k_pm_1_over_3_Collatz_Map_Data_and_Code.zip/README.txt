Ternary (4k +/- 1)/3 Collatz-Type Map - supplementary archive
Author: Farhad Banazadeh

Contents:
- run_verification.py : deterministic exhaustive verification script. It follows
  all three branches of the map exactly and tests n <= 10^9.
- trajectories.txt : raw record trajectories and selected examples
- trajectory_milestones.txt : milestone and record information from the reported scan
- trajectory_records.png, record_evolution.png, record_table.png : figures (300 dpi)
- collatz_3k_minus9_analysis.md : separate background notes on an earlier comparison map
- manifest.sha256 : SHA-256 hashes of the archived files

The paper PDF is distributed separately from this archive.

The record data in this archive are the numerical results discussed in the paper.
The verification script is included as a transparent checker and follows the
three-branch mathematical definition directly.
