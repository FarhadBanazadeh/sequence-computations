#!/usr/bin/env python3
"""Deterministic exhaustive verification of the ternary (4k +/- 1)/3 map.

All starting values n in [1, 10^9] are tested. The implementation follows
exactly the three cases in the paper. Python integers are used, so the code
does not rely on signed 64-bit overflow behavior.

Run: python3 run_verification.py [N]
Default: N = 10^9
"""
import sys
import time

N_DEFAULT = 10**9

def T(k: int) -> int:
    r = k % 3
    if r == 0:
        return k // 3
    if r == 1:
        return (4 * k - 1) // 3
    return (4 * k + 1) // 3

def main(N: int = N_DEFAULT, milestone: int = 10**7) -> None:
    t0 = time.time()
    max_steps = 0
    arg_steps = 0
    max_peak = 0
    arg_peak = 0

    for n in range(1, N + 1):
        k = n
        steps = 0
        peak = n
        while k != 1:
            k = T(k)
            steps += 1
            if k > peak:
                peak = k
        if steps > max_steps:
            max_steps, arg_steps = steps, n
        if peak > max_peak:
            max_peak, arg_peak = peak, n

        if n % milestone == 0:
            elapsed = time.time() - t0
            print(
                "milestone n=%d elapsed=%.1fs max_steps=%d@%d max_peak=%.6e@%d"
                % (n, elapsed, max_steps, arg_steps, max_peak, arg_peak),
                flush=True,
            )

    elapsed = time.time() - t0
    print(
        "DONE: 100%% convergence up to %d; time=%.1fs; max_steps=%d @ n=%d; "
        "max_peak=%.6e @ n=%d"
        % (N, elapsed, max_steps, arg_steps, max_peak, arg_peak)
    )

if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else N_DEFAULT)
