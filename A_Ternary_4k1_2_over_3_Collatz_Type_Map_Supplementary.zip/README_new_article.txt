# A Ternary (4k+1(2))/3 Collatz-Type Map with Two Attracting Cycles

Author: Farhad Banazadeh  
Independent Researcher  
Email: fn.bana@hotmail.com  
ORCID: 0009-0004-7023-0298

## Paper
A Ternary (4k+1(2))/3 Collatz-Type Map with Two Attracting Cycles: Theoretical Analysis and Exhaustive Computational Verification up to 10^9.

## Main results
- Admissible starts up to 10^9: 666,666,667
- Cycle C1 = (1,2): 21,785,111 starts (3.267766648366117%)
- Cycle C7 = (7,10,14,19,26,35,47): 644,881,556 starts (96.732233351633880%)
- Unknown: 0
- Total steps: 42,759,887,447
- Mean steps: 64.139831138430083
- Maximum steps: 385, starting from 696,171,200
- Global peak: 134,701,251,885,711,310, from 920,435,228 at step 115
- Total removed factors of 3: 21,683,837,513
- Maximum factors removed in one step: 19
- Runtime: 527.834688 seconds

## Theoretical analysis included
- 3-adic valuation and Haar-measure/ergodic heuristic
- Distribution P(v3=k)=2/3^(k+1)
- Expected removed exponent E[v3]=1/2
- Negative logarithmic drift delta = ln(4/3) - (1/2)ln(3) ≈ -0.2616
- Average geometric factor 4/(3 sqrt(3)) ≈ 0.7698
- Average logarithmic contraction of about 23.02%
- Algebraic analysis of the two observed cycles
- Stopping-time and peak analysis
- Clear distinction between heuristic theory, finite computational verification, and the global conjecture

## Files
- A_Ternary_4k1_2_over_3_Collatz_Type_Map.pdf — research article
- A_Ternary_4k1_2_over_3_Collatz_Type_Map.tex — LaTeX source
- ternary_collatz.c — exhaustive C verification program
- ternary_map_1e9.cpp — additional exhaustive implementation
- results_ternary_4k1_2_N1000000000.json — machine-readable result
- results_ternary_4k1_2_N1000000000_summary.csv — CSV summary
- results_ternary_4k1_2_N1000000000_report.txt — text report
- theoretical_analysis_summary.md — theoretical-analysis summary
- SHA256SUMS.txt — file checksums

Previous related paper:
Zenodo DOI: https://doi.org/10.5281/ZENODO.22195651
GitHub repository: https://github.com/FarhadBanazadeh/sequence-computations
