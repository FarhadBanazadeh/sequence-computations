# Theoretical analysis used in the paper

The map is defined on positive integers not divisible by 3. Write n=3p+1 or n=3p+2 and define

- G(3p+1)=4p+2
- G(3p+2)=4p+3

Then remove all factors of 3:

T(n)=G(n)/3^{v_3(G(n))}.

The compressed computation represents the eliminated state 3 by 1, giving the 2-cycle 1 -> 2 -> 1.

## 3-adic valuation heuristic

For large values, G(n) is approximately (4/3)n. If v=v_3(G(n)), then

T(n)/n approximately 4/3^{v+1}.

Under the Haar-measure / uniform-residue heuristic in Z_3,

P(v=k)=2/3^{k+1}, k>=0.

Therefore E[v]=1/2.

The mean logarithmic drift is

delta = ln(4/3) - (1/2) ln(3) = ln(4/(3 sqrt(3))) approximately -0.2616.

The corresponding geometric mean factor is approximately 0.7698, which is about a 23.02% contraction per step in this heuristic model.

This is a heuristic, not a proof of convergence for every deterministic orbit.

## Two observed cycles

C1=(1,2).

C7=(7,10,14,19,26,35,47).

For C7, G(47)=63=3^2*7, so the final compressed step is 47 -> 7.

The theoretical note also gives asymptotic cycle-scale estimates 16/27 and 16384/19683. These are heuristic multiplicative scale estimates, not ordinary derivatives of the discrete valuation map.

## One-million stopping-time study

Among 666,667 admissible starts up to 10^6, the reported maximum stopping time is 143 at n=497,116, with peak 410,683,162 in the stopping-time segment.

Top records:
1. 497,116: 143 steps, peak 410,683,162
2. 662,822: 142 steps, peak 410,683,162
3. 883,763: 141 steps, peak 410,683,162
4. 749,897: 129 steps, peak 2,687,932,606
5. 629,449: 127 steps, peak 263,207,404,847
6. 839,266: 126 steps, peak 263,207,404,847
7. 832,280: 121 steps, peak 2,687,932,606
8. 981,244: 120 steps, peak 40,062,776,062
9. 360,637: 119 steps, peak 517,652,138
10. 999,863: 118 steps, peak 2,687,932,606

The one-million study reported approximately 3.31% in C1 and 96.69% in C7.
