/*
  Ternary (4k+1(2))/3 Collatz-type map
  Exhaustive audit for starting values 1..N, excluding multiples of 3.

  Map:
      n = 3p+1  -> 4p+2 = (4n+2)/3
      n = 3p+2  -> 4p+3 = (4n+1)/3

  After each map step, all factors of 3 are removed.
  For the compressed state space used in this program, 3 is normalized to 1.
  Therefore the observed small cycle is:
      1 -> 2 -> 1
  and the 7-cycle is:
      7 -> 10 -> 14 -> 19 -> 26 -> 35 -> 47 -> 7

  The program does NOT store all trajectories. It computes every admissible
  starting value, uses a compact memoization table for states <= N, and keeps
  only aggregate statistics plus optional per-start CSV output.

  Build:
      clang++ -O3 -std=c++17 -DNDEBUG ternary_map_1e9.cpp -o ternary_map_1e9

  Run:
      ./ternary_map_1e9 1000000000
*/

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

using u32 = uint32_t;
using u64 = uint64_t;
using i64 = int64_t;

static inline u32 strip3(u64 x) {
    // Remove every factor of 3. For the intended range x is small enough
    // that u64 is ample even when a trajectory temporarily exceeds N.
    while (x % 3ULL == 0ULL) x /= 3ULL;
    return static_cast<u32>(x);
}

static inline u32 next_value(u32 n) {
    // n is never divisible by 3 here.
    u64 m;
    if (n % 3U == 1U)
        m = (4ULL * n + 2ULL) / 3ULL;
    else
        m = (4ULL * n + 1ULL) / 3ULL;

    m = strip3(m);

    // Compressed convention: the eliminated state 3 is represented by 1.
    // This makes the first attractor exactly {1,2}.
    if (m == 3U) m = 1U;

    return static_cast<u32>(m);
}

static inline bool in_cycle1(u32 n) {
    return n == 1U || n == 2U;
}

static inline bool in_cycle7(u32 n) {
    switch (n) {
        case 7: case 10: case 14: case 19: case 26: case 35: case 47:
            return true;
        default:
            return false;
    }
}

static inline const char* cycle_name(u32 n) {
    if (in_cycle1(n)) return "cycle_1";
    if (in_cycle7(n)) return "cycle_7";
    return "unknown";
}

struct Stats {
    u64 starts = 0;
    u64 cycle1 = 0;
    u64 cycle7 = 0;
    u64 unknown = 0;

    u64 total_steps = 0;
    u64 max_steps = 0;
    u32 max_steps_start = 0;

    u32 global_peak = 0;
    u32 global_peak_start = 0;
    u64 global_peak_step = 0;

    u64 total_stripped_3_factors = 0;
    u64 max_single_step_3_factors = 0;

    u64 max_trajectory_value = 0; // same as global_peak, retained for JSON clarity

    long double sum_steps = 0.0L;
};

static void write_json(const std::string& file, u64 N, const Stats& s,
                       double seconds) {
    std::ofstream out(file);
    out << "{\n";
    out << "  \"map\": \"ternary_(4k+1(2))/3\",\n";
    out << "  \"domain\": \"1 <= n <= N, 3 does not divide n\",\n";
    out << "  \"N\": " << N << ",\n";
    out << "  \"admissible_starts\": " << s.starts << ",\n";
    out << "  \"cycle_1\": {\"members\": [1,2], \"count\": " << s.cycle1
        << ", \"percent\": " << std::setprecision(12)
        << (100.0L * s.cycle1 / s.starts) << "},\n";
    out << "  \"cycle_7\": {\"members\": [7,10,14,19,26,35,47], \"count\": "
        << s.cycle7 << ", \"percent\": "
        << (100.0L * s.cycle7 / s.starts) << "},\n";
    out << "  \"unknown\": " << s.unknown << ",\n";
    out << "  \"total_steps\": " << s.total_steps << ",\n";
    out << "  \"mean_steps\": " << std::setprecision(15)
        << (double)(s.sum_steps / s.starts) << ",\n";
    out << "  \"max_steps\": " << s.max_steps << ",\n";
    out << "  \"max_steps_start\": " << s.max_steps_start << ",\n";
    out << "  \"global_peak\": " << s.global_peak << ",\n";
    out << "  \"global_peak_start\": " << s.global_peak_start << ",\n";
    out << "  \"global_peak_step\": " << s.global_peak_step << ",\n";
    out << "  \"total_removed_3_factors\": " << s.total_stripped_3_factors << ",\n";
    out << "  \"max_removed_3_factors_in_one_step\": "
        << s.max_single_step_3_factors << ",\n";
    out << "  \"runtime_seconds\": " << std::setprecision(12) << seconds << "\n";
    out << "}\n";
}

static void write_latex(const std::string& file, u64 N, const Stats& s,
                        double seconds) {
    std::ofstream out(file);
    out << R"(\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,booktabs}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\title{Exhaustive Computational Study of a Ternary $(4k+1(2))/3$ Collatz-Type Map}
\author{Farhad Banazadeh}
\date{\today}
\begin{document}
\maketitle

\section{Definition}
Let
\[
D_N=\{n\in\mathbb N:1\le n\le N,\;3\nmid n\}.
\]
For $n=3p+1$ define $T(n)=4p+2$, and for $n=3p+2$ define
$T(n)=4p+3$. After each step, every factor of $3$ is removed:
\[
F(n)=\frac{T(n)}{3^{v_3(T(n))}}.
\]
In the compressed convention used in this computation, the state $3$ is
represented by $1$. Thus the first observed attractor is
$1\to2\to1$.

The second observed attractor is
\[
7\to10\to14\to19\to26\to35\to47\to7.
\]

\section{Computational experiment}
The experiment exhaustively checks every $n\in D_N$. For each starting value,
the program records the stopping cycle, number of steps to first cycle entry,
and maximum value reached. It also records global maxima and aggregate
statistics. The implementation uses compact memoization and does not store
complete trajectories for all starting values.

\section{Results}
\begin{table}[h]
\centering
\begin{tabular}{lr}
\toprule
Quantity & Value\\
\midrule
Upper bound $N$ & )";
    out << N;
    out << R"(\\
Admissible starting values & )";
    out << s.starts;
    out << R"(\\
Cycle $\{1,2\}$ count & )";
    out << s.cycle1;
    out << R"(\\
Cycle $\{1,2\}$ percentage & )";
    out << std::fixed << std::setprecision(8)
        << (100.0L*s.cycle1/s.starts);
    out << R"(\%\\
Cycle $\{7,10,14,19,26,35,47\}$ count & )";
    out << s.cycle7;
    out << R"(\\
Cycle 7 percentage & )";
    out << std::fixed << std::setprecision(8)
        << (100.0L*s.cycle7/s.starts);
    out << R"(\%\\
Unknown & )";
    out << s.unknown;
    out << R"(\\
Mean steps & )";
    out << std::setprecision(10) << (double)(s.sum_steps/s.starts);
    out << R"(\\
Maximum steps & )";
    out << s.max_steps << " (start " << s.max_steps_start << R"()\\
Global peak & )";
    out << s.global_peak << " (start " << s.global_peak_start
        << ", step " << s.global_peak_step << R"()\\
Runtime (s) & )";
    out << std::setprecision(6) << seconds;
    out << R"(\\
\bottomrule
\end{tabular}
\end{table}

\section{Reproducibility}
The source code, configuration, JSON result, and raw summary data are supplied
with this report. The exact compiler command and machine information should be
added to the final research record.

\end{document}
)";
}

int main(int argc, char** argv) {
    const u64 N = (argc >= 2) ? std::strtoull(argv[1], nullptr, 10)
                              : 1000000ULL;

    if (N < 1 || N > 1000000000ULL) {
        std::cerr << "N must be in [1, 1000000000].\n";
        return 2;
    }

    const u64 admissible = N - N / 3;
    Stats s;
    s.starts = admissible;

    const auto t0 = std::chrono::steady_clock::now();

    // Dense memoization for states <= N.
    // 0 = unknown, 1 = cycle1, 2 = cycle7.
    // A uint8_t table costs exactly N+1 bytes.
    std::vector<uint8_t> memo(static_cast<size_t>(N) + 1, 0);
    memo[1] = memo[2] = 1;
    for (u32 x : {7U,10U,14U,19U,26U,35U,47U}) memo[x] = 2;

    // We use a reusable vector for the current path. This is usually tiny.
    std::vector<u32> path;
    path.reserve(256);

    for (u32 start = 1; (u64)start <= N; ++start) {
        if (start % 3U == 0U) continue;

        path.clear();
        u32 x = start;
        u64 steps = 0;
        u32 peak = start;
        u64 peak_step = 0;
        u64 removed3_this_path = 0;

        while (true) {
            if (x <= N && memo[x] != 0) {
                const uint8_t c = memo[x];
                if (c == 1) s.cycle1++;
                else if (c == 2) s.cycle7++;
                else s.unknown++;
                break;
            }

            // A value outside N cannot use the dense memo table.
            // Continue until it reaches a known cycle or returns to a state
            // already present in this current path.
            bool repeated = false;
            for (u32 y : path) {
                if (y == x) { repeated = true; break; }
            }
            if (repeated) {
                // This should not occur for the two known cycles; retain as
                // a safety classification rather than assuming a result.
                s.unknown++;
                break;
            }

            path.push_back(x);

            // Compute the unstripped image so we can count factors of 3.
            u64 m;
            if (x % 3U == 1U)
                m = (4ULL*x + 2ULL) / 3ULL;
            else
                m = (4ULL*x + 1ULL) / 3ULL;

            u64 local3 = 0;
            while (m % 3ULL == 0ULL) {
                m /= 3ULL;
                ++local3;
            }
            removed3_this_path += local3;
            if (local3 > s.max_single_step_3_factors)
                s.max_single_step_3_factors = local3;

            if (m == 3ULL) m = 1ULL;
            x = static_cast<u32>(m);
            ++steps;

            if (x > peak) {
                peak = x;
                peak_step = steps;
            }

            if (steps > 10000000ULL) {
                s.unknown++;
                break;
            }
        }

        s.total_steps += steps;
        s.sum_steps += (long double)steps;
        s.total_stripped_3_factors += removed3_this_path;

        if (steps > s.max_steps) {
            s.max_steps = steps;
            s.max_steps_start = start;
        }
        if (peak > s.global_peak) {
            s.global_peak = peak;
            s.global_peak_start = start;
            s.global_peak_step = peak_step;
        }

        // Propagate known classification backwards through this path.
        uint8_t cls = 0;
        if (in_cycle1(x)) cls = 1;
        else if (in_cycle7(x)) cls = 2;

        if (cls != 0) {
            for (u32 v : path) {
                if (v <= N) memo[v] = cls;
            }
        }

        if ((start % 10000000U) == 0U) {
            std::cerr << "processed " << start << " / " << N << "\r";
        }
    }

    const auto t1 = std::chrono::steady_clock::now();
    const double seconds =
        std::chrono::duration<double>(t1 - t0).count();

    const std::string prefix = "ternary_4k1_2_N" + std::to_string(N);
    write_json(prefix + ".json", N, s, seconds);
    write_latex(prefix + ".tex", N, s, seconds);

    std::ofstream csv(prefix + "_summary.csv");
    csv << "metric,value\n";
    csv << "N," << N << "\n";
    csv << "admissible_starts," << s.starts << "\n";
    csv << "cycle_1_count," << s.cycle1 << "\n";
    csv << "cycle_1_percent," << std::setprecision(12)
        << (100.0L*s.cycle1/s.starts) << "\n";
    csv << "cycle_7_count," << s.cycle7 << "\n";
    csv << "cycle_7_percent," << (100.0L*s.cycle7/s.starts) << "\n";
    csv << "unknown," << s.unknown << "\n";
    csv << "total_steps," << s.total_steps << "\n";
    csv << "mean_steps," << (double)(s.sum_steps/s.starts) << "\n";
    csv << "max_steps," << s.max_steps << "\n";
    csv << "max_steps_start," << s.max_steps_start << "\n";
    csv << "global_peak," << s.global_peak << "\n";
    csv << "global_peak_start," << s.global_peak_start << "\n";
    csv << "global_peak_step," << s.global_peak_step << "\n";
    csv << "total_removed_3_factors," << s.total_stripped_3_factors << "\n";
    csv << "max_removed_3_factors_in_one_step," << s.max_single_step_3_factors << "\n";
    csv << "runtime_seconds," << seconds << "\n";

    std::ofstream txt(prefix + "_report.txt");
    txt << "Ternary (4k+1(2))/3 exhaustive computational audit\n";
    txt << "N = " << N << "\n";
    txt << "Admissible starts = " << s.starts << "\n\n";
    txt << "Cycle 1: {1,2}\n";
    txt << "Count = " << s.cycle1 << "\n";
    txt << "Percent = " << std::setprecision(12)
        << (100.0L*s.cycle1/s.starts) << "%\n\n";
    txt << "Cycle 7: {7,10,14,19,26,35,47}\n";
    txt << "Count = " << s.cycle7 << "\n";
    txt << "Percent = " << (100.0L*s.cycle7/s.starts) << "%\n\n";
    txt << "Unknown = " << s.unknown << "\n";
    txt << "Total steps = " << s.total_steps << "\n";
    txt << "Mean steps = " << (double)(s.sum_steps/s.starts) << "\n";
    txt << "Maximum steps = " << s.max_steps
        << " (start " << s.max_steps_start << ")\n";
    txt << "Global peak = " << s.global_peak
        << " (start " << s.global_peak_start
        << ", step " << s.global_peak_step << ")\n";
    txt << "Total removed factors of 3 = "
        << s.total_stripped_3_factors << "\n";
    txt << "Maximum factors of 3 removed in one step = "
        << s.max_single_step_3_factors << "\n";
    txt << "Runtime seconds = " << seconds << "\n";

    std::cout << "\nDONE\n";
    std::cout << "N = " << N << "\n";
    std::cout << "Admissible = " << s.starts << "\n";
    std::cout << "Cycle 1 = " << s.cycle1 << " ("
              << std::setprecision(8) << (100.0L*s.cycle1/s.starts) << "%)\n";
    std::cout << "Cycle 7 = " << s.cycle7 << " ("
              << (100.0L*s.cycle7/s.starts) << "%)\n";
    std::cout << "Unknown = " << s.unknown << "\n";
    std::cout << "Max steps = " << s.max_steps
              << " at start " << s.max_steps_start << "\n";
    std::cout << "Global peak = " << s.global_peak
              << " at start " << s.global_peak_start
              << " (step " << s.global_peak_step << ")\n";
    std::cout << "Runtime = " << seconds << " s\n";
    return 0;
}
