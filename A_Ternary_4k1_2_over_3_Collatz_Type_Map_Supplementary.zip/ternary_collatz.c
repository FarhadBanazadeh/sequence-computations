#include <stdio.h>
#include <time.h>

#define N 1000000000LL
#define MAX_STEPS 1000000

int is_cycle1(long long n)
{
    return (n == 1 || n == 2);
}

int is_cycle7(long long n)
{
    return (n == 7 || n == 10 || n == 14 ||
            n == 19 || n == 26 || n == 35 ||
            n == 47);
}

long long next_value(long long n, int *removed)
{
    long long x;

    *removed = 0;

    if (n % 3 == 1)
        x = 4 * n + 2;
    else
        x = 4 * n + 1;

    x /= 3;

    while (x % 3 == 0)
    {
        x /= 3;
        (*removed)++;
    }

    if (x == 3)
        x = 1;

    return x;
}

int main(void)
{
    clock_t start_time = clock();

    long long cycle1_count = 0;
    long long cycle7_count = 0;
    long long unknown_count = 0;

    long long total_steps = 0;

    long long max_steps = 0;
    long long max_steps_start = 0;

    long long global_peak = 0;
    long long global_peak_start = 0;
    long long global_peak_step = 0;

    long long total_removed = 0;
    long long max_removed_one_step = 0;

    long long admissible = 0;

    for (long long start = 1; start <= N; start++)
    {
        if (start % 3 == 0)
            continue;

        admissible++;

        long long n = start;
        long long steps = 0;

        long long peak = start;
        long long peak_step = 0;

        int found_cycle = 0;

        while (steps < MAX_STEPS)
        {
            if (is_cycle1(n))
            {
                cycle1_count++;
                found_cycle = 1;
                break;
            }

            if (is_cycle7(n))
            {
                cycle7_count++;
                found_cycle = 1;
                break;
            }

            if (n > peak)
            {
                peak = n;
                peak_step = steps;
            }

            int removed;
            long long next = next_value(n, &removed);

            total_removed += removed;

            if (removed > max_removed_one_step)
                max_removed_one_step = removed;

            n = next;
            steps++;
        }

        if (!found_cycle)
            unknown_count++;

        total_steps += steps;

        if (steps > max_steps)
        {
            max_steps = steps;
            max_steps_start = start;
        }

        if (peak > global_peak)
        {
            global_peak = peak;
            global_peak_start = start;
            global_peak_step = peak_step;
        }
    }

    double cycle1_percent =
        100.0 * cycle1_count / admissible;

    double cycle7_percent =
        100.0 * cycle7_count / admissible;

    double mean_steps =
        (double)total_steps / admissible;

    double runtime =
        (double)(clock() - start_time) / CLOCKS_PER_SEC;

    printf("\n========== C RESULT ==========\n\n");

    printf("N = %lld\n\n", (long long)N);

    printf("Admissible starts = %lld\n\n", admissible);

    printf("Cycle 1 count = %lld\n", cycle1_count);
    printf("Cycle 1 percent = %.15f\n\n", cycle1_percent);

    printf("Cycle 7 count = %lld\n", cycle7_count);
    printf("Cycle 7 percent = %.15f\n\n", cycle7_percent);

    printf("Unknown = %lld\n\n", unknown_count);

    printf("Total steps = %lld\n", total_steps);
    printf("Mean steps = %.15f\n\n", mean_steps);

    printf("Maximum steps = %lld\n", max_steps);
    printf("Maximum-step starting number = %lld\n\n",
           max_steps_start);

    printf("Global peak = %lld\n", global_peak);
    printf("Global-peak starting number = %lld\n",
           global_peak_start);
    printf("Global-peak step = %lld\n\n",
           global_peak_step);

    printf("Total removed factors of 3 = %lld\n",
           total_removed);

    printf("Maximum factors of 3 removed in one step = %lld\n\n",
           max_removed_one_step);

    printf("Runtime = %.6f seconds\n\n", runtime);

    return 0;
}
